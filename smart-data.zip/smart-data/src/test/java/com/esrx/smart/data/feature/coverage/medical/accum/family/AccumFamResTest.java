package com.esrx.smart.data.feature.coverage.medical.accum.family;

import com.esrx.smart.data.util.JsonUtil;
import com.fasterxml.jackson.databind.json.JsonMapper;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.is;

/**
 * Medical Accumulator Family Tests
 *
 * @author NV
 * @since 5/18/2023
 */
class AccumFamResTest {

    private static final String FILENAME = "familyAccum";

    @Test @SneakyThrows
    public void givenJson_mapToJavaObject() {
        AccumFamRes accumPlan = JsonMapper.builder().build().readValue(JsonUtil.getJson(FILENAME), AccumFamRes.class);
        assertThat(accumPlan.getAccumFamMembers().getAccumulationPeriods().get(0).getAccumulationBeginDate(), is("01/01/2023"));
        assertThat(accumPlan.getAccumFamMembers().getAccumulationPeriods().get(0).getPlanAccumulators(), is(true));
        assertThat(accumPlan.getAccumFamMembers().getAccumulationPeriods().get(0).getAccumulationNetworkCategories().size(), greaterThanOrEqualTo(2));
    }
}

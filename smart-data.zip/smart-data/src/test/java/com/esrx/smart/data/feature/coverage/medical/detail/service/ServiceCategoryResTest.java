package com.esrx.smart.data.feature.coverage.medical.detail.service;

import com.esrx.smart.data.util.JsonUtil;
import com.fasterxml.jackson.databind.json.JsonMapper;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.is;

/**
 * Service Categories Response Test
 *
 * @author NV
 * @since 5/26/2023
 */
class ServiceCategoryResTest {

    private static final String FILENAME = "serviceCategories";

    @Test
    @SneakyThrows
    public void givenJson_mapToJavaObject() {
        ServiceCategoriesRes serviceCategories = JsonMapper.builder().build().readValue(JsonUtil.getJson(FILENAME), ServiceCategoriesRes.class);
        assertThat(serviceCategories.getServiceCategories().size(), greaterThanOrEqualTo(8));
        assertThat(serviceCategories.getServiceCategories().get(0).getVirtualInd(), is(false));
        assertThat(serviceCategories.getServiceCategories().get(0).getServiceBenefits().size(), greaterThanOrEqualTo(3));
    }
}

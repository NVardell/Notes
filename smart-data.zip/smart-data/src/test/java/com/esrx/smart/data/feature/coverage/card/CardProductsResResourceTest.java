package com.esrx.smart.data.feature.coverage.card;

import com.esrx.smart.data.feature.card.products.CardProductsRes;
import com.esrx.smart.data.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * Card Resource Unit Tests
 *
 * @author NV
 * @since 5/15/2023
 */
class CardProductsResResourceTest {

    private static final String FILENAME = "cardProducts";

    @Test
    public void givenJson_mapToJavaObject() throws IOException {
        ObjectMapper mapper = JsonMapper.builder().build();
        CardProductsRes cardProductsRes = mapper.readValue(JsonUtil.getJson(FILENAME), CardProductsRes.class);
        assertThat(cardProductsRes.getFamilyMembers().get(0).getName().getFirst(), is("Nate"));
        assertThat(cardProductsRes.getFamilyMembers().get(0).getIsLoggedInUser(), is(true));
        assertThat(cardProductsRes.getFamilyMembers().get(0).getDisplayRank(), is(1));
    }
}

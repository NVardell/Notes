package com.esrx.smart.data.feature.member.product;

import com.esrx.smart.data.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * Member Product Group Response Tests
 *
 * @author NV
 * @since 6/19/2023
 */
class MemberProductGroupResTest {

    private static final String FILENAME = "memberProducts";

    @Test
    public void givenJson_mapToJavaObject() throws IOException {
        ObjectMapper mapper = JsonMapper.builder().build();
        MemberProductGroupRes cardProductsRes = mapper.readValue(JsonUtil.getJson(FILENAME), MemberProductGroupRes.class);
        assertThat(cardProductsRes.getMemberProductGroups().get(0).getDisplayRank(), is(1));
        assertThat(cardProductsRes.getMetadata().getOutcome().getStatus(), is(200));
        assertThat(cardProductsRes.getMemberProductGroups().size(), is(5));
    }
}

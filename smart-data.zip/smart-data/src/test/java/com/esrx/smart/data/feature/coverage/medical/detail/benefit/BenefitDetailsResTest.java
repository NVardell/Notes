package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import com.esrx.smart.data.util.JsonUtil;
import com.fasterxml.jackson.databind.json.JsonMapper;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.is;

/**
 * Benefit Details Response Tests
 *
 * @author NV
 * @since 5/26/2023
 */
class BenefitDetailsResTest {

    private static final String FILENAME = "medicalBenefitDetails";

    @Test
    @SneakyThrows
    public void givenJson_mapToJavaObject() {
        BenefitDetailsRes benefitDetails = JsonMapper.builder().build().readValue(JsonUtil.getJson(FILENAME), BenefitDetailsRes.class);
        assertThat(benefitDetails.getMedicalBenefitDetails().getNetworkCoverageKeyCode(), is("INNOON"));
        assertThat(benefitDetails.getMedicalBenefitDetails().getBenefitNetworkList().get(0).getPlanOOPMax(), is(true));
        assertThat(benefitDetails.getMedicalBenefitDetails().getBenefitNetworkList().size(), greaterThanOrEqualTo(2));
    }
}

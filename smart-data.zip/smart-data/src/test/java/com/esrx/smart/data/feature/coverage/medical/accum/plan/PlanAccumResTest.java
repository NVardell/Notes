package com.esrx.smart.data.feature.coverage.medical.accum.plan;

import com.esrx.smart.data.util.JsonUtil;
import com.fasterxml.jackson.databind.json.JsonMapper;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * Medical Plan Accumulator Tests
 *
 * @author NV
 * @since 5/18/2023
 */
class PlanAccumResTest {

    private static final String FILENAME = "medicalAccumInNet";

    @Test @SneakyThrows
    public void givenJson_mapToJavaObject() {
        PlanAccumRes planAccumRes = JsonMapper.builder().build().readValue(JsonUtil.getJson(FILENAME), PlanAccumRes.class);
        assertThat(planAccumRes.getMedicalPlanAccumulators().getAccumulationBeginDate(), is("2023-01-01"));
        assertThat(planAccumRes.getMedicalPlanAccumulators().getDeductibleWaived(), is(false));
        assertThat(planAccumRes.getMedicalPlanAccumulators().getAccumulators().getDeductibleRemainingAmount(), is(4706.47));
    }

}

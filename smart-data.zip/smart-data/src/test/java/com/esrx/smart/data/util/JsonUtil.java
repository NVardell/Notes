package com.esrx.smart.data.util;

import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * JSON Util
 *
 * @author NV
 * @since 5/15/2023
 */
public class JsonUtil {
    public static File getJson(String fileName) throws FileNotFoundException {
        return ResourceUtils.getFile("classpath:" + fileName + ".json");
    }
}

package com.esrx.smart.data.common.name;

import com.esrx.smart.data.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * Name Unit Tests
 *
 * @author NV
 * @since 5/15/2023
 */
class NameTest {

    private static final String FILENAME = "name";

    @Test
    public void givenJson_mapToJavaObject() throws IOException {
        ObjectMapper mapper = JsonMapper.builder().build();
        Name name = mapper.readValue(JsonUtil.getJson(FILENAME), Name.class);
        assertThat(name.getFirst(), is("Nate"));
        assertThat(name.getFullName(), is("Nate I Vardell"));
    }
}

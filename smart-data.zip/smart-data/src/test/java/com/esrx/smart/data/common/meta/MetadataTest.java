package com.esrx.smart.data.common.meta;

import com.esrx.smart.data.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Metadata Test Cases
 *
 * @author NV
 * @since 5/15/2023
 */
class MetadataTest {

    private static final String FILENAME = "metadata";

    @Test
    public void givenJson_mapToJavaObject() throws IOException {
        ObjectMapper mapper = JsonMapper.builder().build();
        Metadata meta = mapper.readValue(JsonUtil.getJson(FILENAME), Metadata.class);
        assertThat(meta, notNullValue());
        assertThat(meta.getOutcome().getStatus(), is(200));
        assertThat(meta.getOutcome().getAdditionalDetails().size(), is(1));
        assertThat(meta.getOutcome().getAdditionalDetails().get(0).getSeverity(), is("WARNING"));
    }
}

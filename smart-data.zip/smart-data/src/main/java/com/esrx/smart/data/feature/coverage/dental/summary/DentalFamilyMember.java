package com.esrx.smart.data.feature.coverage.dental.summary;

import com.esrx.smart.data.common.name.Name;
import lombok.Data;

/**
 * Dental Family Member Model
 *
 * @author NV
 * @since 6/9/2023
 */
@Data public class DentalFamilyMember {
    private Name name;
    private String idCardExtensionCode;
    private String dateOfBirth;
    private String relationshipToSubscriberCode;
    private String coverageEffectiveDate;
    private String coverageCancelDate;
    private String coverageStatus;
    private Boolean loggedInUser;
    private Boolean delegate;
    private String displayRank;
    private Restriction restrictions;
    private String pediatricEligibleIndicator;
}

package com.esrx.smart.data.feature.coverage.medical.coveragesummeries;
import lombok.Data;
/**
 * Relation To Subscriber POJO
 *
 * @author C7H4X4
 *
 */

 @Data
public class RelationshipToSubscriber {
     private String code;
     private String description;
}

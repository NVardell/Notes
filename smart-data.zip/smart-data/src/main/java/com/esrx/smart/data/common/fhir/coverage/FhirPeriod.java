package com.esrx.smart.data.common.fhir.coverage;

import lombok.Builder;
import lombok.Data;

/**
 * FHIR Period Model
 *
 * @author NV
 * @since 6/9/2023
 */
@Data @Builder public class FhirPeriod {
    private String start;
}

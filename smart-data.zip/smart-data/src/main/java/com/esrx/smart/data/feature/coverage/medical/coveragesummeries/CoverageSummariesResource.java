package com.esrx.smart.data.feature.coverage.medical.coveragesummeries;

import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * Coverage Summaries Controller
 *
 * @author  C7H4X4
 *
 */
@Log4j2
@RestController public class CoverageSummariesResource {

    @Value("${proxy.port}") private int proxyPort;
    @Value("${proxy.host}") private String proxyHost;
    @Value("${coverage.summaries.resource}") private String coverageSummariesURI;

    private static final String PRODUCT_TYPE = "productGroupType";

    @GetMapping("coverageSummaries")
    public Optional<CoverageSummariesRes> getCoverageSummaries(@RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken,
                                                               @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType) {
        return Optional.ofNullable(Unirest.get(coverageSummariesURI)
                .header(HttpHeaders.AUTHORIZATION, authBearerToken)
                .proxy(proxyHost, proxyPort)
                .queryString(PRODUCT_TYPE, productGroupType.toUpperCase())
                .asObject(CoverageSummariesRes.class)
                .getBody());
    }
}

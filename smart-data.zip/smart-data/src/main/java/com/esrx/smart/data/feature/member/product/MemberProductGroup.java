package com.esrx.smart.data.feature.member.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Member Product Group Model
 *
 * @author NV
 * @since 6/16/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data public class MemberProductGroup {
    private String productGroupType;
    private String coverageStatus;
    private String planNameKeyCode;
    private String groupId;
    private String sourceSystemLocationCode;
    private String claimSysCode;
    private String customerId;
    private String subscriberId;
    private Boolean customerIdUnavailable;
    private Boolean coverageDetailsUnavailable;
    private Boolean accumulatorsSharedWithMedical;
    private Integer displayRank;
}

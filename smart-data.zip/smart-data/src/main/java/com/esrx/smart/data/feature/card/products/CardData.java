package com.esrx.smart.data.feature.card.products;

import lombok.Data;

/**
 * Card Data POJO
 *
 * @author NV
 * @since 5/12/2023
 */
@Data
public class CardData {
    private String subscriberPID;
    private String accountNumber;
    private String memberIdentifier;
}

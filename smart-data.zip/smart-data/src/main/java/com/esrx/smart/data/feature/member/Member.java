package com.esrx.smart.data.feature.member;

import com.esrx.smart.data.common.name.Name;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

/**
 * Member Model
 *
 * @author NV
 * @since 6/7/2023
 */
@Data @Builder
@JsonInclude(JsonInclude.Include.NON_NULL) public class Member {
    private MemberMedicalBenefits memberMedicalBenefits;
    private String memberId;
    private String personId;
    private String dateOfBirth;  // private LocalDate dateOfBirth;
    private Name name;
}

package com.esrx.smart.data.feature.coverage.summary;

import com.esrx.smart.data.common.name.Name;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

/**
 * Card Product Summary Model
 *
 * @author NV
 * @since 6/2/2023
 */
@Data @Builder @JsonInclude(JsonInclude.Include.NON_NULL)
public class CardProductSummary {
    private String age;
    private String cardExtension;
    private String coverageEffectiveDate;
    private String coverageEndDate;
    private String coverageStatus;
    private String dateOfBirth;
    private String productGroupType;
    private String userAmiId;
    private String fullName;
    private String memberIdentifier;
    private String state;
    private String relationshipToSubscriber;
    private Name name;
}

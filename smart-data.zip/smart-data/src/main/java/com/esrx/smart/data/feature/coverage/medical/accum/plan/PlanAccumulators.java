package com.esrx.smart.data.feature.coverage.medical.accum.plan;

import lombok.Data;

/**
 * Plan Accumulation Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data public class PlanAccumulators {
    private String sourceSystemLocationCode;
    private String customerId;
    private String subscriberId;
    private Boolean applyRestrictions;
    private String accumulationBeginDate;
    private String accumulationEndDate;
    private String coverageStatus;
    private Boolean deductibleWaived;
    private Boolean grandfatheredPlan;
    private String accumulationNetworkCategoryCode;
    private PlanAccumulator accumulators;
}

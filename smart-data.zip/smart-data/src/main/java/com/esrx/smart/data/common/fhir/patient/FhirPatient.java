package com.esrx.smart.data.common.fhir.patient;

import com.esrx.smart.data.common.fhir.FhirResource;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * FHIR Patient Model
 *
 * @author NV
 * @since 6/9/2023
 */
@EqualsAndHashCode(callSuper = true)
@JsonPropertyOrder({ "resourceType", "name", "birthDate" })
@Data @Builder public class FhirPatient extends FhirResource {
    private List<FhirName> name;
    private String birthDate;  // private LocalDate birthDate;
}

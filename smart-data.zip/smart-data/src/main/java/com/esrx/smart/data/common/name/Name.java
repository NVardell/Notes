package com.esrx.smart.data.common.name;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Name POJO
 *
 * @author NV
 * @since 5/12/2023
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Name {
    private String prefix;
    private String first;
    private String middle;
    private String last;
    private String suffix;

    @JsonIgnore public String getFullName() {
        return Stream.of(prefix, first, middle, last, suffix)
                .filter(Objects::nonNull)
                .collect(Collectors.joining(" "));
    }

    @JsonIgnore public List<String> toList() {
        return Stream.of(prefix, first, middle, last, suffix)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }
}

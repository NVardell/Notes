package com.esrx.smart.data.feature.coverage.medical.coveragesummeries;

import lombok.Data;

import java.util.List;

/**
 * Coverage Summaries POJO
 *
 * @author C7H4X4
 *
 */
@Data
public class CoverageSummaries {
    private String customerId;
    private String subscriberId;
    private String sourceSystemLocationCode;
    private String productGroupType;
    private String productGroupTypeKeyCode;
    private String productTypeCode;
    private String planNameKeyCode;
    private String reimbursementProduct;
    private String groupId;
    private String groupName;
    private String planPeriodBeginDate;
    private String planPeriodEndDate;
    private boolean coverageDetailsUnavailable;
    private String primaryCareProviderRequirement;
    private boolean referralRequired;
    private String fundingArrangementTypeCode;
    private String networkCoverageKeyCode;
    private boolean grandfatheredPlan;
    private String networkTypeKeyCode;
    private CoverageNetwork network;
    private List<FamilyMember> familyMembers;
}

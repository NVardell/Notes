package com.esrx.smart.data.feature.card.products;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Card Product POJO
 *
 * @author NV
 * @since 5/12/2023
 */
@Data @JsonInclude(JsonInclude.Include.NON_NULL)
public class CardProduct {
    private String type;
    private String sourceSystemCode;
    private boolean allowsTempIDCards;
    private boolean bypassIDCardImage;
    private boolean allowsReplacementIDCards;
    private String idCardType;
    private String coverageEffectiveDate;
    private String coverageEndDate;
    private String coverageStatus;
    private String situsState;
    private CardData requestIDCardData;
    private CardIdentifier idCardIdentifier;
    private int displayRank;
    private String ami;
    private String idCardExtensionCode;
    private boolean employeeOnlyPlanIndicator;
}

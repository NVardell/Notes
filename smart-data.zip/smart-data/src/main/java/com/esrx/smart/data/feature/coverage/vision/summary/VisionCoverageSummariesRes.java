package com.esrx.smart.data.feature.coverage.vision.summary;

import com.esrx.smart.data.common.meta.Metadata;
import lombok.Data;
@Data
public class VisionCoverageSummariesRes {
    private CoverageSummaries coverageSummaries;
    private Metadata metadata;
}

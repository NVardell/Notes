package com.esrx.smart.data.feature.coverage.pharma.summary;
import com.esrx.smart.data.common.name.Name;
import lombok.Data;

@Data
public class FamilyMember {
    private Name name;
    private String dateOfBirth;
    private String relationshipToSubscriberCode;
    private String coverageEffectiveDate;
    private String coverageCancelDate;
    private String coverageStatus;
    private Boolean loggedInUser;
    private Boolean delegate;
    private String displayRank;
    private Restriction restrictions;
}

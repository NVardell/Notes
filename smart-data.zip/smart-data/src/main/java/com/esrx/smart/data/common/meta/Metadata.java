package com.esrx.smart.data.common.meta;

import lombok.Data;

/**
 * Metadata POJO
 *
 * @author NV
 * @since 5/12/2023
 */
@Data public class Metadata {
    private Outcome outcome;
    private String serviceReferenceId;
}

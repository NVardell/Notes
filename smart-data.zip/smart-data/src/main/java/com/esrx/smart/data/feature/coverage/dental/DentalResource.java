package com.esrx.smart.data.feature.coverage.dental;

import com.esrx.smart.data.feature.coverage.dental.summary.DentalCoverageSummariesRes;
import com.esrx.smart.data.feature.coverage.dental.summary.DentalCoverageSummary;
import com.esrx.smart.data.feature.coverage.dental.summary.DentalSummaryResource;
import com.esrx.smart.data.feature.coverage.summary.DentalSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * Dental Coverage Resource
 *
 * @author NV
 * @since 5/12/2023
 */
@RestController public class DentalResource {

    @Autowired DentalSummaryResource dentalSummaryResource;

    @GetMapping("getDentalSummary") public DentalSummary getDentalSummary(String authBearerToken) {

        DentalSummary dentalSummary = DentalSummary.builder().build();

        Optional<DentalCoverageSummariesRes> dentalCoverageSummariesRes = dentalSummaryResource.getDentalCoverageSummaries(authBearerToken);
        dentalCoverageSummariesRes.ifPresent(dentalCoverageSummariesResponse -> {
            DentalCoverageSummary coverageSummary = dentalCoverageSummariesResponse.getCoverageSummaries();

            if(coverageSummary != null) {
                dentalSummary.setGroupId(coverageSummary.getGroupId());
                dentalSummary.setPlanName(coverageSummary.getPlanName());
                dentalSummary.setPlanType(coverageSummary.getPlanType());
                dentalSummary.setNetworkName(coverageSummary.getNetworkDetails().getBenefitNetworkName());
            }
        });

        return dentalSummary;
    }

}

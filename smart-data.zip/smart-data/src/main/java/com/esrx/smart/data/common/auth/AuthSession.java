package com.esrx.smart.data.common.auth;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Auth Session Model
 *
 * @author NV
 * @since 6/6/2023
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthSession {
    private String expiresAt;
    private String status;
    private String sessionToken;
}

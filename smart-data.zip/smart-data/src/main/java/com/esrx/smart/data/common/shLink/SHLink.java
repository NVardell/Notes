package com.esrx.smart.data.common.shLink;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;

/**
 * SH Link Model
 *
 * @author NV
 * @since 6/13/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "url", "key", "exp","flag","label","v" })
@Data @Builder public class SHLink {
    private String url;
    private String key;
    private String exp;
    private String flag;
    private String label;
    private Integer v;
    @JsonIgnore private String uniMemberId;
}

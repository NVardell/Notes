package com.esrx.smart.data.feature.coverage.pharma.summary;
import lombok.Data;

@Data
public class Restriction {
    private Boolean hipaaRestriction;
    private Boolean delegationOptOut;
}

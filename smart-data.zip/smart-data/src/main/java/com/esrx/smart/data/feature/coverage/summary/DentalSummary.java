package com.esrx.smart.data.feature.coverage.summary;
import lombok.Builder;
import lombok.Data;

/**
 * Dental Summary Model
 *
 * @author NV
 * @since 6/9/2023
 */
@Data @Builder public class DentalSummary {
    private String planName;
    private String planType;
    private String groupId;
    private String networkName;
}

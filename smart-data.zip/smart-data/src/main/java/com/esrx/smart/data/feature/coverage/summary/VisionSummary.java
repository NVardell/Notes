package com.esrx.smart.data.feature.coverage.summary;

import lombok.Builder;
import lombok.Data;
@Data @Builder public class VisionSummary {
    private String groupId;
    private String visionType;
}

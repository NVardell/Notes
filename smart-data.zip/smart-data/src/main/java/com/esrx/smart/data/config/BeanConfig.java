package com.esrx.smart.data.config;

import com.esrx.smart.data.util.helper.JwtSignUtil;
import org.apache.http.HttpHost;
import org.apache.http.conn.routing.HttpRoutePlanner;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.http.SdkHttpClient;
import software.amazon.awssdk.http.apache.ApacheHttpClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

import java.security.SecureRandom;
import java.util.UUID;

/**
 * Bean Config
 *
 * @author NV
 * @since 6/12/2023
 */
@Configuration
public class BeanConfig {


    @Value("${proxy.host}") private String proxyHost;
    @Value("${proxy.port}") private Integer proxyPort;
    @Value("${aws.access.key}") private String awsAccessKeyId;
    @Value("${aws.secret.key}") private String awsAccessSecretKey;


    @Bean public JwtSignUtil jwtSigningHelper(@Value("${sh.kid}") String kid, @Value("${sh.jwks}") String privateKey) {
        return new JwtSignUtil(kid, privateKey);
    }

    @Bean public SecureRandom secureRandom() {
        return new SecureRandom(UUID.randomUUID().toString().getBytes());
    }

    @Bean public S3Client s3Client() {
        HttpRoutePlanner routePlanner = new DefaultProxyRoutePlanner(new HttpHost(proxyHost, proxyPort));

        SdkHttpClient apacheHttpClient =
                ApacheHttpClient.builder()
                        .maxConnections(100)
                        .tcpKeepAlive(true)
                        .httpRoutePlanner(routePlanner)
                        .build();

        AwsBasicCredentials awsCredentials = AwsBasicCredentials.create(awsAccessKeyId, awsAccessSecretKey);

        return S3Client.builder()
                .region(Region.US_EAST_2)
                .credentialsProvider(StaticCredentialsProvider.create(awsCredentials))
                .httpClient(apacheHttpClient)
                .build();
    }


}

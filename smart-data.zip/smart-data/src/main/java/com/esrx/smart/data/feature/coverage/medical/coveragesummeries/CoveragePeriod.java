package com.esrx.smart.data.feature.coverage.medical.coveragesummeries;
/**
 * Coverage Period POJO
 *
 * @author C7H4X4
 *
 */
import lombok.Data;

@Data
public class CoveragePeriod {
    private String effectiveDate;
    private String cancelDate;
}

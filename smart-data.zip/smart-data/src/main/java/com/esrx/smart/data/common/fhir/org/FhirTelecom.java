package com.esrx.smart.data.common.fhir.org;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * FHIR Telecom Model
 *
 * @author NV
 * @since 6/9/2023
 */
@AllArgsConstructor(staticName = "of")
@Data public class FhirTelecom {
    private String system;
    private String value;
}

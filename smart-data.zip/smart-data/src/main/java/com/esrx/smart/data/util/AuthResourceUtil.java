package com.esrx.smart.data.util;

import com.esrx.smart.data.common.auth.AuthLogin;
import com.esrx.smart.data.common.auth.AuthSession;
import com.esrx.smart.data.common.auth.AuthToken;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

import static org.apache.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED_VALUE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

/**
 * Auth Resource Util
 *
 * @author NV
 * @since 6/6/2023
 */
@Log4j2 @Service @RestController
public class AuthResourceUtil {

    @Value("${auth.login.resource}") String loginUri;
    @Value("${auth.authorize.resource}") String authorizeUri;
    @Value("${auth.token.resource}") String authTokenUri;

    @Value("${proxy.port}") private int proxyPort;
    @Value("${proxy.host}") private String proxyHost;

    private static final String CODE_FIELD = "code";
    private static final String SESSION_TOKEN_FIELD = "sessionToken";
    private static final String STATE_FIELD = "state";

    private static final String CLIENT_ID = "tWkJWsIBpzqDeU1ziYSx";
    private static final String CLIENT_ID_FIELD = "client_id";
    private static final String CODE_CHALLENGE = "8bO1j4brcIYY9rKzR-xiThXxL02dZaJrdsvJhXWYSLE";
    private static final String CODE_CHALLENGE_FIELD = "code_challenge";
    private static final String CODE_CHALLENGE_METHOD = "S256";
    private static final String CODE_CHALLENGE_METHOD_FIELD = "code_challenge_method";
    private static final String CODE_VERIFIER = "9G5C9W_eqE4YTKwAyMivxYgMo6jQbqvXjoDa64-nIuA";
    private static final String CODE_VERIFIER_FIELD = "code_verifier";
    private static final String GRANT_TYPE = "authorization_code";
    private static final String GRANT_TYPE_FIELD = "grant_type";
    private static final String REDIRECT_URI = "com.oktapreview.a-mycigna:/callback";
    private static final String REDIRECT_URI_FIELD = "redirect_uri";
    private static final String RESPONSE_TYPE = "code";
    private static final String RESPONSE_TYPE_FIELD = "response_type";


    @GetMapping("getAuthToken")
    public String getAuthToken(String user, String pass){

        log.info("[AUTH] Part 1/3 ~ Logging in User");
        AuthSession authSession =  Unirest.post(loginUri)
                .header(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .proxy(proxyHost, proxyPort)
                .body(AuthLogin.builder().username(user).password(pass).build())
                .asObject(AuthSession.class)
                .getBody();


        log.info("[AUTH] Part 2/3 ~ Authorizing User");
        HttpResponse<String> response = Unirest
                .get(authorizeUri)
                .proxy(proxyHost, proxyPort)
                .queryString(CLIENT_ID_FIELD, CLIENT_ID)
                .queryString(CODE_CHALLENGE_FIELD, CODE_CHALLENGE)
                .queryString(CODE_CHALLENGE_METHOD_FIELD, CODE_CHALLENGE_METHOD)
                .queryString(REDIRECT_URI_FIELD, REDIRECT_URI)
                .queryString(RESPONSE_TYPE_FIELD, RESPONSE_TYPE)
                .queryString(SESSION_TOKEN_FIELD, authSession.getSessionToken())
                .queryString(STATE_FIELD, UUID.randomUUID())
                .asString();
        String locationCode = response.getHeaders().get("location").get(0).split("code=")[1].split("&")[0];


        log.info("[AUTH] Part 3/3 ~ Generating Auth Token");
        AuthToken authToken = Unirest.post(authTokenUri)
                .header(CONTENT_TYPE, APPLICATION_FORM_URLENCODED_VALUE)
                .field(CLIENT_ID_FIELD, CLIENT_ID)
                .field(CODE_FIELD, locationCode)
                .field(CODE_VERIFIER_FIELD, CODE_VERIFIER)
                .field(GRANT_TYPE_FIELD, GRANT_TYPE)
                .field(REDIRECT_URI_FIELD, REDIRECT_URI)
                .proxy(proxyHost, proxyPort)
                .asObject(AuthToken.class)
                .getBody();


        log.info("[AUTH] Returning Auth Token");
        return authToken.getToken();
    }
}

package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.util.List;

/**
 * Benefit Details Model
 *
 * @author NV
 * @since 5/25/2023
 */
@Data public class BenefitDetails {
    private Boolean referralRequired;
    private String networkCoverageKeyCode;
    private String ccnTierCode;
    private String nonReviewedSpecialityTierCode;
    private Boolean ppacaBenefit;
    @JsonAlias("benefitNetworks") private List<BenefitNetwork> benefitNetworkList;
}

package com.esrx.smart.data.feature.coverage.medical.coveragesummeries;

import com.esrx.smart.data.common.name.Name;
import lombok.Data;

import java.util.List;

/**
 * Coverage Family Members POJO
 *
 * @author C7H4X4
 *
 */
@Data
public class FamilyMember {
    private String customerId;
    private String dateOfBirth;
    private boolean loggedInUser;
    private String coverageStatus;
    private String displayRank;
    private Name name;
    private RelationshipToSubscriber relationshipToSubscriber;
    private List<CoveragePeriod> coveragePeriods;

}

package com.esrx.smart.data.feature.coverage.medical.detail;

import com.esrx.smart.data.feature.coverage.medical.detail.benefit.BenefitDetailsRes;
import com.esrx.smart.data.feature.coverage.medical.detail.service.ServiceCategoriesRes;
import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * Medical Services Resource
 *
 * @author NV
 * @since 5/17/2023
 */
@Log4j2 @Service @RestController
public class ServiceBenefitDetailResource {

    @Value("${coverage.service.categories.resource}") String serviceCatsUri;
    @Value("${coverage.medical.benefit.details.resource}") String medBenefitDetailsUri;

    @Value("${coverage.medical.accum.resource}") String medAccumUri;
    @Value("${coverage.medical.accum.fam.resource}") String famAccumUri;

    @Value("${proxy.port}") private int proxyPort;
    @Value("${proxy.host}") private String proxyHost;

    private static final String CATEGORY_CODE = "categoryCode";
    private static final String PRODUCT_TYPE = "productGroupType";
    private static final String BENEFIT_SERVICE_ID = "benefitServiceId";


    @GetMapping("getServiceCats")
    public Optional<ServiceCategoriesRes> getServiceCategories(
            @RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType) {
        log.info("[MED.DETAIL.SVC] Retrieving Service Categories");
        return Optional.ofNullable(Unirest.get(serviceCatsUri)
                .header(HttpHeaders.AUTHORIZATION, authBearerToken)
                .queryString(PRODUCT_TYPE, productGroupType.toUpperCase())
                .proxy(proxyHost, proxyPort)
                .asObject(ServiceCategoriesRes.class)
                .getBody());
    }

    @GetMapping("getBenefitDetails")
    public Optional<BenefitDetailsRes> getBenefitDetails(
            @RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken,
            @RequestParam(value = "categoryCode", defaultValue = "DV") String categoryCode,
            @RequestParam(value = "benefitServiceId", defaultValue = "PCP") String benefitServiceId,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType) {
        log.info("[MED.DETAIL.BEN] Retrieving Benefit Details");
        log.info("[MED.DETAIL.BEN] authBearerToken={}", authBearerToken);
        log.info("[MED.DETAIL.BEN] categoryCode={}", categoryCode);
        log.info("[MED.DETAIL.BEN] benefitServiceId={}", benefitServiceId);
        log.info("[MED.DETAIL.BEN] productGroupType={}", productGroupType);
        return Optional.ofNullable(Unirest.get(medBenefitDetailsUri)
                .header(HttpHeaders.AUTHORIZATION, authBearerToken)
                .queryString(CATEGORY_CODE, categoryCode)
                .queryString(PRODUCT_TYPE, productGroupType.toUpperCase())
                .queryString(BENEFIT_SERVICE_ID, benefitServiceId)
                .proxy(proxyHost, proxyPort)
                .asObject(BenefitDetailsRes.class)
                .getBody());
    }
}

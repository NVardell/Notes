package com.esrx.smart.data.common.fhir.org;

import com.esrx.smart.data.common.fhir.FhirResource;
import com.esrx.smart.data.common.fhir.coverage.FhirIdentifier;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * FHIR Organization Model
 *
 * @author NV
 * @since 6/9/2023
 */
@EqualsAndHashCode(callSuper = true)
@Data @Builder public class FhirOrganization extends FhirResource {
    private String name;
    private List<FhirContact> contact;
    private List<FhirIdentifier> identifier;
}

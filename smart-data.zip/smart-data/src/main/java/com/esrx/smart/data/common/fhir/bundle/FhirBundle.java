package com.esrx.smart.data.common.fhir.bundle;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * FHIR Bundle Model
 *
 *      Bundle Type: Indicates how the Bundle can/should be used.
 *          ~ https://www.hl7.org/fhir/codesystem-bundle-type.html
 *
 * @author NV
 * @since 6/12/2023
 */
@JsonPropertyOrder({ "resourceType", "type", "entry" })
@Data @Builder public class FhirBundle {
    @JsonProperty("resourceType") private final String resourceType = "Bundle";
    @JsonProperty("type") private final String type = "collection";
    private List<FhirEntry> entry;
}

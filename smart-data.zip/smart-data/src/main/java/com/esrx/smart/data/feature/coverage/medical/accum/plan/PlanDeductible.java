package com.esrx.smart.data.feature.coverage.medical.accum.plan;

import lombok.Data;

/**
 * Plan Deductible Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data public class PlanDeductible {
    private String crossAccumulationsType;
    private Boolean accumulatorMet;
    private Boolean collectiveIndicator;
    private String collectiveTypeCode;
    private Double metAmount;
    private Double targetAmount;
    private Double remainingAmount;
}

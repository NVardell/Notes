package com.esrx.smart.data.common.fhir.coverage;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * FHIR Cost Beneficiary Model
 *
 * @author NV
 * @since 6/9/2023
 */
@Data @Builder
@AllArgsConstructor(staticName = "of")
public class FhirCostToBeneficiaryComponent {
    private FhirType type;
    private FhirMoney valueMoney;
}

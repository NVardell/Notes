package com.esrx.smart.data.common.fhir;

import lombok.Getter;
import lombok.Setter;

/**
 * FHIR Resource Model
 *
 * @author NV
 * @since 6/12/2023
 */
@Getter @Setter
public class FhirResource {
    public String resourceType;
}

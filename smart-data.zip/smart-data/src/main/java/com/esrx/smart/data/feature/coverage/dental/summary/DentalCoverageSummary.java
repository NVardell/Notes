package com.esrx.smart.data.feature.coverage.dental.summary;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

/**
 * Dental Coverage Summary Model
 *
 * @author NV
 * @since 6/9/2023
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DentalCoverageSummary {
    private String planName;
    private String planType;
    private String groupId;
    private Boolean suppressSummary;
    private List<DentalFamilyMember> familyMembers;
    private Boolean hasThreeTier;
    private String dhmoPdfKey;
    private NetworkDetail networkDetails;
    private Boolean adminHold;
}

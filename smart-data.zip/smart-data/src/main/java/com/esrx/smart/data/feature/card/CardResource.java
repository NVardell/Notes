package com.esrx.smart.data.feature.card;

import com.esrx.smart.data.feature.card.products.CardMember;
import com.esrx.smart.data.feature.card.products.CardProduct;
import com.esrx.smart.data.feature.card.products.CardProductsRes;
import com.esrx.smart.data.feature.card.products.CardProductsResource;
import com.esrx.smart.data.feature.coverage.summary.CardProductSummary;
import com.esrx.smart.data.util.CollectorUtil;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

/**
 * ID Card Resources
 *
 * @author NV
 * @since 5/11/2023
 */
@Log4j2
@RestController
public class CardResource {

    @Autowired CardProductsResource cardProductsResource;


    @GetMapping("getCardProducts")
    public Optional<CardProductSummary> getCardProducts(
            @RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType) {
        log.info("[CARD] Retrieving Card Products for Group = {}", productGroupType);
        CardProductSummary cardProductSummary = CardProductSummary.builder().build();

        // Retrieve Member ID Card Products
        Optional<CardProductsRes> cardProductsRes = cardProductsResource.getCardProductIds(authBearerToken);
        log.info("[CARD] Card Product Response = {}", cardProductsRes);

        cardProductsRes.ifPresent(cardProductsResResponse -> {
            // Extract Current Logged-In User from Family Member List
            List<CardMember> cardMembersList = cardProductsResResponse.getFamilyMembers();

            if(cardMembersList != null){
                CardMember currentMember = cardMembersList
                        .stream()
                        .filter(CardMember::getIsLoggedInUser)
                        .collect(CollectorUtil.toSingleton());
                log.info("[CARD] Current Member - {}", currentMember);

                // Populate Summary Fields for Current Member
                cardProductSummary.setAge(currentMember.getAge());
                cardProductSummary.setName(currentMember.getName());
                cardProductSummary.setFullName(currentMember.getName().getFullName());
                cardProductSummary.setDateOfBirth(currentMember.getDateOfBirth());
                cardProductSummary.setRelationshipToSubscriber(currentMember.getRelationshipToSubscriberCode());

                // Extract Card Product for Specific Product Group Type (MED/DENT/VIS/etc.)
                log.info("[CARD] Current Member Card Products = {}", currentMember.getProducts());
                CardProduct cardProduct = currentMember.getProducts()
                        .stream()
                        .filter(product -> product.getType().contains(productGroupType.toUpperCase()))
                        .collect(CollectorUtil.toSingleton());
                log.info("[CARD] Current Member Card Product = {}", cardProduct);

                // Populate Summary Fields for Current Member Card Product
                if(cardProduct != null){
                    cardProductSummary.setUserAmiId(cardProduct.getAmi());
                    cardProductSummary.setCardExtension(cardProduct.getIdCardExtensionCode());
                    cardProductSummary.setCoverageStatus(cardProduct.getCoverageStatus());
                    cardProductSummary.setCoverageEffectiveDate(cardProduct.getCoverageEffectiveDate());
                    cardProductSummary.setCoverageEndDate(cardProduct.getCoverageEndDate());
                    cardProductSummary.setProductGroupType(cardProduct.getType());
                    cardProductSummary.setState(cardProduct.getSitusState());
                    if(cardProduct.getRequestIDCardData() != null)
                        cardProductSummary.setMemberIdentifier(cardProduct.getRequestIDCardData().getMemberIdentifier());
                }
            }
        });

        return Optional.ofNullable(cardProductSummary);
    }
}

package com.esrx.smart.data.feature.coverage.summary;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

/**
 * Coverage Resource Parent Summary Model
 *
 * @author NV
 * @since 6/2/2023
 */
@Data @Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CoverageSummary {
    CardProductSummary cardProductSummary;
    MedicalCoverageSummary medicalCoverageSummary;
    MedicalAccumSummary medicalAccumSummary;
    MedicalServiceDetailSummary medicalServiceDetailSummary;
    DentalSummary dentalSummary;
    PharmaSummary pharmaSummary;
    VisionSummary visionSummary;

    /*
      Maybe....
         DentalSummary dentalSummary;
         VisionSummary visionSummary;
         PharmaSummary pharmaSummary;

      Or...
         This might change entirely to be match the object format Nava requested.
            ~ https://git.express-scripts.com/ExpressScripts/smart-health-data-services/blob/develop/src/main/java/com/esrx/smarthealth/hibernate/entity/MedicalBenefits.java

         I kind of like the idea of having both though, now that I think about it.
         Primarily, because there seems to be a lot of useful info in summaries that is not currently in that object.
    */
}

package com.esrx.smart.data.feature.coverage.vision.summary;

import com.esrx.smart.data.common.name.Name;
import lombok.Data;
@Data
public class FamilyMember {
    private Name name;
    private String dateOfBirth;
    private String relationshipToSubscriberCode;
    private Boolean loggedInUser;
    private String coverageStatus;
    private Boolean delegate;
    private String coverageEffectiveDate;
    private String coverageCancelDate;
    private String displayRank;
    private Boolean pediatricRestriction;
}

package com.esrx.smart.data.util;

import lombok.extern.log4j.Log4j2;

import java.util.stream.Collector;
import java.util.stream.Collectors;

/**
 * Stream Collector Util
 *
 * @author NV
 * @since 5/31/2023
 */
@Log4j2
public class CollectorUtil {
    public static <T> Collector<T, ?, T> toSingleton() {
        return Collectors.collectingAndThen(
                Collectors.toList(),
                list -> {
                    if (list.size() > 1)
                        log.warn("[UTIL.COLLECT] Collector Util found multiple matches. Total={}", list.size());
                    if(list.size() < 1) {
                        log.error("[UTIL.COLLECT] Collector Util found zero matches.");
                        return null;
                    }
                    return list.get(0);
                }
        );
    }
}

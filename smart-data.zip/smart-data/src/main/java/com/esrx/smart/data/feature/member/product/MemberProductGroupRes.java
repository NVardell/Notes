package com.esrx.smart.data.feature.member.product;

import com.esrx.smart.data.common.meta.Metadata;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

/**
 * Member Product Group Response Model
 *
 * @author NV
 * @since 6/16/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data public class MemberProductGroupRes {
    private @JsonAlias("customerproductgroups") List<MemberProductGroup> memberProductGroups;
    private Metadata metadata;
}

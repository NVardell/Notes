package com.esrx.smart.data.util.helper;

import com.esrx.smart.data.common.fhir.bundle.FhirBundle;
import com.esrx.smart.data.common.fhir.bundle.FhirCredential;
import com.esrx.smart.data.common.fhir.bundle.FhirEntry;
import com.esrx.smart.data.common.fhir.bundle.FhirJwtPayload;
import com.esrx.smart.data.common.fhir.bundle.FhirSubject;
import com.esrx.smart.data.common.fhir.coverage.FhirCoverage;
import com.esrx.smart.data.common.fhir.org.FhirOrganization;
import com.esrx.smart.data.common.fhir.patient.FhirPatient;
import lombok.experimental.UtilityClass;
import lombok.extern.log4j.Log4j2;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * FHIR Bundler Util
 *
 * @author NV
 * @since 6/12/2023
 */
@Log4j2 @UtilityClass public class FhirBundlerUtil {

    private static final String[] CREDENTIAL_TYPES = { "https://smarthealth.cards#health-card"};
    private static final String FHIR_VERSION = "4.0.1";
    private static final String RESOURCE_PREFIX = "resource:";
    private static final String JWT_ISSUER = "https://www.cigna.com/SHCKeys/main";


    public FhirJwtPayload toJwtPayload(FhirPatient patient, FhirCoverage coverage, FhirOrganization organization) {
        log.info("[UTIL.FHIR.BUNDLE] Generating FHIR Payload");
        return FhirJwtPayload.builder()
                .issuer(JWT_ISSUER)
                .notBefore(BigDecimal.valueOf(Instant.now().getEpochSecond()))
                .credential(FhirCredential.of(CREDENTIAL_TYPES, FhirSubject.of(FHIR_VERSION, toFhirBundle(patient, coverage, organization))))
                .build();
    }

    private FhirBundle toFhirBundle(FhirPatient patient, FhirCoverage coverage, FhirOrganization organization) {
        log.info("[UTIL.FHIR.BUNDLE] Generating FHIR Bundle");
        AtomicInteger resourceIndex = new AtomicInteger();

        // Bundle FHIR Coverage, Patient, & Organization Objects
        FhirBundle bundle = FhirBundle.builder()
                .entry(Arrays.asList(
                        FhirEntry.of(RESOURCE_PREFIX + resourceIndex.get(), coverage),
                        FhirEntry.of(RESOURCE_PREFIX + resourceIndex.incrementAndGet(), patient),
                        FhirEntry.of(RESOURCE_PREFIX + resourceIndex.incrementAndGet(), organization)))
                .build();

        // Update Reference Values
        bundle.getEntry().forEach(entry-> {
            if(entry.getResource() instanceof FhirCoverage) {
                ((FhirCoverage) entry.getResource()).getPayor().get(0).setReference(entry.getFullUrl());
                ((FhirCoverage) entry.getResource()).getSubscriber().setReference(entry.getFullUrl());
                ((FhirCoverage) entry.getResource()).getBeneficiary().setReference(entry.getFullUrl());
            }
        });

        return bundle;
    }
}

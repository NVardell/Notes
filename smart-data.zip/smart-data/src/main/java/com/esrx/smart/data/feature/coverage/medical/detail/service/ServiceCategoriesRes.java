package com.esrx.smart.data.feature.coverage.medical.detail.service;

import com.esrx.smart.data.common.meta.Metadata;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

/**
 * Service Categories Response Model
 *
 * @author NV
 * @since 5/24/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data public class ServiceCategoriesRes {
    private List<ServiceCategory> serviceCategories;
    private Metadata metadata;
}

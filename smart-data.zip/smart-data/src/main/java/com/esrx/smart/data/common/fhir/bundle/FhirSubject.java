package com.esrx.smart.data.common.fhir.bundle;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * FHIR Subject Model
 *
 * @author NV
 * @since 6/12/2023
 */
@AllArgsConstructor(staticName = "of")
@Data @Builder public class FhirSubject {
    private String fhirVersion;
    private FhirBundle fhirBundle;
}

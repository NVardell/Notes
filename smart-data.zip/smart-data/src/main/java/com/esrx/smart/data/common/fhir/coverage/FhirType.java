package com.esrx.smart.data.common.fhir.coverage;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * FHIR Type Model
 *
 * @author NV
 * @since 6/9/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor(staticName = "of")
@Data @Builder public class FhirType {
    private List<FhirCoding> coding;
    private String text;
}

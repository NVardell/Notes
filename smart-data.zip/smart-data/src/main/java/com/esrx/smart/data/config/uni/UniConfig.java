package com.esrx.smart.data.config.uni;

import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * UniRest Config
 *
 * @author Nate Vardell
 * @since 7/1/2019
 */
@Log4j2
@Component
public class UniConfig {

    @PostConstruct
    public void init() {
        log.info("Configuring Uni.");

        Unirest.config()
                // Setup Metrics
                .instrumentWith(requestSummary -> {
                    long startNano = System.nanoTime();
                    return (responseSummary, exception) -> {
                        if(exception != null)
                            log.error("exception:{} message:{}", exception.getCause(), exception.getMessage());
                        else
                            log.info("time:{} path:{} status:{} message:{}",
                                System.nanoTime() - startNano,
                                requestSummary.getRawPath(),
                                responseSummary.getStatus(),
                                responseSummary.getStatusText());
                    };
                })
                .enableCookieManagement(false)
                .followRedirects(false)
                .connectTimeout(15000)
                // Set Custom Object Mapper
                .setObjectMapper(new UniObjectMapper());
    }
}

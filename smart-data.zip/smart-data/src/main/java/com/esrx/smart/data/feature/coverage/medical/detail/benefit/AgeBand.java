package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import lombok.Data;

import java.util.List;

/**
 * Benefit Details Age Band Model
 *
 * @author NV
 * @since 5/25/2023
 */
@Data public class AgeBand {
    private int displayRank;
    private int minAge;
    private int maxAge;
    private List<RangeBand> rangeBands;
}

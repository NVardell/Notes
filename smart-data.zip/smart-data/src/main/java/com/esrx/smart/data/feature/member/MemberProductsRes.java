package com.esrx.smart.data.feature.member;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Member Products Response Model
 *
 * @author NV
 * @since 6/21/2023
 */
@Data @Builder public class MemberProductsRes {
    private List<String> memberProducts;
}

package com.esrx.smart.data.feature.coverage.medical.accum.family;

import lombok.Data;

import java.util.List;

/**
 * Accumulation Family Members Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data public class AccumFamMembers {
    private List<AccumPeriod> accumulationPeriods;
}

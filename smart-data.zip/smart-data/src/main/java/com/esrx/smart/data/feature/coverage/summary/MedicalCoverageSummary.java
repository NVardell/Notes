package com.esrx.smart.data.feature.coverage.summary;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

/**
 * Medical Coverage Summary Model
 *
 * @author NV
 * @since 5/18/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data @Builder public class MedicalCoverageSummary {
    private String groupId;
    private String groupName;
    private String networkId;
    private String networkName;
    private String planId;
    private String planName;
}

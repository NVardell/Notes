package com.esrx.smart.data.util.helper;

import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.zip.Deflater;

/**
 * Smart Card Util
 *
 * @author NV
 * @since 6/12/2023
 */
@Log4j2
@Service public class SmartCardUtil {

    @Autowired JwtSignUtil jwtSignUtil;

    public String getJsonWebSignature(String fhirJwtPayload) {
        log.info("[UTIL.SMART] Getting JSON Web Signature");
        return jwtSignUtil.getSignedJwt(deflatePayload(fhirJwtPayload));
    }

    @SneakyThrows private byte[] deflatePayload(String fhirJwtPayload) {
        log.info("[UTIL.SMART] Deflating Bundled FHIR Payload for Signing");
        final Deflater deflater = new Deflater(Deflater.DEFAULT_COMPRESSION, true);

        byte[] data = fhirJwtPayload.getBytes(StandardCharsets.UTF_8);
        deflater.setInput(data);

        try (final ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length)) {
            deflater.finish();
            final byte[] buffer = new byte[1024];

            while (!deflater.finished()) {
                int count = deflater.deflate(buffer);
                outputStream.write(buffer, 0, count);
            }
            return outputStream.toByteArray();
        } catch (IOException ioException) {
            log.error("Failed to deflate the FHIR payload: " + ioException.getMessage());
            throw new Exception("Unable to create Smart Health Card", ioException);
        }
    }
}

package com.esrx.smart.data.common.fhir.bundle;

import com.esrx.smart.data.common.fhir.FhirResource;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * FHIR Entry Model
 *
 * @author NV
 * @since 6/12/2023
 */
@AllArgsConstructor(staticName = "of")
@Data @Builder public class FhirEntry {
    private String fullUrl;
    private FhirResource resource;
}

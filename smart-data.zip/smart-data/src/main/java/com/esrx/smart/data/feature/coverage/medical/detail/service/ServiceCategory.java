package com.esrx.smart.data.feature.coverage.medical.detail.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

/**
 * Service Categories Model
 *
 * @author NV
 * @since 5/24/2023
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceCategory {
    private String categoryCode;
    private int categoryDisplayRank;
    private Boolean virtualInd;
    private String vendorName;
    private String vendorContactTelephoneNumber;
    private List<ServiceBenefit> serviceBenefits;
}

package com.esrx.smart.data.common.fhir.coverage;

import com.esrx.smart.data.common.fhir.patient.FhirName;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * FHIR Extension Model
 *
 * @author NV
 * @since 6/9/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data @Builder public class FhirExtension {
    private String url;
    private String valueString;
    private String valueId;
    private FhirName valueHumanName;
    private FhirValueAnnotation valueAnnotation;
    private String valueDate;
    private List<FhirExtension> extension;
}

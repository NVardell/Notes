package com.esrx.smart.data.feature.coverage.medical.accum.family;

import lombok.Data;

import java.util.List;

/**
 * Accumulation Period Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data public class AccumPeriod {
    private String accumulationBeginDate;
    private String accumulationEndDate;
    private String accumulationPeriodTypeCode;
    private Boolean coverageDetailsUnavailable;
    private String sourceSystemLocationCode;
    private String subscriberId;
    private String claimSystemCode;
    private Boolean collectiveAccumulations;
    private Boolean planAccumulators;
    private List<AccumNetwork> accumulationNetworkCategories;
    private Boolean familyCovered;
    private List<AccumFamMember> familyMembers;
}

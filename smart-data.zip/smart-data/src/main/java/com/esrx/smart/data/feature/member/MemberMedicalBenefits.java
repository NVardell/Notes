package com.esrx.smart.data.feature.member;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

/**
 * Medical Benefits Model
 *
 * @author NV
 * @since 6/7/2023
 */
@Data @Builder
@JsonInclude(JsonInclude.Include.NON_NULL) public class MemberMedicalBenefits {
    // Card Product Summary
    private Member member;
    private String state;
    private String medialBenefitId;
    private String coverageEffDate;

    // Medical Coverage Summary
    private String groupId;
    private String planName;

    // Medical Accumulation Summary
    private Double inNetworkDedFam;
    private Double inNetworkDedInd;
    private Double inNetworkOopFam;
    private Double inNetworkOopInd;
    private Double outNetworkDedFam;
    private Double outNetworkDedInd;
    private Double outNetworkOopFam;
    private Double outNetworkOopInd;

    // Medical Service Detail Summary
    private String inNetworkCoInsurance;
    private String outNetworkCoInsurance;

    private String rx;
    private String rxBin;
    private String rxGroup;
    private String rxPcn;

    private Double pcpVisit;
    private Double specialist;
    private Double urgentCare;
    private String hospitalEr;
    private String erNotTrueEmergency;
    private String erTrueEmergency;

    private String custServiceNo;
    private String sendClaimAddr1;
    private String sendClaimAddr2;
    private String sendClaimZipCode;

    private String additionalInfo;
}

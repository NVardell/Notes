package com.esrx.smart.data.feature.smart;

import com.esrx.smart.data.common.shLink.SHLink;
import com.esrx.smart.data.feature.member.MemberMedicalBenefits;
import com.esrx.smart.data.feature.member.MemberQrRes;
import com.esrx.smart.data.util.FhirUtil;
import com.esrx.smart.data.util.QrUtil;
import com.esrx.smart.data.util.SHLinkUtil;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

/**
 * Smart Health Data Service Implementations
 *
 * @author NV
 * @since 6/14/2023
 */
@Log4j2 @Component
public class SmartHealthDataSvcImpl implements SmartHealthDataSvc {

    @Autowired SHLinkUtil shLinkUtil;
    @Autowired FhirUtil fhirUtil;
    @Autowired QrUtil qrUtil;


    @Override
    public String getFhirBundle(MemberMedicalBenefits memberMedicalBenefits, Boolean encrypt) {
        log.info("[SMART.HEALTH.SVC] Starting FHIR Bundling");
        return fhirUtil.getFhirBundle(memberMedicalBenefits, encrypt);
    }

    @Override
    public SHLink getSHLinkPayload(MemberMedicalBenefits memberMedicalBenefits, String flag, Boolean isLocal, Boolean doEncrypt) {
        log.info("[SMART.HEALTH.SVC] Starting SH Link Generation");
        return shLinkUtil.getSHLinkPayload(memberMedicalBenefits, flag, isLocal, doEncrypt);
    }

    @Override
    public byte[] getQrCodeImage(SHLink shLink) {
        log.info("[SMART.HEALTH.SVC] Starting QR Generation");
        return qrUtil.getQrCodeImage(shLink);
    }

    @Override
    public MemberQrRes getQrCodeImagePath(SHLink shLink) {
        log.info("[SMART.HEALTH.SVC] Starting QR Generation");
        return qrUtil.getQrCodeImagePath(shLink);
    }

    @Override
    public SHLink verifyQrCode(MultipartFile qrImage, Boolean decrypt) {
        log.info("[SMART.HEALTH.SVC] Verify QR Code");
        return qrUtil.verifyQrCode(qrImage, decrypt);
    }
}

package com.esrx.smart.data.feature.member;

import com.esrx.smart.data.common.shLink.SHLink;
import com.esrx.smart.data.feature.coverage.CoverageResource;
import com.esrx.smart.data.feature.coverage.medical.detail.benefit.Benefit;
import com.esrx.smart.data.feature.coverage.summary.CardProductSummary;
import com.esrx.smart.data.feature.coverage.summary.CoverageSummary;
import com.esrx.smart.data.feature.coverage.summary.DentalSummary;
import com.esrx.smart.data.feature.coverage.summary.MedicalAccumSummary;
import com.esrx.smart.data.feature.coverage.summary.MedicalCoverageSummary;
import com.esrx.smart.data.feature.coverage.summary.MedicalServiceDetailSummary;
import com.esrx.smart.data.feature.coverage.summary.PharmaSummary;
import com.esrx.smart.data.feature.coverage.summary.VisionSummary;
import com.esrx.smart.data.feature.member.product.MemberProductGroupRes;
import com.esrx.smart.data.feature.member.product.MemberProductGroupResource;
import com.esrx.smart.data.feature.smart.SmartHealthDataSvc;
import com.esrx.smart.data.util.AuthResourceUtil;
import com.esrx.smart.data.util.CollectorUtil;
import com.esrx.smart.data.util.FileUtil;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Member Resource
 *
 * @author NV
 * @since 6/8/2023
 */
@Log4j2
@RestController public class MemberResource {

    @Autowired private CoverageResource coverageResource;
    @Autowired private MemberProductGroupResource memberProductGroupResource;
    @Autowired private SmartHealthDataSvc smartHealthDataSvc;
    @Autowired private AuthResourceUtil authResourceUtil;
    @Autowired private FileUtil fileUtil;

    private static final String ACTIVE_COVERAGE = "Active";
    private static final List<String> products = Arrays.asList("DENT", "MED", "PDP", "VIS");

    @GetMapping("getMemberProducts")
    public MemberProductsRes getMemberProducts(
            @RequestParam(value = "username", defaultValue = "${test.user.med}") String user,
            @RequestParam(value = "password", defaultValue = "${test.pass}") String pass){
        log.info("[MEMBER.PRODUCTS] Retrieving Member Products");

        // List of Member Products
        List<String> memberProductGroups = new ArrayList<>();

        // Retrieve JWT
        log.info("[MEMBER.PRODUCTS] Retrieving JWT Token for Coverage Calls");
        String bearerToken = authResourceUtil.getAuthToken(user, pass);

        // Get Member Products
        Optional<MemberProductGroupRes> memberProductGroupRes = memberProductGroupResource.getMemberProductGroups(bearerToken);
        log.info("[MEMBER.PRODUCTS] Retrieved Member Product Groups - {}", memberProductGroupRes);

        // Add Product Groups to Return
        memberProductGroupRes.ifPresent(memberProductGroupResponse -> {
            memberProductGroupResponse.getMemberProductGroups()
                    .forEach(memberProductGroup -> {
                        String productGroup = memberProductGroup.getProductGroupType();
                        if(products.contains(productGroup) && memberProductGroup.getCoverageStatus().equals(ACTIVE_COVERAGE))
                            memberProductGroups.add(productGroup);
                    });
        });

        return MemberProductsRes.builder()
                .memberProducts(memberProductGroups)
                .build();
    }


    @GetMapping("getMemberMedicalBenefits")
    public MemberMedicalBenefits getMemberMedicalBenefits(
            @RequestParam(value = "username", defaultValue = "${test.user.med}") String user,
            @RequestParam(value = "password", defaultValue = "${test.pass}") String pass,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType) {

        MemberMedicalBenefits memberMedicalBenefits = MemberMedicalBenefits.builder().build();

        log.info("[MEMBER.MED] Retrieving Coverage Details");
        Optional<CoverageSummary> getCoverageDetails = coverageResource.getCoverageDetails(user, pass, productGroupType);

        getCoverageDetails.ifPresent(coverageDetails -> {

            // Set Member Details from Card Product Summary
            CardProductSummary cardProductSummary = coverageDetails.getCardProductSummary();
            memberMedicalBenefits.setMember(Member.builder()
                    .memberId(cardProductSummary.getUserAmiId())
                    .name(cardProductSummary.getName())
                    .personId(cardProductSummary.getCardExtension())
                    .dateOfBirth(cardProductSummary.getDateOfBirth()) // .dateOfBirth(LocalDate.parse(cardProductSummary.getDateOfBirth(), DateTimeFormatter.ofPattern("MM/d/yyyy")))
                    .build());
            memberMedicalBenefits.setState(cardProductSummary.getState());
            memberMedicalBenefits.setMedialBenefitId(cardProductSummary.getMemberIdentifier());
            memberMedicalBenefits.setCoverageEffDate(cardProductSummary.getCoverageEffectiveDate());

            // Set Member Benefits Based On Product Type
            if("MED".equals(productGroupType)) {
                log.info("[MEMBER.MED] Adding Benefit Details for Product = {}", productGroupType);

                // Set Member Medical Benefit Details from Coverage Summary
                MedicalCoverageSummary coverageSummary = coverageDetails.getMedicalCoverageSummary();
                if(coverageSummary != null) {
                    memberMedicalBenefits.setGroupId(coverageSummary.getGroupId());

                    if (coverageSummary.getPlanName() != null) // Not all responses have a plan name
                        memberMedicalBenefits.setPlanName(coverageSummary.getPlanName());
                    else
                        memberMedicalBenefits.setPlanName(coverageSummary.getPlanId());
                }

                // Set Member Medical Benefit Details from Medical Accum Summary
                MedicalAccumSummary medicalAccumSummary = coverageDetails.getMedicalAccumSummary();

                if(medicalAccumSummary != null) {
                    memberMedicalBenefits.setInNetworkDedFam(medicalAccumSummary.getInNetworkFamilyDeductible());
                    memberMedicalBenefits.setInNetworkDedInd(medicalAccumSummary.getInNetworkIndividualDeductible());
                    memberMedicalBenefits.setInNetworkOopFam(medicalAccumSummary.getInNetworkFamilyOutOfPocket());
                    memberMedicalBenefits.setInNetworkOopInd(medicalAccumSummary.getInNetworkIndividualOutOfPocket());
                    memberMedicalBenefits.setOutNetworkDedFam(medicalAccumSummary.getOutNetworkFamilyDeductible());
                    memberMedicalBenefits.setOutNetworkDedInd(medicalAccumSummary.getOutNetworkIndividualDeductible());
                    memberMedicalBenefits.setOutNetworkOopFam(medicalAccumSummary.getOutNetworkFamilyOutOfPocket());
                    memberMedicalBenefits.setOutNetworkOopInd(medicalAccumSummary.getOutNetworkIndividualOutOfPocket());
                }

                // Set Member Medical Benefit Details from Medical Service Benefit Summary
                MedicalServiceDetailSummary medicalServiceDetailSummary = coverageDetails.getMedicalServiceDetailSummary();

                if(medicalServiceDetailSummary != null) {
                    Benefit benefit = medicalServiceDetailSummary.getBenefitList()
                            .stream()
                            .filter(b -> ("MED").equals(b.getProductGroupType()))
                            .filter(b -> ("DV").equals(b.getCategoryCode()))
                            .filter(b -> ("PCP").equals(b.getBenefitServiceId()) || ("OVCW").equals(b.getBenefitServiceId()))
                            .collect(CollectorUtil.toSingleton());
                    memberMedicalBenefits.setInNetworkCoInsurance(benefit.getInNetworkCoinsurance());
                    memberMedicalBenefits.setOutNetworkCoInsurance(benefit.getOutOfNetworkCoinsurance());
                }
            } else if ("DENT".equals(productGroupType)) {
                log.info("[MEMBER.MED] Adding Benefit Details for Product = {}", productGroupType);
                DentalSummary dentalSummary = coverageDetails.getDentalSummary();
                memberMedicalBenefits.setPlanName(dentalSummary.getPlanName());
                memberMedicalBenefits.setGroupId(dentalSummary.getGroupId());
            } else if ("PDP".equals(productGroupType)) {
                log.info("[MEMBER.MED] Adding Benefit Details for Product = {}", productGroupType);
                PharmaSummary pharmaSummary = coverageDetails.getPharmaSummary();
                memberMedicalBenefits.setPlanName(pharmaSummary.getPlanName());
                memberMedicalBenefits.setGroupId(pharmaSummary.getGroupId());
            } else if ("VIS".equals(productGroupType)) {
                log.info("[MEMBER.MED] Adding Benefit Details for Product = {}", productGroupType);
                VisionSummary visionSummary = coverageDetails.getVisionSummary();
                memberMedicalBenefits.setPlanName(visionSummary.getVisionType());
                memberMedicalBenefits.setGroupId(visionSummary.getGroupId());
            }
        });

        return memberMedicalBenefits;
    }


    @GetMapping("getSmartHealthLinkPayload") public SHLink getSmartHealthLinkPayload(
            @RequestParam(value = "username", defaultValue = "${test.user.med}") String user,
            @RequestParam(value = "password", defaultValue = "${test.pass}") String pass,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType,
            @RequestParam(value = "shFlag", defaultValue = "L") String shFlag,
            @RequestParam(value = "encrypt", defaultValue = "false") Boolean encrypt,
            @RequestParam(value = "isLocal", defaultValue = "true") Boolean isLocal) {

        log.info("[MEMBER.SH-LINK] Get Smart Health Link Payload");

        // Get Member Details
        MemberMedicalBenefits memberMedicalBenefits = getMemberMedicalBenefits(user, pass, productGroupType);
        log.info("[MEMBER.SH-LINK] Retrieved Member Medical Benefits");

        // Get SH Link & Return
        return smartHealthDataSvc.getSHLinkPayload(memberMedicalBenefits, shFlag, isLocal, encrypt);
    }


    @SneakyThrows
    @GetMapping(path="getSmartHealthQRImage", produces = MediaType.IMAGE_PNG_VALUE) public byte[] getSmartHealthQRImage(
            @RequestParam(value = "username", defaultValue = "${test.user.med}") String user,
            @RequestParam(value = "password", defaultValue = "${test.pass}") String pass,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType,
            @RequestParam(value = "shFlag", defaultValue = "L") String shFlag,
            @RequestParam(value = "encrypt", defaultValue = "false") Boolean encrypt,
            @RequestParam(value = "isLocal", defaultValue = "true") Boolean isLocal) {

        log.info("[MEMBER.QR.IMAGE] Get Smart Health QR");

        // Get Member Details
        MemberMedicalBenefits memberMedicalBenefits = getMemberMedicalBenefits(user, pass, productGroupType);
        log.info("[MEMBER.QR.IMAGE] Retrieved Member Medical Benefits");

        // Get SH Link
        SHLink shLink = smartHealthDataSvc.getSHLinkPayload(memberMedicalBenefits, shFlag, isLocal, encrypt);
        log.info("[MEMBER.QR.IMAGE] Retrieved Smart Health Link. SH Link = {}", shLink.toString());

        // Generate & Return QR
        return smartHealthDataSvc.getQrCodeImage(shLink);
    }


    @SneakyThrows
    @GetMapping(path="getSmartHealthQRImagePath") public MemberQrRes getSmartHealthQRImagePath(
            @RequestParam(value = "username", defaultValue = "${test.user.med}") String user,
            @RequestParam(value = "password", defaultValue = "${test.pass}") String pass,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType,
            @RequestParam(value = "shFlag", defaultValue = "L") String shFlag,
            @RequestParam(value = "encrypt", defaultValue = "false") Boolean encrypt,
            @RequestParam(value = "isLocal", defaultValue = "true") Boolean isLocal) {

        log.info("[MEMBER.QR.PATH] Get Smart Health QR Image Path");

        // Get Member Details
        MemberMedicalBenefits memberMedicalBenefits = getMemberMedicalBenefits(user, pass, productGroupType);
        log.info("[MEMBER.QR.PATH] Retrieved Member Medical Benefits");

        // Get SH Link
        SHLink shLink = smartHealthDataSvc.getSHLinkPayload(memberMedicalBenefits, shFlag, isLocal, encrypt);
        log.info("[MEMBER.QR.PATH] Retrieved Smart Health Link. SH Link = {}", shLink.toString());

        // Get QR Code Image Bytes/Path & Return Member QR Response
        return smartHealthDataSvc.getQrCodeImagePath(shLink);
    }


    @PostMapping(path="verifySmartHealthQR") public SHLink verifySmartHealthQR(
            @RequestPart MultipartFile qrCode,
            @RequestParam(value = "decrypt", defaultValue = "false") Boolean decrypt) {

        log.info("[MEMBER.QR.VERIFY] Verifying SH Link QR Code.  decrypt-{}", decrypt);

        return smartHealthDataSvc.verifyQrCode(qrCode, decrypt);
    }
}

package com.esrx.smart.data.feature.coverage.dental.summary;

import com.esrx.smart.data.common.meta.Metadata;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Dental COverage Summaries Response Model
 *
 * @author NV
 * @since 6/9/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data public class DentalCoverageSummariesRes {
    private DentalCoverageSummary coverageSummaries;
    private Metadata metadata;
}

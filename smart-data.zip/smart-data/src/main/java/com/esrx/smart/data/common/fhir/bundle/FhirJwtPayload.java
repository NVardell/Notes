package com.esrx.smart.data.common.fhir.bundle;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

/**
 * FHIR JWT Payload Model
 *
 * @author NV
 * @since 6/12/2023
 */
@JsonPropertyOrder({ "iss", "nbf", "vc" })
@Data @Builder public class FhirJwtPayload {
    @JsonProperty("iss") @JsonAlias("iss") private String issuer;
    @JsonProperty("nbf") private BigDecimal notBefore;  // Time before JWT MUST NOT be accepted for processing
    @JsonProperty("vc") private FhirCredential credential;
}

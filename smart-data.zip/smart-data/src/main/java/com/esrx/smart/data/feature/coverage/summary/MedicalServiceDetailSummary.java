package com.esrx.smart.data.feature.coverage.summary;

import com.esrx.smart.data.feature.coverage.medical.detail.benefit.Benefit;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Medical Service Summary Model
 *
 * @author NV
 * @since 5/18/2023
 */
@Data @Builder public class MedicalServiceDetailSummary {
    // In-Network & Out-of-Network
    //      ~ Coinsurance
    //      ~ Deductible
    //      ~ Out-of-Pocket Max
    List<Benefit> benefitList;
}

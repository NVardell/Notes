package com.esrx.smart.data.common.fhir.coverage;

import com.esrx.smart.data.common.fhir.FhirResource;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * FHIR Coverage Model
 *
 * @author NV
 * @since 6/9/2023
 */
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"extension", "identifier", "status", "subscriber", "subscriberId", "beneficiary", "dependent", "relationship", "period", "payor", "classes", "costToBeneficiary"})
@Data @Builder public class FhirCoverage extends FhirResource {
    private List<FhirExtension> extension;
    private List<FhirIdentifier> identifier;
    private String status;
    private FhirReference subscriber;
    private String subscriberId;
    private FhirReference beneficiary;
    private String dependent;
    private FhirType relationship;
    private FhirPeriod period;
    private List<FhirReference> payor;
    @JsonProperty("class") private List<FhirCoverageClass> classes;
    private List<FhirCostToBeneficiaryComponent> costToBeneficiary;
}

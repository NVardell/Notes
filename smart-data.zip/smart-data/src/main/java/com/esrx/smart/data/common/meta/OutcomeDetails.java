package com.esrx.smart.data.common.meta;

import lombok.Data;

/**
 * Outcome Details POJO
 *
 * @author NV
 * @since 5/12/2023
 */
@Data
public class OutcomeDetails {
    private String id;
    private String severity;
    private String message;
    private int code;
}

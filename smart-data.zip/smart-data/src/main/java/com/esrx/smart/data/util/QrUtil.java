package com.esrx.smart.data.util;

import com.esrx.smart.data.common.shLink.SHLink;
import com.esrx.smart.data.feature.member.MemberQrRes;
import com.esrx.smart.data.util.helper.JwtSignUtil;
import com.google.gson.Gson;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import io.nayuki.qrcodegen.QrCode;
import io.nayuki.qrcodegen.QrSegment;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

/**
 * QR Util
 *      ~ Nava's Smart Health Card Helper
 *          - https://git.express-scripts.com/ExpressScripts/smart-health-qr-generator/blob/develop/src/main/java/com/esrx/smarthealth/helper/SmartHealthCardHelper.java
 *
 * @author NV
 * @since 6/14/2023
 */
@Log4j2 @Service  public class QrUtil {

    @Autowired JwtSignUtil jwtSignUtil;
    @Autowired FileUtil fileUtil;

    private static final int QR_LOGO_SCALE = 4; // 3
    private static final int QR_SCALE = 4;
    private static final int QR_BORDER = 5; // 10
    private static final int MAX_QR_CODE_VERSION = 22;
    private static final int MIN_QR_CODE_VERSION = 1;
    private static final String SMART_LOGO_PATH = "logo/smart-logo.png";
    private static final String SMART_HEALTH_LINK_SCHEMA = "shlink:/";
    private static final String QR_IMAGE_FORMAT = "png";
    private static final String QR_IMAGE_NAME = "qr.png";


    @SneakyThrows public byte[] getQrCodeImage(SHLink shLink) {
        log.info("[UTIL.QR] Starting steps to generate QR");

        // Create QR Code
        QrCode qrCode = getQrCode(shLink);

        // Get & Return QR Bytes
        log.info("[UTIL.QR] Returning QR Code Bytes");
        return getQRCodeBytes(qrCode);
    }

    @SneakyThrows public MemberQrRes getQrCodeImagePath(SHLink shLink) {
        log.info("[UTIL.QR] Starting steps to generate QR");

        // Create QR Code
        QrCode qrCode = getQrCode(shLink);

        // Get QR Image
        log.info("[UTIL.QR] Returning QR Code Bytes");
        BufferedImage qrImage = overlaySmartLogoOnQr(qrCode.toImage(QR_SCALE, QR_BORDER));

        // Get QR Byte Array
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ImageIO.write(qrImage, QR_IMAGE_FORMAT, byteArrayOutputStream);

        // Save Local QR Image & Return filepath to QR image
        return MemberQrRes.builder()
                .qrPath(fileUtil.saveQrImageToLocal(shLink.getUniMemberId(), QR_IMAGE_FORMAT, QR_IMAGE_NAME, qrImage))
                .qrBytes(byteArrayOutputStream.toByteArray())
                .build();
    }


    @SneakyThrows public SHLink verifyQrCode(MultipartFile qrImage, Boolean decrypt) {
        log.info("[UTIL.QR.VERIFY] Verifying QR Code.   Decrypt-{}", decrypt);

        // Read data from QR Code (64 Bit Encoded)
        String qrData = readQrImage(qrImage);
        log.info("[UTIL.QR.VERIFY] QR Data: {}", qrData);

        // Extract SH Link Text
        String base64UrlEncodedPayload = qrData.substring(qrData.lastIndexOf("/") + 1);
        log.info("[UTIL.QR.VERIFY] QR SH Link Encoded: {}", base64UrlEncodedPayload);

        // Decode
        String shLinkPayloadDecoded = new String(Base64.getUrlDecoder().decode(base64UrlEncodedPayload));
        log.info("[UTIL.QR.VERIFY] QR SH Link Decoded: {}", shLinkPayloadDecoded);

        // TODO ~ Recreate logic for decoding FHIR payload.
        //      ~ From the looks of it, Nava is grabbing this from S3 & decoding.
        //      ~ I have most of the AWS Code, but not the specific S3 Prop Values.

        log.info("[UTIL.QR.VERIFY] Returning Decoded SH Link");
        return new Gson().fromJson(shLinkPayloadDecoded, SHLink.class);
    }


    /**
     *  GET QR HELPER METHODS BELOW
     */
    private static QrCode getQrCode(SHLink shLink) {
        // Create SH Link String
        String shLinkString = new Gson().toJson(shLink);
        log.info("[UTIL.QR] SH Link String = {}", shLinkString);

        // Encode SH Link String
        byte[] encodedPayload = Base64.getUrlEncoder().encode(shLinkString.getBytes());
        log.info("[UTIL.QR] Encoded SH Link String = {}", encodedPayload);

        // Create QR Segments (idk)
        List<QrSegment> segments = Arrays.asList(
                QrSegment.makeBytes(SMART_HEALTH_LINK_SCHEMA.getBytes(StandardCharsets.US_ASCII)),
                QrSegment.makeBytes(encodedPayload)
        );

        // Create QR
        QrCode qrCode = QrCode.encodeSegments(segments, QrCode.Ecc.MEDIUM, MIN_QR_CODE_VERSION, MAX_QR_CODE_VERSION, -1, true);
        log.info("[UTIL.QR] Generated QR Code");
        return qrCode;
    }

    @SneakyThrows private byte[] getQRCodeBytes(QrCode qrCode) {
        byte[] bytes;

        try {
            BufferedImage image = qrCode.toImage(QR_SCALE, QR_BORDER);
            // Add smart logo overlay
            BufferedImage combinedImg = overlaySmartLogoOnQr(image);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ImageIO.write(combinedImg, QR_IMAGE_FORMAT, byteArrayOutputStream);
            bytes = byteArrayOutputStream.toByteArray();
        } catch (IOException ioException) {
            log.error("Failed to convert QR code to byte Array: " + ioException.getMessage());
            throw new Exception("Unable to create Smart Health Card", ioException);
        }

        return bytes;
    }

    @SneakyThrows private BufferedImage overlaySmartLogoOnQr(BufferedImage qrImage) {
        int qrImgHeight = qrImage.getHeight();
        int qrImgWidth = qrImage.getWidth();

        ClassPathResource resource = new ClassPathResource(SMART_LOGO_PATH);
        BufferedImage origLogoImage = ImageIO.read(resource.getInputStream());

        double logoWHFactor = (double) origLogoImage.getWidth() / origLogoImage.getHeight();

        // Scale Smart Logo based on % of total QR size
        int newLogoHeight = (int)Math.round(Math.sqrt(((QR_LOGO_SCALE * qrImgHeight * qrImgWidth)/(100 * logoWHFactor))));
        int newLogoWidth = (int)Math.round(newLogoHeight * logoWHFactor);

        // Get Dimensions to Draw Centered Overlay
        int deltaHeight = qrImgHeight - newLogoHeight;
        int deltaWidth  = qrImgWidth  - newLogoWidth;

        // Create new image
        BufferedImage combinedImage = new BufferedImage(qrImgHeight, qrImgWidth, BufferedImage.TYPE_INT_ARGB);
        Graphics2D combinedImageGraphics = (Graphics2D)combinedImage.getGraphics();
        combinedImageGraphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

        // Draw QR Image
        combinedImageGraphics.drawImage(qrImage, 0, 0, null);
        combinedImageGraphics.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER));

        // Scale Overlay
        BufferedImage scaledLogoImg = new BufferedImage(newLogoWidth, newLogoHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics scaledLogoImgGraphics = scaledLogoImg.createGraphics();
        scaledLogoImgGraphics.drawImage(origLogoImage, 0, 0, newLogoWidth, newLogoHeight, null);
        scaledLogoImgGraphics.dispose();

        // Get Scaled Logo Image & Draw Centered Overlay
        combinedImageGraphics.drawImage(scaledLogoImg, Math.round(deltaWidth/2), Math.round(deltaHeight/2), null);
        combinedImageGraphics.dispose();

        return combinedImage;
    }


    /**
     *  VERIFY QR HELPER METHODS
     */
    private String readQrImage(MultipartFile qrImage) throws Exception {
        InputStream is = new ByteArrayInputStream(qrImage.getBytes());
        BufferedImage bufferedImage = ImageIO.read(is);
        LuminanceSource source = new BufferedImageLuminanceSource(bufferedImage);

        BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
        Result result = new MultiFormatReader().decode(bitmap);
        return result.getText();
    }
}

package com.esrx.smart.data.common.message;

import lombok.Data;

/**
 * Error Message POJO
 *
 * @author NV
 * @since 5/12/2023
 */
@Data public class ErrorMessage {
    private String message;
}

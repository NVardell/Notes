package com.esrx.smart.data.feature.coverage.medical;

import com.esrx.smart.data.feature.coverage.medical.accum.MedicalAccumResource;
import com.esrx.smart.data.feature.coverage.medical.accum.family.AccumFamMembers;
import com.esrx.smart.data.feature.coverage.medical.accum.family.AccumFamRes;
import com.esrx.smart.data.feature.coverage.medical.accum.family.AccumNetwork;
import com.esrx.smart.data.feature.coverage.medical.accum.family.AccumPeriod;
import com.esrx.smart.data.feature.coverage.medical.accum.plan.PlanAccumRes;
import com.esrx.smart.data.feature.coverage.medical.accum.plan.PlanAccumulations;
import com.esrx.smart.data.feature.coverage.medical.accum.plan.PlanAccumulator;
import com.esrx.smart.data.feature.coverage.medical.coveragesummeries.CoverageNetwork;
import com.esrx.smart.data.feature.coverage.medical.coveragesummeries.CoverageSummaries;
import com.esrx.smart.data.feature.coverage.medical.coveragesummeries.CoverageSummariesRes;
import com.esrx.smart.data.feature.coverage.medical.coveragesummeries.CoverageSummariesResource;
import com.esrx.smart.data.feature.coverage.medical.detail.ServiceBenefitDetailResource;
import com.esrx.smart.data.feature.coverage.medical.detail.benefit.Benefit;
import com.esrx.smart.data.feature.coverage.medical.detail.benefit.BenefitDetailsRes;
import com.esrx.smart.data.feature.coverage.medical.detail.benefit.BenefitNetwork;
import com.esrx.smart.data.feature.coverage.medical.detail.benefit.CostShare;
import com.esrx.smart.data.feature.coverage.medical.detail.service.ServiceCategoriesRes;
import com.esrx.smart.data.feature.coverage.summary.MedicalAccumSummary;
import com.esrx.smart.data.feature.coverage.summary.MedicalCoverageSummary;
import com.esrx.smart.data.feature.coverage.summary.MedicalServiceDetailSummary;
import com.esrx.smart.data.feature.coverage.summary.MedicalSummary;
import com.esrx.smart.data.util.CollectorUtil;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Medical Coverage Resource
 *
 * @author NV
 * @since 5/12/2023
 */
@Log4j2
@RestController public class MedicalResource {

    @Autowired MedicalAccumResource medicalAccumResource;
    @Autowired CoverageSummariesResource coverageSummariesResource;
    @Autowired ServiceBenefitDetailResource serviceBenefitDetailResource;

    private static final List<String> BENEFIT_CATEGORIES = Arrays.asList("DV", "IC");


    @GetMapping("getMedicalSummary") public Optional<MedicalSummary> getMedicalSummary(
            @RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType) {
        log.info("[MED.SUM] Retrieving Medical Summary");
        MedicalSummary medicalSummary = MedicalSummary.builder()
                .medicalCoverageSummary(getCoverageSummary(authBearerToken, productGroupType))
                .medicalAccumSummary(getAccum(authBearerToken, productGroupType))
                .medicalServiceDetailSummary(getMedicalServiceBenefitDetailsSummary(authBearerToken, productGroupType))
                .build();
        return Optional.ofNullable(medicalSummary);
    }


    @GetMapping("getCoverageSummary") public MedicalCoverageSummary getCoverageSummary(
            @RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType) {

        log.info("[MED.SUM.COV] Retrieving Medical Coverage Summary");
        MedicalCoverageSummary medicalCoverageSummary = MedicalCoverageSummary.builder().build();

        // Retrieve Coverage Summaries
        Optional<CoverageSummariesRes> coverageSummariesRes = coverageSummariesResource.getCoverageSummaries(authBearerToken, productGroupType);
        log.info("[MED.SUM.COV] Retrieved Coverage Summaries - {}", coverageSummariesRes);

        coverageSummariesRes.ifPresent(coverageSummariesResponse -> {
            // Extract Group Information
            CoverageSummaries coverageSummaries = coverageSummariesResponse.getCoverageSummaries();
            if(coverageSummaries != null){
                medicalCoverageSummary.setGroupId(coverageSummaries.getGroupId());
                medicalCoverageSummary.setGroupName(coverageSummaries.getGroupName());
                medicalCoverageSummary.setPlanId(coverageSummaries.getPlanNameKeyCode());

                // Extract Network Details
                CoverageNetwork coverageNetwork = coverageSummaries.getNetwork();
                if(coverageNetwork != null) {
                    medicalCoverageSummary.setNetworkId(coverageNetwork.getNetworkId());
                    medicalCoverageSummary.setNetworkName(coverageNetwork.getNetworkName());
                    medicalCoverageSummary.setPlanName(coverageNetwork.getRegulatoryNetworkName());
                }
            }
        });

        log.info("[MED.SUM.COV] Returning Medical Coverage Summary");
        return medicalCoverageSummary;
    }


    @GetMapping("getAccumulators")
    public MedicalAccumSummary getAccum(
            @RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType) {

        log.info("[MED.SUM.ACCUM] Retrieving Medical Accumulators Summary");
        Optional<AccumFamRes> familyMedicalAccum = medicalAccumResource.getFamilyAccum(authBearerToken, productGroupType);

        MedicalAccumSummary medicalAccumSummary = MedicalAccumSummary.builder().build();

        /*  NTS ~
                    DTR need to match logged-in user in order to extract their respective Card ID.
                        Example. 1.1, 2.1, etc.
        */
        familyMedicalAccum.ifPresent(familyAccumulations -> {
            AccumFamMembers accumFamMembers = familyAccumulations.getAccumFamMembers();

            if(accumFamMembers != null){
                AccumPeriod accumPeriod = familyAccumulations.getAccumFamMembers().getAccumulationPeriods().get(0);
                medicalAccumSummary.setAccumulationBeginDate(accumPeriod.getAccumulationBeginDate());
                medicalAccumSummary.setAccumulationEndDate(accumPeriod.getAccumulationEndDate());
                medicalAccumSummary.setFamilyMemberId(accumPeriod.getFamilyMembers().get(0).getId());

                List<AccumNetwork> accumNetworkList = accumPeriod.getAccumulationNetworkCategories();
                accumNetworkList.forEach(accumNetwork -> {
                    String network = accumNetwork.getCode();
                    log.info("[MED.SUM.ACCUM] Retrieving Medical Accumulators for Network = {}", network);
                    Optional<PlanAccumRes> planAccum = medicalAccumResource.getPlanAccum(
                            authBearerToken,
                            medicalAccumSummary.getFamilyMemberId(),
                            medicalAccumSummary.getAccumulationBeginDate(),
                            medicalAccumSummary.getAccumulationEndDate(),
                            network
                    );

                    planAccum.ifPresent(accum -> {
                        if(accum.getMedicalPlanAccumulators() != null) {
                            PlanAccumulator accumulator = accum.getMedicalPlanAccumulators().getAccumulators();
                            PlanAccumulations familyAccum = accumulator.getFamily();
                            PlanAccumulations individualAccum = accumulator.getIndividual();

                            if (Objects.equals(network, "INN")) {
                                medicalAccumSummary.setInNetworkFamilyDeductible(familyAccum.getDeductible().getTargetAmount());
                                medicalAccumSummary.setInNetworkFamilyOutOfPocket(familyAccum.getOutOfPocketMax().getTargetAmount());
                                medicalAccumSummary.setInNetworkIndividualDeductible(individualAccum.getDeductible().getTargetAmount());
                                medicalAccumSummary.setInNetworkIndividualOutOfPocket(individualAccum.getOutOfPocketMax().getTargetAmount());
                            } else if(Objects.equals(network, "OON")) {
                                medicalAccumSummary.setOutNetworkFamilyDeductible(familyAccum.getDeductible().getTargetAmount());
                                medicalAccumSummary.setOutNetworkFamilyOutOfPocket(familyAccum.getOutOfPocketMax().getTargetAmount());
                                medicalAccumSummary.setOutNetworkIndividualDeductible(individualAccum.getDeductible().getTargetAmount());
                                medicalAccumSummary.setOutNetworkIndividualOutOfPocket(individualAccum.getOutOfPocketMax().getTargetAmount());
                            } else log.warn("[MED.ACCUM] Unknown Network:{}", network);
                        }
                    });
                });
            }
        });

        log.info("[MED.SUM.ACCUM] Returning Medical Accumulators Summary");
        return medicalAccumSummary;
    }


    @GetMapping("getMedicalServiceBenefitDetailsSummary")
    public MedicalServiceDetailSummary getMedicalServiceBenefitDetailsSummary(
            @RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType) {

        log.info("[MED.SUM.SVC] Retrieving Service Categories Benefit Details Summary");
        MedicalServiceDetailSummary medicalServiceDetailSummary = MedicalServiceDetailSummary.builder().build();
        List<Benefit> allBenefits = new ArrayList<>();

        // Get Service Benefit Categories
        log.info("[MED.SUM.SVC] Retrieving Service Categories");
        Optional<ServiceCategoriesRes> serviceCategoriesRes = serviceBenefitDetailResource.getServiceCategories(authBearerToken, productGroupType);

        serviceCategoriesRes.ifPresent(svcCategoryRes -> {

            if(svcCategoryRes.getServiceCategories() == null) {
                log.error("[MED.SUM.SVC] Failed to retrieve Benefit Categories");
                return;
            }

            // Retrieve Service Benefit Details for the specific Benefit Categories
            //    ~ DV = Doctor Visits
            //    ~ IC = Intensive Care
            BENEFIT_CATEGORIES.forEach(benefitCategory -> {
                log.info("[MED.SUM.SVC] Retrieving Medical Benefit Service Details for Benefit Category = {}", benefitCategory);

                // Extract list of benefits from the Service Categories.
                List<Benefit> benefitList = svcCategoryRes.getServiceCategories().stream()
                        .filter(service -> benefitCategory.equals(service.getCategoryCode()))
                        .collect(CollectorUtil.toSingleton())
                        .getServiceBenefits().stream()
                        .map(serviceBenefit -> Benefit.builder()
                                .productGroupType(serviceBenefit.getProductGroupType())
                                .categoryCode(benefitCategory)
                                .benefitServiceId(serviceBenefit.getBenefitServiceId())
                                .build())
                        .collect(Collectors.toList());

                // Retrieve the details for each Service Benefit
                benefitList.forEach(benefit -> {
                    log.warn("[MED.SUM.SVC] Retrieving Details for Benefit = {}", benefit);

                    // Service call to retrieve Benefit Details
                    Optional<BenefitDetailsRes> benefitDetailsRes = serviceBenefitDetailResource.getBenefitDetails(
                            authBearerToken,
                            benefit.getCategoryCode(),
                            benefit.getBenefitServiceId(),
                            benefit.getProductGroupType());

                    // Extract Benefit Details from Benefit Detail Response
                    benefitDetailsRes.ifPresent(benefitDetail -> {

                        if(benefitDetail.getMedicalBenefitDetails() != null) {
                            List<BenefitNetwork> benefitNetworkList = benefitDetail.getMedicalBenefitDetails().getBenefitNetworkList();

                            // Loop Benefit Networks to retrieve Cost Share details
                            benefitNetworkList.forEach(benefitNetwork -> {
                                String networkCode = benefitNetwork.getCode();
                                log.info("[MED.SUM.SVC] Retrieving Details for Benefit Network = {}", networkCode);

                                CostShare costShare = benefitNetwork.getPlaceOfServiceList().get(0)
                                        .getAgeBands().get(0)
                                        .getRangeBands().get(0)
                                        .getCostShare();

                                if("INN".equals(networkCode)) {
                                    // Benefit Network = In-Network
                                    Optional.ofNullable(costShare.getDeductible()).ifPresent(deduct -> benefit.setInNetworkDeductible(deduct.getAmount()));
                                    Optional.ofNullable(costShare.getCoinsurance()).ifPresent(coin -> benefit.setInNetworkCoinsurance(coin.getPercent()));
                                    Optional.ofNullable(costShare.getCopay()).ifPresent(co -> benefit.setInNetworkCopay(co.getAmount()));
                                } else if("OON".equals(networkCode)) {
                                    // Benefit Network = Out-Of-Network
                                    Optional.ofNullable(costShare.getDeductible()).ifPresent(deduct -> benefit.setOutOfNetworkDeductible(deduct.getAmount()));
                                    Optional.ofNullable(costShare.getCoinsurance()).ifPresent(coin -> benefit.setOutOfNetworkCoinsurance(coin.getPercent()));
                                    Optional.ofNullable(costShare.getCopay()).ifPresent(co -> benefit.setOutOfNetworkCopay(co.getAmount()));
                                }
                            });
                        }

                        // Add Benefit to List of All Benefits
                        allBenefits.add(benefit);
                    });
                });
            });
            // Set Benefits List in Medical Service Detail Summary Response Object
            medicalServiceDetailSummary.setBenefitList(allBenefits);
        });

        log.info("[MED.SUM.SVC] Returning Medical Service Category Benefit Details Summary");
        return medicalServiceDetailSummary;
    }

}

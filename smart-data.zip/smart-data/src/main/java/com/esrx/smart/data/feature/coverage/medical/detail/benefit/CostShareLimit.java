package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import lombok.Data;

/**
 * Copay Cost Share Limit Model
 *
 * @author NV
 * @since 5/25/2023
 */
@Data public class CostShareLimit {
    private LimitQuantity limitQuantity;
    private TimePeriod timePeriod;
}

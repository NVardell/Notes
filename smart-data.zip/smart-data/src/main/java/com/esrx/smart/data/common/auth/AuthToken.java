package com.esrx.smart.data.common.auth;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Auth Token Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthToken {
    @JsonAlias("token_type") private String tokenType;
    @JsonAlias("access_token") private String accessToken;

    @JsonIgnore public String getToken() {
        return Stream.of(tokenType, accessToken)
                .filter(Objects::nonNull)
                .collect(Collectors.joining(" "));
    }
}

package com.esrx.smart.data.common.smart;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Smart Card Model
 *
 * @author NV
 * @since 6/12/2023
 */
@Data @Builder public class SmartCard {
    private List<String> verifiableCredential;
}

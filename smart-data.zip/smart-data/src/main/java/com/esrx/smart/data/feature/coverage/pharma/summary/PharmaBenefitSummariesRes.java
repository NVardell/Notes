package com.esrx.smart.data.feature.coverage.pharma.summary;
import com.esrx.smart.data.common.meta.Metadata;
import com.esrx.smart.data.feature.coverage.pharma.summary.CoverageSummaries;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PharmaBenefitSummariesRes {
    private CoverageSummaries coverageSummaries;
    private Metadata metadata;
}

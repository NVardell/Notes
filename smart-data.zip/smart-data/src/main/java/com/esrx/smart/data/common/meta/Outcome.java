package com.esrx.smart.data.common.meta;

import lombok.Data;

import java.util.List;

/**
 * Outcome POJO
 *
 * @author NV
 * @since 5/12/2023
 */
@Data
public class Outcome {
    private int status;
    private int code;
    private String message;
    private List<OutcomeDetails> additionalDetails;
}

package com.esrx.smart.data.feature.coverage.medical.accum.family;

import com.esrx.smart.data.common.name.Name;
import lombok.Data;

/**
 * Accumulation Family Member Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data public class AccumFamMember {
    private String customerId;
    private String idCardExtensionCode;
    private String dateOfBirth;
    private String id;
    private String gender;
    private Name name;
    private String relationshipToSubscriberCode;
    private Boolean loggedInUser;
    private Boolean delegate;
    private Boolean hipaaRestrictions;
    private Boolean delegationOptOut;
    private Boolean applyRestrictions;
    private int displayRank;
}

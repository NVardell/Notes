package com.esrx.smart.data.feature.coverage.pharma;
import com.esrx.smart.data.feature.coverage.pharma.summary.CoverageSummaries;
import com.esrx.smart.data.feature.coverage.pharma.summary.PharmaBenefitSummariesRes;
import com.esrx.smart.data.feature.coverage.pharma.summary.PharmaSummaryResource;
import com.esrx.smart.data.feature.coverage.summary.PharmaSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Optional;
@RestController
 public class PharmaResource {
    @Autowired
    PharmaSummaryResource pharmaSummaryResource;
    @GetMapping("getPharmaSummary") public PharmaSummary getPharmaSummary(String authBearerToken) {
        PharmaSummary pharmaSummary = PharmaSummary.builder().build();
        Optional<PharmaBenefitSummariesRes> pharmaBenefitSummariesRes = pharmaSummaryResource.getPharmaBenefitSummaries(authBearerToken);
        pharmaBenefitSummariesRes.ifPresent(pharmaBenefitSummariesResponse -> {
            CoverageSummaries coverageSummary = pharmaBenefitSummariesResponse.getCoverageSummaries();
            if(coverageSummary != null) {
                pharmaSummary.setPlanName(coverageSummary.getPlanName());
                pharmaSummary.setGroupId(coverageSummary.getGroupId());
            }

        });
        return pharmaSummary;
    }
}

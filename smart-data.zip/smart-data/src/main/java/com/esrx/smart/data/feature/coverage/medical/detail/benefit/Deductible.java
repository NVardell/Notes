package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Deductible Model
 *
 * @author NV
 * @since 5/25/2023
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Deductible {
    private Boolean waived;
    private Double amount;
    private CostShareLimit costShareLimit;
}

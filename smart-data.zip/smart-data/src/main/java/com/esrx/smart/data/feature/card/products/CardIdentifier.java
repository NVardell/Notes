package com.esrx.smart.data.feature.card.products;

import lombok.Data;

/**
 * Card Identifier POJO
 *
 * @author NV
 * @since 5/12/2023
 */
@Data
public class CardIdentifier {
    private String guidFront;
    private String guidBack;
}

package com.esrx.smart.data.feature.coverage;

import com.esrx.smart.data.feature.card.CardResource;
import com.esrx.smart.data.feature.coverage.dental.DentalResource;
import com.esrx.smart.data.feature.coverage.medical.MedicalResource;
import com.esrx.smart.data.feature.coverage.pharma.PharmaResource;
import com.esrx.smart.data.feature.coverage.summary.CardProductSummary;
import com.esrx.smart.data.feature.coverage.summary.CoverageSummary;
import com.esrx.smart.data.feature.coverage.summary.DentalSummary;
import com.esrx.smart.data.feature.coverage.summary.MedicalSummary;
import com.esrx.smart.data.feature.coverage.summary.PharmaSummary;
import com.esrx.smart.data.feature.coverage.summary.VisionSummary;
import com.esrx.smart.data.feature.coverage.vision.VisionResource;
import com.esrx.smart.data.util.AuthResourceUtil;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * Coverage Resource
 *
 * @author NV
 * @since 6/2/2023
 */
@Log4j2
@RestController public class CoverageResource {

    @Autowired AuthResourceUtil authResourceUtil;
    @Autowired CardResource cardResource;
    @Autowired MedicalResource medicalResource;
    @Autowired DentalResource dentalResource;


    @Autowired PharmaResource pharmaResource;

    @Autowired VisionResource visionResource;

    private static final String ACTIVE_STATUS = "Active";
    private static final String DENTAL = "DENT"; // Dental
    private static final String MEDICAL = "MED"; // Medical
    private static final String PHARMA = "PDP";  // Prescription Drug Plan (PDP)
    private static final String VISION = "VIS";  // Vision

    @GetMapping("getCoverageDetails/{productGroupType}") public Optional<CoverageSummary> getCoverageDetails(
            @RequestParam(value = "username", defaultValue = "${test.user.med}") String user,
            @RequestParam(value = "password", defaultValue = "${test.pass}") String pass,
            @PathVariable(value = "productGroupType") String productGroupType) {
        log.info("[COV] Retrieving Coverage Details for Group Type = {}", productGroupType);

        // Coverage Details Response Object
        CoverageSummary coverageSummary = CoverageSummary.builder().build();

        // Step #1 ~ Retrieve JWT
        log.info("[COV.AUTH] Retrieving JWT Token for Coverage Calls");
        String bearerToken = authResourceUtil.getAuthToken(user, pass);

        // Step #2 ~ Retrieve Member ID Card Products
        Optional<CardProductSummary> cardProductSummary = cardResource.getCardProducts(bearerToken, productGroupType);
        log.info("[COV.CARD] Retrieved Card Product Summary - type:{}", productGroupType);
        cardProductSummary.ifPresent(cardSummary -> {

            // Set Card Summary Details
            coverageSummary.setCardProductSummary(cardSummary);

            // Check Coverage Status
            if(ACTIVE_STATUS.equals(cardSummary.getCoverageStatus())) {

                // Step #3 ~ Retrieve Coverage Details
                if(productGroupType.toUpperCase().contains(MEDICAL)) {
                    log.info("[COV.MED] Retrieving Medical Summaries");
                    Optional<MedicalSummary> medicalSummary = medicalResource.getMedicalSummary(bearerToken, productGroupType);
                    log.info("[COV.MED] Retrieved Medical Summary");
                    medicalSummary.ifPresent(medicalSum -> {
                        coverageSummary.setMedicalCoverageSummary(medicalSum.getMedicalCoverageSummary());
                        coverageSummary.setMedicalAccumSummary(medicalSum.getMedicalAccumSummary());
                        coverageSummary.setMedicalServiceDetailSummary(medicalSum.getMedicalServiceDetailSummary());
                    });
                }
                // Step #4 ~ Retrieve Dental Coverage Details
                else if (productGroupType.toUpperCase().contains(DENTAL)) {
                    log.info("[COV.DENT] Retrieving Dental Summaries");
                    DentalSummary dentalSummary = dentalResource.getDentalSummary(bearerToken);
                    coverageSummary.setDentalSummary(dentalSummary);
                }
                // Step #5 ~ Retrieve Pharma Benefit Coverage Details
                else if (productGroupType.toUpperCase().contains(PHARMA)) {
               log.info("[COV.PDP] Retrieving Pharmacy Summaries");
                    PharmaSummary pharmaSummary = pharmaResource.getPharmaSummary(bearerToken);
                    coverageSummary.setPharmaSummary(pharmaSummary);
                }
                // Step #6 ~ Retrieve Vision Coverage Details
                else if (productGroupType.toUpperCase().contains(VISION)) {
                    log.info("[COV.VIS] Retrieving Vision Summaries");
                    VisionSummary visionSummary = visionResource.getVisionSummary(bearerToken);
                    coverageSummary.setVisionSummary(visionSummary);
                }
            }
        });
        return Optional.of(coverageSummary);
    }
}

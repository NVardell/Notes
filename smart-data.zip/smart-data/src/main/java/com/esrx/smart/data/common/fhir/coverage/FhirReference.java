package com.esrx.smart.data.common.fhir.coverage;

import lombok.Builder;
import lombok.Data;

/**
 * FHIR Reference Model
 *
 * @author NV
 * @since 6/9/2023
 */
@Data @Builder public class FhirReference {
    private String reference;
    private String display;
}

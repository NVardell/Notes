package com.esrx.smart.data.feature.card.products;

import com.esrx.smart.data.common.meta.Metadata;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

/**
 * Card Products Model
 *
 * @author NV
 * @since 5/11/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data public class CardProductsRes {
    private DigitalIdCards digitalIdCards;
    private List<CardMember> familyMembers;
    private Metadata metadata;
}

package com.esrx.smart.data.feature.coverage.dental.summary;

import lombok.Data;

/**
 * Dental Restriction Model
 *
 * @author NV
 * @since 6/9/2023
 */
@Data public class Restriction {
    private Boolean hipaaRestriction;
    private Boolean delegationOptOut;
    private Boolean pediatricRestriction;
}

package com.esrx.smart.data.feature.card.products;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Digital ID Cards Modal
 *
 * @author NV
 * @since 5/11/2023
 */
@Data @JsonInclude(JsonInclude.Include.NON_NULL)
public class DigitalIdCards {
    private String hasDigitalIdCards;
    private String digitalIdCardProducts;
}

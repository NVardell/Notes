package com.esrx.smart.data.util;

import com.esrx.smart.data.common.shLink.SHLink;
import com.esrx.smart.data.common.shLink.SHLinkFile;
import com.esrx.smart.data.common.shLink.SHLinkManifest;
import com.esrx.smart.data.feature.member.MemberMedicalBenefits;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;
import software.amazon.awssdk.services.s3.model.S3Exception;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.Collections;

/**
 * SH Link Util
 *
 * @author NV
 * @since 6/13/2023
 */
@Log4j2 @Service public class SHLinkUtil {


    /*@Autowired*/ private S3Client s3Client;
    @Autowired private FhirUtil fhirUtil;
    @Autowired private FileUtil fileUtil;
    @Autowired private SecureRandom secureRandom;


    @Value("${sh.payload.uri}") private String SH_PAYLOAD_URI;
    @Value("${aws.s3.uri}") private String AWS_S3_URI;

    private static final Integer RANDOM_BYTES_COUNT = 32;
    private static final Integer SMART_LINK_VERSION = 1;
    private static final String S3_BUCKET_NAME = "shlink-manifest";
    private static final String SMART_CARD_LABEL = "Medical ID Card";
    private static final String SMART_HEALTH_CONTENT_TYPE = "application/smart-health-card";
    private static final String SMART_LINK_MANIFEST_FILE_NAME = "manifest.json";
    private static final String SMART_LINK_PAYLOAD_FLAG_L = "L";
    private static final String SMART_LINK_PAYLOAD_FLAG_U = "U";


    @SneakyThrows public SHLink getSHLinkPayload(MemberMedicalBenefits memberMedicalBenefits, String flag, Boolean isLocal, Boolean encrypt) {
        log.info("[UTIL.SH-LINK] Retrieving SH Link Payload");

        String encryptKey = getRandomKey();
        String uniqueMemberIdForUrl = getRandomKey();
        log.info("[UTIL.SH-LINK] MemberId:{}  EncryptKey:{}  UniUrlId:{}", memberMedicalBenefits.getMember().getMemberId(), encryptKey, uniqueMemberIdForUrl);


        log.info("[UTIL.SH-LINK] Generating FHIR Payload URL for Flag={}", flag);
        String fhirPayloadGetUrl = "";
        if(flag.equalsIgnoreCase(SMART_LINK_PAYLOAD_FLAG_U)) {
            fhirPayloadGetUrl = SH_PAYLOAD_URI + uniqueMemberIdForUrl;
        } else if(flag.equalsIgnoreCase(SMART_LINK_PAYLOAD_FLAG_L)) {
            String s3ObjectKey = uniqueMemberIdForUrl + "/" + SMART_LINK_MANIFEST_FILE_NAME;
            fhirPayloadGetUrl = AWS_S3_URI + s3ObjectKey;

            log.info("[UTIL.SH-LINK] Retrieving FHIR Payload");
            String fhirPayload = fhirUtil.getFhirBundle(memberMedicalBenefits, encrypt);

            log.info("[UTIL.SH-LINK] Setting up Manifest File");
            SHLinkManifest shLinkManifest = SHLinkManifest.builder()
                    .files(Collections.singletonList(SHLinkFile.builder()
                                    .contentType(SMART_HEALTH_CONTENT_TYPE)
                                    .embedded(fhirPayload)
                            .build()))
                    .build();

            // Create local manifest file or upload to S3
            if(isLocal)
                fileUtil.saveFileToLocal(uniqueMemberIdForUrl, SMART_LINK_MANIFEST_FILE_NAME, new ObjectMapper().writeValueAsString(shLinkManifest));
            else
                uploadManifestToS3(s3ObjectKey, new ObjectMapper().writeValueAsString(shLinkManifest));
        }

        log.info("[UTIL.SH-LINK] Returning SH Link");
        return SHLink.builder()
                .key(encryptKey)
                .url(fhirPayloadGetUrl)
                .flag(flag.toUpperCase())
                .v(SMART_LINK_VERSION)
                .label(SMART_CARD_LABEL)
                .uniMemberId(uniqueMemberIdForUrl)
                .build();
    }


    private String getRandomKey() {
        log.info("[UTIL.SH-LINK] Generating Random Key");
        byte[] randomKey = new byte[RANDOM_BYTES_COUNT];
        secureRandom.nextBytes(randomKey);
        return Base64.getUrlEncoder().encodeToString(randomKey);
    }


    @SneakyThrows private void uploadManifestToS3(String objectKey, String manifestContent) {
        log.info("[UTIL.SH-LINK] Uploading Manifest to S3 Bucket");
        try {
            PutObjectRequest putOb = PutObjectRequest.builder()
                    .bucket(S3_BUCKET_NAME)
                    .key(objectKey)
                    .build();
            PutObjectResponse response = s3Client.putObject(putOb, RequestBody.fromString(manifestContent));
            log.info("[UTIL.SH-LINK] Uploaded to S3 - {}", response.eTag());
        } catch (S3Exception e) {throw new Exception(e.getMessage()); }
    }
}

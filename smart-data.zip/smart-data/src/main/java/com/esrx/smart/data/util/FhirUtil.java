package com.esrx.smart.data.util;

import com.esrx.smart.data.common.fhir.bundle.FhirJwtPayload;
import com.esrx.smart.data.common.fhir.coverage.*;
import com.esrx.smart.data.common.fhir.org.FhirContact;
import com.esrx.smart.data.common.fhir.org.FhirOrganization;
import com.esrx.smart.data.common.fhir.org.FhirTelecom;
import com.esrx.smart.data.common.fhir.patient.FhirName;
import com.esrx.smart.data.common.fhir.patient.FhirPatient;
import com.esrx.smart.data.common.name.Name;
import com.esrx.smart.data.common.smart.SmartCard;
import com.esrx.smart.data.feature.member.Member;
import com.esrx.smart.data.feature.member.MemberMedicalBenefits;
import com.esrx.smart.data.feature.member.MemberResource;
import com.esrx.smart.data.util.helper.FhirBundlerUtil;
import com.esrx.smart.data.util.helper.SmartCardUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers;
import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.crypto.spec.SecretKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

/**
 * FHIR Util
 *
 * @author NV
 * @since 6/9/2023
 */
@Log4j2 @Service public class FhirUtil{

    @Autowired MemberResource memberResource;
    @Autowired SmartCardUtil smartCardUtil;


    private static final String STATUS_ACTIVE = "active";
    private static final String RESOURCE_TYPE_COVERAGE = "Coverage";
    private static final String RESOURCE_TYPE_PATIENT = "Patient";
    private static final String RESOURCE_TYPE_ORG = "Organization";

    private static final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());


    //  FHIR URIs
    //
    private static final String ADD_CARD_INFO_EXT_URI = "http://hl7.org/fhir/us/insurance-card/StructureDefinition/C4DIC-AdditionalCardInformation-extension";
    private static final String CODE_SYSTEM_URI = "http://terminology.hl7.org/CodeSystem/v2-0203";
    private static final String CODE_SYSTEM_C4DIC_URI = "http://hl7.org/fhir/us/insurance-card/CodeSystem/C4DICIdentifierType";
    private static final String CONTACT_TYPE_URI = "http://hl7.org/fhir/us/insurance-card/CodeSystem/C4DICExtendedContactTypeCS";
    private static final String COPAY_TYPE_URI = "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    private static final String EXTENDED_COPAY_URI = "http://hl7.org/fhir/us/insurance-card/CodeSystem/C4DICExtendedCopayTypeCS";
    private static final String PLAN_BENEFICIARY_EXT_URI = "http://hl7.org/fhir/us/insurance-card/StructureDefinition/C4DIC-PlanBeneficiaries-extension";
    private static final String SUB_RELATION_URI = "http://terminology.hl7.org/CodeSystem/subscriber-relationship";


    @SneakyThrows public String getFhirBundle(MemberMedicalBenefits memberMedicalBenefits, Boolean encrypt) {
        log.info("[FHIR] Generating FHIR Bundle");

        Member member = memberMedicalBenefits.getMember();
        Name memberName = memberMedicalBenefits.getMember().getName();


        // Patient
        FhirPatient patient = FhirPatient.builder()
                .birthDate(member.getDateOfBirth())
                .name(Collections.singletonList(
                        FhirName.builder()
                                .family(memberName.getLast())
                                .given(memberName.toList())
                                .text(memberName.getFullName())
                                .build()))
                .build();
        patient.setResourceType(RESOURCE_TYPE_PATIENT);
        log.info("[FHIR] Part 1/3 ~ Generated FHIR Patient {}", patient);


        // Coverage
        FhirCoverage coverage = createFhirCoverage(member, memberMedicalBenefits, patient);
        coverage.setResourceType(RESOURCE_TYPE_COVERAGE);
        log.info("[FHIR] Part 2/3 ~ Generated FHIR Coverage {}", coverage);


        // Organization
        FhirOrganization organization = FhirOrganization.builder()
                .name("Cigna Insurance")
                .contact(Collections.singletonList(FhirContact.builder()
                                .purpose(FhirType.of(Collections.singletonList(FhirCoding.of(CONTACT_TYPE_URI, "provider", "Provider Service")),null))
                                .telecom(Collections.singletonList(FhirTelecom.of("phone", memberMedicalBenefits.getCustServiceNo() != null ? memberMedicalBenefits.getCustServiceNo() : "1 (888) 992-4462")))
                        .build()))
                .identifier(Collections.singletonList(FhirIdentifier.builder()
                                .type(FhirType.of(Collections.singletonList(FhirCoding.of(CODE_SYSTEM_C4DIC_URI, "payerId", "Payer Identifier")),null))
                                .value("54001")  // Nava Note ~ Hardcoded - Unknown.
                        .build()))
                .build();
        organization.setResourceType(RESOURCE_TYPE_ORG);
        log.info("[FHIR] Part 3/3 ~ Generated FHIR Organization {}", organization);


        // FHIR Bundle
        FhirJwtPayload fhirJwtPayload = FhirBundlerUtil.toJwtPayload(patient, coverage, organization);

        // Signed FHIR Bundle
        String signedFhirPayload = smartCardUtil.getJsonWebSignature(objectMapper.writeValueAsString(fhirJwtPayload));

        // Convert FHIR Bundle to Smart Card
        SmartCard smartCard = SmartCard.builder()
                .verifiableCredential(Collections.singletonList(signedFhirPayload))
                .build();

        return encrypt ? encrypt(objectMapper.writeValueAsString(smartCard), Base64.getUrlDecoder().decode("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")) : objectMapper.writeValueAsString(fhirJwtPayload);
    }

    private FhirCoverage createFhirCoverage(Member member, MemberMedicalBenefits memberMedicalBenefits, FhirPatient fhirPatient) {

        // FHIR Extension List
        List<FhirExtension> fhirExtensionList = Arrays.asList(
                FhirExtension.builder().url(PLAN_BENEFICIARY_EXT_URI)
                        .extension(Arrays.asList(
                                FhirExtension.builder().url("memberId").valueString(member.getMemberId() + "-" + member.getPersonId()).build(),
                                FhirExtension.builder().url("name").valueHumanName(fhirPatient.getName().get(0)).build()
                        )).build(),
                FhirExtension.builder().url(ADD_CARD_INFO_EXT_URI).valueAnnotation(FhirValueAnnotation.builder().text(memberMedicalBenefits.getCustServiceNo()).build()).build()
        );
        
        // FHIR Identifier
        FhirIdentifier memberIdentifier = FhirIdentifier.builder()
                .type(FhirType.builder().coding(Collections.singletonList(FhirCoding.builder().system(CODE_SYSTEM_URI).code("MB").display("Member Number").build())).build())
                .value(member.getMemberId() + "-" + member.getPersonId())
                .assigner(FhirAssigner.builder().display("Cigna Insurance").build())
                .build();

        // Time Period ~ Want Format ~ SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
        FhirPeriod timePeriod = FhirPeriod.builder().start(memberMedicalBenefits.getCoverageEffDate()).build();

        // Payor Reference - Organization - Update reference once resource name is assigned.
        FhirReference payorRef = FhirReference.builder().reference("payor").display("Cigna Insurance").build();

        // Subscriber Reference - Patient - Update reference once resource name is assigned.
        FhirReference subscriberRef = FhirReference.builder().reference("name").display(member.getName().getFullName()).build();

        // Beneficiary (Self) Reference - Patient - Update reference once resource name is assigned.
        FhirReference beneficiaryRef = FhirReference.builder().reference("name").display(member.getName().getFullName()).build();

        // Subscriber - Dependent Relationship
        FhirType relationship = FhirType.builder()
                .coding(Collections.singletonList(FhirCoding.builder()
                                .system(SUB_RELATION_URI)
                                .code("Self")
                                .display("Self")
                        .build()))
                .build();

        // FHIR Coverage Classes
        List<FhirCoverageClass> classes = Arrays.asList(
                FhirCoverageClass.of(null, "group", memberMedicalBenefits.getGroupId()),
                FhirCoverageClass.of(null, "plan", memberMedicalBenefits.getPlanName()),
                FhirCoverageClass.of(null, "rxBin", memberMedicalBenefits.getRxBin() != null ? memberMedicalBenefits.getRxBin() : "017010"),
                FhirCoverageClass.of(null, "rxPcn", memberMedicalBenefits.getRxPcn() != null ? memberMedicalBenefits.getRxPcn() : "0215COMM"),
                FhirCoverageClass.of(null, "rxGroup", memberMedicalBenefits.getRxGroup() != null ? memberMedicalBenefits.getRxGroup() : "3174704")
        );

        // FHIR Cost Components
        List<FhirCostToBeneficiaryComponent> costToBeneficiaryComponents = Arrays.asList(
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(EXTENDED_COPAY_URI, "IndInDed", "Individual In Network Deductible")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getInNetworkDedInd(), null)),
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(EXTENDED_COPAY_URI, "IndOutDed", "Individual Out of Network Deductible")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getOutNetworkDedInd(), null)),
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(EXTENDED_COPAY_URI, "IndInMax", "Individual In Network Out of Pocket Maximum")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getInNetworkOopInd(), null)),
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(EXTENDED_COPAY_URI, "IndOutMax", "Individual Out of Network Out of Pocket Maximum")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getOutNetworkOopInd(), null)),
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(EXTENDED_COPAY_URI, "FamInDed", "Family In Network Deductible")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getInNetworkDedFam(), null)),
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(EXTENDED_COPAY_URI, "FamOutDed", "Family Out of Network Deductible")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getOutNetworkDedFam(), null)),
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(EXTENDED_COPAY_URI, "FamInMax", "Family In Network Out of Pocket Maximum")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getInNetworkOopFam(), null)),
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(EXTENDED_COPAY_URI, "FamOutMax", "Family Out of Network Out of Pocket Maximum")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getOutNetworkOopFam(), null)),
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(COPAY_TYPE_URI, "GpVisit", "GP Office Visit")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getPcpVisit(), null)),
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(COPAY_TYPE_URI, "SpVisit", "Specialist Office Visit")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getSpecialist(), null)),
                FhirCostToBeneficiaryComponent.of(
                        FhirType.of(Collections.singletonList(FhirCoding.of(COPAY_TYPE_URI, "UrgentCare", "Urgent Care")), null),
                        FhirMoney.of("USD", memberMedicalBenefits.getUrgentCare(), null))
        );

        return FhirCoverage.builder()
                .extension(fhirExtensionList)
                .identifier(Collections.singletonList(memberIdentifier))
                .status(STATUS_ACTIVE)
                .subscriber(subscriberRef)
                .subscriberId(member.getMemberId() + " " + member.getPersonId())
                .period(timePeriod)
                .payor(Collections.singletonList(payorRef))
                .classes(classes)
                .beneficiary(beneficiaryRef)
                .dependent(member.getPersonId())
                .relationship(relationship)
                .costToBeneficiary(costToBeneficiaryComponents)
                .build();
    }


    @SneakyThrows private String encrypt(String payload, byte[] key) {
        JsonWebEncryption encryptingJwe = new JsonWebEncryption();
        encryptingJwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.DIRECT);
        encryptingJwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_256_GCM);
        encryptingJwe.setKey(new SecretKeySpec(key, "AES"));
        encryptingJwe.setPayload(payload);
        return encryptingJwe.getCompactSerialization();
    }
}

package com.esrx.smart.data.feature.coverage.dental.summary;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Network Detail Model
 *
 * @author NV
 * @since 6/9/2023
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NetworkDetail {
    private String inNetworkName;
    private String preferredNetworkName;
    private String benefitNetworkName;
}

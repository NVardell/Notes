package com.esrx.smart.data.common.fhir.coverage;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

/**
 * FHIR Identifier Model
 *
 * @author NV
 * @since 6/9/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data @Builder public class FhirIdentifier {
    private FhirType type;
    private String system;
    private String value;
    private FhirAssigner assigner;
}

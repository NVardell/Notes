package com.esrx.smart.data.common.shLink;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;

/**
 * SH Link File Model
 *
 * @author NV
 * @since 6/13/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "contentType", "embedded", "location" })
@Data @Builder public class SHLinkFile {
    private String contentType;
    private String embedded;
    private String location;
}

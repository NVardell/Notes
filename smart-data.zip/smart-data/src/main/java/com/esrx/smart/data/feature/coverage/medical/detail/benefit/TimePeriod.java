package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import lombok.Data;

/**
 * Time Period Model
 *
 * @author NV
 * @since 5/25/2023
 */
@Data public class TimePeriod {
    private String type;
    private String code;
    private int quantity;
}

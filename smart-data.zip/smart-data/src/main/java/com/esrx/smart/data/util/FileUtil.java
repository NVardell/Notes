package com.esrx.smart.data.util;

import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * File Util
 *
 * @author NV
 * @since 6/21/2023
 */
@Log4j2
@Component public class FileUtil {

    private static final String LOCAL_FILE_PATH = System.getProperty("user.home");

    @SneakyThrows
    public String saveFileToLocal(String fileDirectory, String fileName, String fileContent) {
        log.info("[UTIL.FILE] Saving Locally");

        // Build File Path
        String fullFilePath = LOCAL_FILE_PATH + File.separator
                + "Desktop" + File.separator
                + fileDirectory + File.separator
                + fileName;
        log.info("[UTIL.FILE] Local File Path={}", fullFilePath);

        // Get File path
        Path file = Paths.get(fullFilePath);

        // Create Parent Directory
        Files.createDirectories(file.getParent());

        // Write New File
        Files.write(file, fileContent.getBytes());

        // Return Filepath
        return fullFilePath;
    }

    @SneakyThrows
    public String saveQrImageToLocal(String fileDirectory, String fileType, String fileName, BufferedImage imageContent) {
        log.info("[UTIL.FILE.IMAGE] Saving Image File Locally");

        // Build File Path
        String fullFilePath = LOCAL_FILE_PATH + File.separator
                + "Desktop" + File.separator
                + fileDirectory + File.separator
                + fileName;
        log.info("[UTIL.FILE.IMAGE] Local File Path={}", fullFilePath);

        // Write Image File
        ImageIO.write(imageContent, fileType, new File(fullFilePath));
        log.info("[UTIL.FILE.IMAGE] Local Image File Created Successfully");

        // Return Path to Image
        return fullFilePath;
    }
}

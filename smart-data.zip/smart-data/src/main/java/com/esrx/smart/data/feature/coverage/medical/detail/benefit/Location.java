package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import lombok.Data;

/**
 * Place of Service Location Model
 *
 * @author NV
 * @since 5/25/2023
 */
@Data public class Location {
    private int code;
    private int displayRank;
    private String providerTypeCode;
}

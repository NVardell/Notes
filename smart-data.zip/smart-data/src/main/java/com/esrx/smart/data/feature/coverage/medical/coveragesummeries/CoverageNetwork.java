package com.esrx.smart.data.feature.coverage.medical.coveragesummeries;
import lombok.Data;

/**
 * Coverage Network POJO
 *
 * @author C7H4X4
 *
 */
@Data
public class CoverageNetwork {
    private String networkId;
    private String networkName;
    private String networkCategoryCode;
    private String regulatoryNetworkName;
}

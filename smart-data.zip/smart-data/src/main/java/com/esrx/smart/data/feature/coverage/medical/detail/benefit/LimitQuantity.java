package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import lombok.Data;

/**
 * Limit Quantity Model
 *
 * @author NV
 * @since 5/25/2023
 */
@Data public class LimitQuantity {
    private String code;
    private int min;
    private int max;
}

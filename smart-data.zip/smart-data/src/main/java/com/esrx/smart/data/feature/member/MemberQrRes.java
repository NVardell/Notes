package com.esrx.smart.data.feature.member;

import lombok.Builder;
import lombok.Data;

/**
 * Member QR Response Model
 *
 * @author NV
 * @since 6/21/2023
 */
@Data @Builder public class MemberQrRes {
    private String qrPath;
    private byte [] qrBytes;
}

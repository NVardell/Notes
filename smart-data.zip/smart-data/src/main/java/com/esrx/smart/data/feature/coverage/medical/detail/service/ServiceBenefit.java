package com.esrx.smart.data.feature.coverage.medical.detail.service;

import lombok.Data;

/**
 * Service Benefits Model
 *
 * @author NV
 * @since 5/24/2023
 */
@Data public class ServiceBenefit {
    private String benefitServiceId;
    private int benefitDisplayRank;
    private String productGroupType;
}

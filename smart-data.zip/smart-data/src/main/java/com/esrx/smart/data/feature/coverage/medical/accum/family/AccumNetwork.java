package com.esrx.smart.data.feature.coverage.medical.accum.family;

import lombok.Data;

/**
 * Accumulation Network Categories Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data public class AccumNetwork {
    private String code;
    private int displayRank;
}

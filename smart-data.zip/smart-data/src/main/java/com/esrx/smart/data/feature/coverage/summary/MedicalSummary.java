package com.esrx.smart.data.feature.coverage.summary;

import lombok.Builder;
import lombok.Data;

/**
 * Medical Summary Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data @Builder public class MedicalSummary {
    private MedicalAccumSummary medicalAccumSummary;
    private MedicalCoverageSummary medicalCoverageSummary;
    private MedicalServiceDetailSummary medicalServiceDetailSummary;
}

package com.esrx.smart.data.util.helper;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.ECDSASigner;
import com.nimbusds.jose.crypto.ECDSAVerifier;
import com.nimbusds.jose.jwk.ECKey;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.util.Base64URL;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;

import java.text.ParseException;


/**
 * JWT Signing Util
 *
 * @author NV
 * @since 6/12/2023
 */
@Log4j2 public class JwtSignUtil {

    private static final String JWS_HEADER_ZIP = "zip";
    private static final String JWS_HEADER_ZIP_DEFLATE_PARAM = "DEF";
    private final ECKey ecKey;
    private final JWSSigner jwsSigner;
    private final JWSVerifier jwsVerifier;


    public JwtSignUtil(String kid, String privateKey) {
        try {
            JWKSet jwkSet = JWKSet.parse(privateKey);
            this.ecKey = jwkSet.getKeyByKeyId(kid).toECKey();
            this.jwsSigner = new ECDSASigner(ecKey);
            this.jwsVerifier = new ECDSAVerifier(ecKey.toECPublicKey());
        } catch (ParseException e) {
            throw new IllegalStateException("Could not parse private key set for Smart Health Card signing", e);
        } catch (JOSEException e) {
            throw new IllegalStateException("Could not create ECDSASigner for Smart Health Card signing", e);
        }
    }

    @SneakyThrows public String getSignedJwt(byte[] deflatedPayload) {
        log.info("[UTIL.JWT.SIGN] Signing Deflated FHIR Payload");
        JWSObject jwsObject;

        try {
            final JWSHeader jwsHeader = new JWSHeader
                    .Builder(JWSAlgorithm.ES256)
                    .keyID(ecKey.getKeyID())
                    .customParam(JWS_HEADER_ZIP, JWS_HEADER_ZIP_DEFLATE_PARAM)
                    .base64URLEncodePayload(true)
                    .build();
            final Payload jwsPayload = new Payload(Base64URL.encode(deflatedPayload));

            jwsObject = new JWSObject(jwsHeader, jwsPayload);
            jwsObject.sign(jwsSigner);
        } catch (JOSEException joseException) {
            log.error("Failed to create signer: " + joseException.getMessage());
            throw new Exception("Unable to create Smart Health Card", joseException);
        }

        return jwsObject.serialize();
    }

}

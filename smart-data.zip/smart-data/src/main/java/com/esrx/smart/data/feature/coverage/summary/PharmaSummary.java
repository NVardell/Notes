package com.esrx.smart.data.feature.coverage.summary;

import lombok.Builder;
import lombok.Data;
@Data
@Builder
public class PharmaSummary {
    private String planName;
    private String groupId;

}

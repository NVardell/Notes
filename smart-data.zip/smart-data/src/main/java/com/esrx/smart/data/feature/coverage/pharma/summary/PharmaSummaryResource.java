package com.esrx.smart.data.feature.coverage.pharma.summary;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.Optional;

/**
 * Pharmacy (PDP) Coverage Resource
 *
 * @author NV
 * @since 5/12/2023
 */
@Log4j2
@RestController public class PharmaSummaryResource {
    @Value("${proxy.port}") private int proxyPort;
    @Value("${proxy.host}") private String proxyHost;
    @Value("${coverage.pharma.benefits.resource}") private String pharmaBenefitSummariesURI;
    @GetMapping("benefitSummary")
    public Optional<PharmaBenefitSummariesRes> getPharmaBenefitSummaries(@RequestParam(value = "authBearerToken")
                                                                           String authBearerToken)
    {
        return Optional.ofNullable(Unirest.get(pharmaBenefitSummariesURI)
                .header(HttpHeaders.AUTHORIZATION, authBearerToken)
                .proxy(proxyHost, proxyPort)
                .asObject(PharmaBenefitSummariesRes.class)
                .getBody());
    }
}

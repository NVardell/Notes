package com.esrx.smart.data.feature.card.products;

import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * Coverage Cards Controller
 *
 * @author NV
 * @since 5/11/2023
 */
@Log4j2
@RestController public class CardProductsResource {

    @Value("${proxy.port}") private int proxyPort;
    @Value("${proxy.host}") private String proxyHost;
    @Value("${card.member.products.resource}") private String idMemberProductsUri;


    @GetMapping("getCardProductIds")
    public Optional<CardProductsRes> getCardProductIds(@RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken) {
        return Optional.ofNullable(Unirest.get(idMemberProductsUri)
                .header(HttpHeaders.AUTHORIZATION, authBearerToken)
                .proxy(proxyHost, proxyPort)
                .asObject(CardProductsRes.class)
                .getBody());
    }
}

package com.esrx.smart.data.feature.coverage.medical.accum.family;

import com.esrx.smart.data.common.meta.Metadata;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Accumulation Family Model
 *
 * @author NV
 * @since 5/17/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data public class AccumFamRes {
    @JsonAlias("accumulationPeriodFamilyMembers") private AccumFamMembers accumFamMembers;
    private Metadata metadata;
}

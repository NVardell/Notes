package com.esrx.smart.data.feature.smart;

import com.esrx.smart.data.common.shLink.SHLink;
import com.esrx.smart.data.feature.member.MemberMedicalBenefits;
import com.esrx.smart.data.feature.member.MemberQrRes;
import org.springframework.web.multipart.MultipartFile;

/**
 * Smart Health Data Util Services
 *
 * @author NV
 * @since 6/13/2023
 */
public interface SmartHealthDataSvc {
    //  FHIR
    //
    String getFhirBundle(MemberMedicalBenefits memberMedicalBenefits, Boolean encrypt);

    // SH Link
    //
    SHLink getSHLinkPayload(MemberMedicalBenefits memberMedicalBenefits, String flag, Boolean isLocal, Boolean doEncrypt);

    // QR Code
    //
    byte[] getQrCodeImage(SHLink shLink);
    MemberQrRes getQrCodeImagePath(SHLink shLink);
    SHLink verifyQrCode(MultipartFile qrImage, Boolean decrypt);
}

package com.esrx.smart.data.common.fhir.coverage;

import lombok.Builder;
import lombok.Data;

/**
 * FHIR Assigner Model
 *
 * @author NV
 * @since 6/9/2023
 */
@Data @Builder public class FhirAssigner {
    private String display;
}

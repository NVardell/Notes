package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Coinsurance Model
 *
 * @author NV
 * @since 5/25/2023
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Coinsurance {
    private Boolean accumsToOOPMax;
    private String percent;
    private CostShareLimit costShareLimit;
}

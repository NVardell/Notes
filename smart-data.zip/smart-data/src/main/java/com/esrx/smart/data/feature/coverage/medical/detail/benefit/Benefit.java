package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

/**
 * Benefit Summary Model
 *
 * @author NV
 * @since 5/31/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data @Builder public class Benefit {
    private String productGroupType;
    private String categoryCode;
    private String benefitServiceId;
    private Integer inNetworkCopay;
    private String inNetworkCoinsurance;
    private Double inNetworkDeductible;
    private Integer outOfNetworkCopay;
    private String outOfNetworkCoinsurance;
    private Double outOfNetworkDeductible;
}

package com.esrx.smart.data.feature.coverage.medical.accum.plan;

import com.esrx.smart.data.common.meta.Metadata;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Medical Plan Accumulator Model
 *
 * @author NV
 * @since 5/17/2023
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data public class PlanAccumRes {
    private PlanAccumulators medicalPlanAccumulators;
    private Metadata metadata;
}

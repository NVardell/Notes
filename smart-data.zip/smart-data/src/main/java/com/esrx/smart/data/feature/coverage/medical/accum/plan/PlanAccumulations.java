package com.esrx.smart.data.feature.coverage.medical.accum.plan;

import lombok.Data;

/**
 * Plan Accumulations Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data public class PlanAccumulations {
    private PlanDeductible deductible;
    private PlanOutOfPocketMax outOfPocketMax;
}

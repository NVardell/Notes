package com.esrx.smart.data.common.fhir.coverage;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * FHIR Coding Model
 *
 * @author NV
 * @since 6/9/2023
 */
@AllArgsConstructor(staticName = "of")
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data @Builder public class FhirCoding {
    private String system;
    private String code;
    private String display;
}

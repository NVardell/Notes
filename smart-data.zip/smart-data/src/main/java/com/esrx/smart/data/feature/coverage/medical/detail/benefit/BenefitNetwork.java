package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.util.List;

/**
 * Benefit Network Model
 *
 * @author NV
 * @since 5/25/2023
 */
@Data public class BenefitNetwork {
    private String code;
    private int displayRank;
    private Boolean planDeductible;
    private Boolean planOOPMax;
    private Boolean ccnOrRpoExists;
    @JsonAlias("placesOfService") private List<PlaceOfService> placeOfServiceList ;
}

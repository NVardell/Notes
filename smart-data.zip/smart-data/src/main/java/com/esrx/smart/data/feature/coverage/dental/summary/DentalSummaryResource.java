package com.esrx.smart.data.feature.coverage.dental.summary;

import kong.unirest.Unirest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * Dental Summary Resource
 *
 * @author NV
 * @since 6/9/2023
 */
@RestController public class DentalSummaryResource {

    @Value("${proxy.port}") private int proxyPort;
    @Value("${proxy.host}") private String proxyHost;
    @Value("${coverage.dental.summaries.resource}") private String dentalCoverageSummariesURI;

    @GetMapping("getDentalCoverageSummaries") public Optional<DentalCoverageSummariesRes> getDentalCoverageSummaries(String authBearerToken){
        return Optional.ofNullable(Unirest.get(dentalCoverageSummariesURI)
                .header(HttpHeaders.AUTHORIZATION, authBearerToken)
                .proxy(proxyHost, proxyPort)
                .asObject(DentalCoverageSummariesRes.class)
                .getBody());
    }
}

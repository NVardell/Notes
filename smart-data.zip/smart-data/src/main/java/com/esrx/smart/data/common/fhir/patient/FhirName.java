package com.esrx.smart.data.common.fhir.patient;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Fhir Name Model
 *
 * @author NV
 * @since 6/9/2023
 */
@Data @Builder public class FhirName {
    private String text;
    private String family;
    private List<String> given;
}

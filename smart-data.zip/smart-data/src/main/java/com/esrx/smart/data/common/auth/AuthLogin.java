package com.esrx.smart.data.common.auth;

import lombok.Builder;
import lombok.Data;

/**
 * Auth Login Model
 *
 * @author NV
 * @since 6/6/2023
 */
@Data @Builder public class AuthLogin {
    private String username;
    private String password;
}

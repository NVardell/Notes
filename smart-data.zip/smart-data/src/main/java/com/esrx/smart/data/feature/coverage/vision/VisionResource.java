package com.esrx.smart.data.feature.coverage.vision;
import com.esrx.smart.data.feature.coverage.summary.VisionSummary;
import com.esrx.smart.data.feature.coverage.vision.summary.CoverageSummaries;
import com.esrx.smart.data.feature.coverage.vision.summary.VisionCoverageSummariesRes;
import com.esrx.smart.data.feature.coverage.vision.summary.VisionSummaryResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Optional;


@RestController
public class VisionResource {
    @Autowired
    VisionSummaryResource visionSummaryResource;
    @GetMapping("getVisionSummary") public VisionSummary getVisionSummary(String authBearerToken) {
        VisionSummary visionSummary = VisionSummary.builder().build();
        Optional<VisionCoverageSummariesRes> visionCoverageSummariesRes = visionSummaryResource.getVisionCoverageSummaries(authBearerToken);
        visionCoverageSummariesRes.ifPresent(visionCoverageSummariesResponse -> {
            CoverageSummaries coverageSummary = visionCoverageSummariesResponse.getCoverageSummaries();

            if(coverageSummary != null) {
                visionSummary.setGroupId(coverageSummary.getGroupId());
                visionSummary.setVisionType(coverageSummary.getVisionType());
            }
        });
        return visionSummary;
    }
}

package com.esrx.smart.data.feature.coverage.medical.coveragesummeries;

import com.esrx.smart.data.common.meta.Metadata;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Product Coverage POJO
 *
 * @author C7H4X4
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data public class CoverageSummariesRes {
    private CoverageSummaries coverageSummaries;
    private Metadata metadata;
}

package com.esrx.smart.data.feature.member.product;

import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * Member Product Group Resource
 *
 * @author NV
 * @since 6/16/2023
 */
@Log4j2
@RestController public class MemberProductGroupResource {

    @Value("${proxy.port}") private int proxyPort;
    @Value("${proxy.host}") private String proxyHost;
    @Value("${member.products.resource}") private String memberProductsUri;


    @GetMapping("getMemberProductGroups") public Optional<MemberProductGroupRes> getMemberProductGroups(String authBearerToken) {
        return Optional.ofNullable(Unirest.get(memberProductsUri)
                .header(HttpHeaders.AUTHORIZATION, authBearerToken)
                .proxy(proxyHost, proxyPort)
                .asObject(MemberProductGroupRes.class)
                .getBody());
    }
}

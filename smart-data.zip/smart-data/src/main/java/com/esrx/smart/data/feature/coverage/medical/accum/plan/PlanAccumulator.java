package com.esrx.smart.data.feature.coverage.medical.accum.plan;

import lombok.Data;

import java.util.List;

/**
 * Medical Plan Accumulator Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data public class PlanAccumulator {
    private Double deductibleRemainingAmount;
    private Boolean deductibleMet;
    private Double oopMaxRemainingAmount;
    private Boolean oopMaxMet;
    private Boolean copayAppliesToOopType;
    private Boolean copayAppliesToOopMax;
    private List<String> deductibleShared;
    private List<String> oopMaxShared;
    private PlanAccumulations individual;
    private PlanAccumulations family;
}

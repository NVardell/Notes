package com.esrx.smart.data.feature.coverage.summary;

import lombok.Builder;
import lombok.Data;

/**
 * Accumulation Summary Model
 *
 * @author NV
 * @since 5/17/2023
 */
@Data @Builder public class MedicalAccumSummary {
    private String accumulationBeginDate;
    private String accumulationEndDate;
    private String familyMemberId;
    private Double inNetworkFamilyDeductible;
    private Double inNetworkFamilyOutOfPocket;
    private Double outNetworkFamilyDeductible;
    private Double outNetworkFamilyOutOfPocket;
    private Double inNetworkIndividualDeductible;
    private Double inNetworkIndividualOutOfPocket;
    private Double outNetworkIndividualOutOfPocket;
    private Double outNetworkIndividualDeductible;

    public String getAccumulationBeginDate() {
        String[] date = accumulationBeginDate.split("/");
        return date[2] + "-" + date[0] + "-" + date[1];
    }

    public String getAccumulationEndDate() {
        String[] date = accumulationEndDate.split("/");
        return date[2] + "-" + date[0] + "-" + date[1];
    }
}

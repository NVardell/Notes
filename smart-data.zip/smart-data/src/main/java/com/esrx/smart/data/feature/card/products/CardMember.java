package com.esrx.smart.data.feature.card.products;

import com.esrx.smart.data.common.name.Name;
import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.util.List;

/**
 * Card Family Member POJO
 *
 * @author NV
 * @since 5/12/2023
 */
@Data
public class CardMember {
    private Name name;
    private String dateOfBirth;
    private String relationshipToSubscriberCode;
    private String age;
    private Boolean isLoggedInUser;
    private Boolean isDelegate;
    @JsonAlias("ishipaaRestricted") private Boolean isHipaaRestricted;
    private Boolean hasDelegationOptOut;
    private int displayRank;
    private List<CardProduct> products;
}

package com.esrx.smart.data.feature.coverage.vision.summary;

import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * Vision Coverage Resource
 *
 * @author NV
 * @since 5/12/2023
 */
@Log4j2
@RestController public class VisionSummaryResource {
    @Value("${proxy.port}") private int proxyPort;
    @Value("${proxy.host}") private String proxyHost;
    @Value("${coverage.vision.summaries.resource}") private String visionCoverageSummariesURI;
    @GetMapping("visionCoverageSummaries")
    public Optional<VisionCoverageSummariesRes> getVisionCoverageSummaries(@RequestParam(value = "authBearerToken")
                                                                               String authBearerToken)
    {
        return Optional.ofNullable(Unirest.get(visionCoverageSummariesURI)
                .header(HttpHeaders.AUTHORIZATION, authBearerToken)
                .proxy(proxyHost, proxyPort)
                .asObject(VisionCoverageSummariesRes.class)
                .getBody());
    }
}

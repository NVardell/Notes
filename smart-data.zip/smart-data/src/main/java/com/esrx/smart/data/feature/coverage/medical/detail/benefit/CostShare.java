package com.esrx.smart.data.feature.coverage.medical.detail.benefit;

import lombok.Data;

/**
 * Cost Share Model
 *
 * @author NV
 * @since 5/25/2023
 */
@Data public class CostShare {
    private String benefitOrderCode;
    private Copay copay;
    private Coinsurance coinsurance;
    private Deductible deductible;
}

package com.esrx.smart.data.feature.coverage.medical.accum;

import com.esrx.smart.data.feature.coverage.medical.accum.family.AccumFamRes;
import com.esrx.smart.data.feature.coverage.medical.accum.plan.PlanAccumRes;
import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * Medical Accumulator Resource
 *
 * @author NV
 * @since 5/17/2023
 */
@Log4j2
@Service
@RestController
public class MedicalAccumResource {

    @Value("${coverage.medical.accum.resource}") String medAccumUri;
    @Value("${coverage.medical.accum.fam.resource}") String famAccumUri;

    @Value("${proxy.port}") private int proxyPort;
    @Value("${proxy.host}") private String proxyHost;
    @Value("${auth.bearer.token}") private String authBearerToken;

    private static final String PRODUCT_TYPE = "productGroupType";
    private static final String FAMILY_MEMBER_ID = "id";
    private static final String ACCUM_START = "accumulationBeginDate";
    private static final String ACCUM_FINISH = "accumulationEndDate";
    private static final String ACCUM_CAT = "accumulationNetworkCategoryCode";


    @GetMapping("getFamilyAccum") public Optional<AccumFamRes> getFamilyAccum(
            @RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken,
            @RequestParam(value = "productGroupType", defaultValue = "MED") String productGroupType) {
        log.info("[MED.ACCUM.FAM] Retrieving Family Member Accumulation Periods");
        return Optional.ofNullable(Unirest.get(famAccumUri)
                .header(HttpHeaders.AUTHORIZATION, authBearerToken)
                .queryString(PRODUCT_TYPE, productGroupType.toUpperCase())
                .proxy(proxyHost, proxyPort)
                .asObject(AccumFamRes.class)
                .getBody());
    }


    @GetMapping("getPlanAccum") public Optional<PlanAccumRes> getPlanAccum(
            @RequestParam(value = "authBearerToken", defaultValue = "${auth.bearer.token}") String authBearerToken,
            @RequestParam(value = "famMemberId", defaultValue = "1.1") String famMemberId,
            @RequestParam(value = "accumBeginDate", defaultValue = "2023-01-01") String accumBeginDate,
            @RequestParam(value = "accumEndDate", defaultValue = "2023-12-31") String accumEndDate,
            @RequestParam(value = "networkCategory", defaultValue = "INN") String networkCategory) {
        log.info("[MED.ACCUM.PLAN] Retrieving Medical Plan Accumulators - {}", networkCategory);
        return Optional.ofNullable(Unirest.get(medAccumUri)
                .header(HttpHeaders.AUTHORIZATION, authBearerToken)
                .queryString(FAMILY_MEMBER_ID, famMemberId)
                .queryString(ACCUM_START, accumBeginDate)
                .queryString(ACCUM_FINISH, accumEndDate)
                .queryString(ACCUM_CAT, networkCategory)
                .proxy(proxyHost, proxyPort)
                .asObject(PlanAccumRes.class)
                .getBody());
    }
}

# Getting Started
### Overview
Smart Health Data Aggregation Services

&nbsp;
### Setup
1. Clone Repository Locally
```shell
git clone https://git.express-scripts.com/ExpressScripts/smart-data.git

-- OR --

git clone git@git.express-scripts.com:ExpressScripts/smart-data.git
```
2. CD into the Newly Cloned Repository
```shell
cd smart-data
```
3. Ignore Local Properties File
```shell
git update-index --skip-worktree src/main/resources/local.properties
```

&nbsp; 
### API Reference
#### Swagger UI

```http
  GET http://localhost:8080/swagger-ui
```

&nbsp;
### Reference Documentation
For further reference, please consider the following sections:

* [Spring Web](https://docs.spring.io/spring-boot/docs/3.0.6/reference/htmlsingle/#web)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/3.0.6/maven-plugin/reference/html/#build-image)
* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/3.0.6/maven-plugin/reference/html/)
  
&nbsp;
### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)


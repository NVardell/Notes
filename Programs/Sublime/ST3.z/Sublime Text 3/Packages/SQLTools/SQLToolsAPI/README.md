## SQLTools API for plugins - v0.2.5

Docs will be ready soon

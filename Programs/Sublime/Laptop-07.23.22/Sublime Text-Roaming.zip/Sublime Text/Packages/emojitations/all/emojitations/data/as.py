from emojitations.emojitypes import EmojiAnnotations
emoji = [
  ]
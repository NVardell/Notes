# sublime-emojitations

[![The MIT License](https://img.shields.io/badge/license-MIT-orange.svg?style=flat-square)](http://opensource.org/licenses/MIT)
[![GitHub](https://img.shields.io/github/release/idleberg/sublime-emojitations.svg?style=flat-square)](https://github.com/idleberg/sublime-emojitations/releases)
[![PyPI](https://img.shields.io/pypi/v/emojitations.svg?style=flat-square)](https://pypi.python.org/pypi/emojitations)

Sublime Text dependency of emojitations, a library for using Unicode emoji annotations

Original Package by K.C. Saff:

* [GitHub](https://github.com/kcsaff/emojitations)
* [PyPI](https://pypi.python.org/pypi/emojitations/)

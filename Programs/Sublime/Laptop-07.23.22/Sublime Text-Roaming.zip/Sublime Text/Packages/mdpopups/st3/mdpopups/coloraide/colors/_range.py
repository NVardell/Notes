"""Range."""


class Angle(float):
    """Angle type."""


class Percent(float):
    """Percent type."""

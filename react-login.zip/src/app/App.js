import './App.css';
import LoginForm from "../pages/login";

function App() {
    return (
        <div className="container">
            <LoginForm/>
        </div>
    );
}

export default App;

##
## Williams, Brittney 10/11/2022 11:42 AM • 
    • 'Name'
    • 'Title'
    • 'Location'
    • 'Brief Bio'  (1 sentence each)
        1. Strengths in Current Position
        2. Interests
        3. Hobbies
        4. Family

Nate V.
Engineer
Kalamazoo, MI


A relentless optimist, undeterred by failure or the unknown, endlessly fuels my passion for formulating uniquely woven intricate solutions. 
When I’m not working or nerd-ing out on my statistical analytics pet project, I’m out seein’ movies or outside workin’ on my car. 
In my downtime, I enjoy building computers and solving Rubik’s Cubes of all shapes & sizes. 


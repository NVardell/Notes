// IMPORTANT - If adding/changing paths, update both routeConstants.js & pageInfo.js
export const HOME_PATH = '/'
export const CONTACT_US_PATH = '/contact-us'
export const DIVE_NEURODIVERSITY_PATH = '/neuro'
export const DIVE_SECURE_MESSAGING_PATH = '/secure-browsing'
export const DIVE_PREFERRED_ALTERNATIVES_PATH = '/ppa'
export const LOGIN_CALLBACK = '/login/callback'

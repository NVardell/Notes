import { ICON, LOGO, PILL } from './image.constants'

export const RPT_TITLE_TEXT = 'RPT'
export const RPT_RAPTOR_LOGO = '/images/rpt-logo.svg'
export const carouselSpeed = 3000

const host = window.location.origin
const services = `${host}/images/home/services/`
const homeImagePath = `${host}/images/home/`
const projectBriefsUri = `${host}/images/home/briefs/`
const teamHeadshotUri = `${host}/images/team/`
const teamBiosUri = `${host}/images/team/bio/`


export const NAV_LINK_TEXT = {
    HOME: 'Home',
    PORTFOLIO: 'Portfolio',
    ABOUT: 'About',
    CONTACT: 'Contact',
    TERMS_OF_USE: 'Terms of Use',
    PRIVACY_POLICY: 'Privacy Policy',
}

export const HOME_CARDS = [
    { title: 'Who We Are',    imgSrc: `${homeImagePath}who-we-are.svg` },
    { title: 'What We Do',    imgSrc: `${homeImagePath}what-we-do.svg` },
    { title: 'Why We Exist',  imgSrc: `${homeImagePath}why-we-exist.svg` },
]

export const HOME_BANNER_DETAILS = {
    title: `Rapid
        Prototyping
        Team`,
    content: `We can help your business advance through solution design, using a data-driven, collaborative learning approach`,
}

export const OUR_BELIEF_CARDS = [
    {
        title: 'Partner',
        imageStyles: { backgroundImage: `url(${host}/images/home/belief/belief-partner.svg)` },
        description: 'Partner alongside clients and stakeholders for consultative, end-to-end solution design support',
    },
    {
        title: 'Hypothesize',
        imageStyles: { backgroundImage: `url(${host}/images/home/belief/belief-hypo.svg)` },
        description: 'Orient around key hypotheses to develop a roadmap that delivers insights aimed at answering the hypotheses',
    },
    {
        title: 'Demonstrate',
        imageStyles: { backgroundImage: `url(${host}/images/home/belief/belief-demo.svg)` },
        description: 'Build prototypes and tests to help vet desirability, feasibility and visibility to move forward',
    },
]
export const OUR_SERVICES_CARDS = [
    { title: 'Consultation',      imageSrc: ICON.CONSULTATION, modalImageSrc: `${services}service-consult-v2.svg` },
    { title: 'Learning Strategy', imageSrc: ICON.LEARNING,     modalImageSrc: `${services}service-learning-v2.svg` },
    { title: 'Wireframe',         imageSrc: ICON.WIREFRAME,    modalImageSrc: `${services}service-wireframe-v2.svg` },
    { title: 'Prototype',         imageSrc: ICON.PROTOTYPE,    modalImageSrc: `${services}service-prototype-v2.svg` },
    { title: 'Testing',           imageSrc: ICON.TESTING,      modalImageSrc: `${services}service-testing-v2.svg` },
    { title: 'Proof Points',      imageSrc: ICON.PROOF_POINT,  modalImageSrc: `${services}service-proof-point-v2.svg` },
]


//
//      HOME PAGE | PROJECT BRIEFS
//
export const projectBriefs = [
    { imageSrc: `${projectBriefsUri}v3.svg`,        shortTitle: 'v3',        title: 'Verifiable Vaccine View', },
    { imageSrc: `${projectBriefsUri}ohc.svg`,       shortTitle: 'ohc',       title: 'Online Health Community', },
    { imageSrc: `${projectBriefsUri}maternal.svg`,  shortTitle: 'maternal',  title: 'MATERNAL POP-INS', },
    { imageSrc: `${projectBriefsUri}360.svg`,       shortTitle: 'hc360',     title: 'BEHAVIORAL HEALTH HC360 SALES DEMO', },
    { imageSrc: `${projectBriefsUri}cme.svg`,       shortTitle: 'cme',       title: 'Consumer Mediated Exchange', },
]

export const projectBriefBubbles = [
    {
        altText: 'Pain Point',
        className: 'pain-pill',
        imgClasses: 'img-fluid cursor-pointer zoomImage',
        imgSrc: PILL.PAIN,
        modalImage: 'pain.svg',
    },
    {
        altText: 'Goal',
        className: 'goal-pill',
        imgClasses: 'img-fluid cursor-pointer zoomImage',
        imgSrc: PILL.GOAL,
        modalImage: 'goal.svg',
    },
    {
        altText: 'Solution',
        className: 'solution-pill',
        imgClasses: 'img-fluid cursor-pointer zoomImage',
        imgSrc: PILL.SOLUTION,
        modalImage: 'solution.svg',
    },
]

//
//      HOME PAGE ~ MEET THE TEAM
//
export const teamBios = [
    { name: 'Akhila',   imageSrc: `${teamHeadshotUri}akhila.svg`,   modalImageSrc: `${teamBiosUri}akhila-bio.svg` },
    { name: 'Brittney', imageSrc: `${teamHeadshotUri}brittney.svg`, modalImageSrc: `${teamBiosUri}brittney-bio.svg` },
    { name: 'Jackie',   imageSrc: `${teamHeadshotUri}jackie.svg`,   modalImageSrc: `${teamBiosUri}jackie-bio.svg` },
    { name: 'James',    imageSrc: `${teamHeadshotUri}james.svg`,    modalImageSrc: `${teamBiosUri}james-bio.svg` },
    { name: 'Jeremy',   imageSrc: `${teamHeadshotUri}jeremy.svg`,   modalImageSrc: `${teamBiosUri}jeremy-bio.svg` },
    { name: 'Joel',     imageSrc: `${teamHeadshotUri}joel.svg`,     modalImageSrc: `${teamBiosUri}joel-bio.svg` },
    { name: 'Kimberly', imageSrc: `${teamHeadshotUri}kimberly.svg`, modalImageSrc: `${teamBiosUri}kimberly-bio.svg` },
    { name: 'Melissa',  imageSrc: `${teamHeadshotUri}melissa.svg`, modalImageSrc: `${teamBiosUri}melissa-bio.svg` },
    { name: 'Nate',     imageSrc: `${teamHeadshotUri}nate.svg`,     modalImageSrc: `${teamBiosUri}nate-bio.svg` },
    { name: 'Nava',     imageSrc: `${teamHeadshotUri}nava.svg`,     modalImageSrc: `${teamBiosUri}nava-bio.svg` },
    { name: 'Sara',     imageSrc: `${teamHeadshotUri}sara.svg`,     modalImageSrc: `${teamBiosUri}sara-bio.svg` },
    { name: 'Stefani',  imageSrc: `${teamHeadshotUri}stefani.svg`,  modalImageSrc: `${teamBiosUri}stefani-bio.svg` },
    { name: 'Swapna',   imageSrc: `${teamHeadshotUri}swapna.svg`,   modalImageSrc: `${teamBiosUri}swapna-bio.svg` },
    { name: 'Teja',     imageSrc: `${teamHeadshotUri}teja.svg`,     modalImageSrc: `${teamBiosUri}teja-bio.svg` },
]

export const CONTACTS = [
    { altText: 'evernorth-logo',       imgSrc: LOGO.EVERNORTH },
    { altText: 'cigna-logo',           imgSrc: LOGO.CIGNA },
    { altText: 'express-scripts-logo', imgSrc: LOGO.ESI },
]

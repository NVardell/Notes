const BG = {
    HIGH_TIDE: '/images/common/background/wave-high-tide.svg',
    LOW_TIDE: '/images/common/background/wave-low-tide.svg',
    NO_TIDE: '/images/common/background/wave-no-tide.svg',
    HEX_BLUE: '/images/common/background/hex-blue.svg',
    HEX_BLUE_GREEN: '/images/common/background/hex-blue-green.svg',
    HEX_BLUE_TRANS: '/images/common/background/hex-blue-trans.svg',
}

const CLOUD = {
    0: '/images/common/cloud/cloud-1.svg',
    1: '/images/common/cloud/cloud-2.svg',
    2: '/images/common/cloud/cloud-3.svg',
    3: '/images/common/cloud/cloud-4.svg',
}

const COMMON = {
    ARROW_WHITE: '/images/common/white-arrow.svg',
}

const ICON = {
    CONSULTATION: '/images/common/icon/sunset-hex.svg',
    ITERATE:      '/images/common/icon/touch-2.svg',       // Diff ID
    LEARNING:     '/images/common/icon/light-bulb-hex.svg',
    PROOF_POINT:  '/images/common/icon/touch-hex.svg',
    PROTOTYPE:    '/images/common/icon/gears-hex.svg',
    PROTOTYPE_2:  '/images/common/icon/light-bulb-2.svg',  // Diff Icon
    RESEARCH:     '/images/common/icon/microscope-2.svg',  // Diff ID
    TESTING:      '/images/common/icon/microscope-hex.svg',
    TESTING_2:    '/images/common/icon/gears-2.svg',       // Diff Icon
    WIREFRAME:    '/images/common/icon/wireframe-hex.svg',
    WIREFRAME_2:  '/images/common/icon/wireframe-2.svg',   // Diff Border
}

const LOGO = {
    ESI: '/images/common/logo/express-scripts-logo.svg',
    CIGNA: '/images/common/logo/cigna-logo.svg',
    EVERNORTH: '/images/common/logo/evernorth-logo.svg',
}

const PILL = {
    GOAL: '/images/common/pill/goal-pill.svg',
    PAIN: '/images/common/pill/pain-pill.svg',
    SOLUTION: '/images/common/pill/solution-pill.svg',
}

export { BG, CLOUD, COMMON, ICON, LOGO, PILL }

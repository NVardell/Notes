import { ICON, LOGO } from './image.constants'

const DIVE = {
    PPA: 'PPA',
    SND: 'SND',
    IMC: 'IMC',
}

const PROCESS = {
    STEPS: [
        { title: 'Research',  icon: ICON.RESEARCH,    },
        { title: 'Wireframe', icon: ICON.WIREFRAME_2, },
        { title: 'Prototype', icon: ICON.PROTOTYPE_2, },
        { title: 'Test',      icon: ICON.TESTING_2,   },
        { title: 'Iterate',   icon: ICON.ITERATE,     },
    ],
}

const PERSONAL = {
    PROJECT: 'Personalized Preferred Alternatives',
    ACRONYM: DIVE.PPA,
    INTRO: {
        TEXT: [
            'Health providers need to make informed decisions to offer the best medication to their patients.  In order to remain competitive, Rational Med has the opportunity to evolve and include additional member data points to optimize ideal medication recommendations.  We started by determining a feasible solution in which rules and datasets are leveraged and filtered to offer data for clinicians.',
        ],
    },
    SECRET: 'RPT delivered the prototype in nine months, with three backend developers, one designer, and collaboration from multiple teams assisting in gathering the necessary data.',
    TESTS: [
        { theory: '/images/ppa/q1.svg', reason: '/images/ppa/a1.svg' },
        { theory: '/images/ppa/q2.svg', reason: '/images/ppa/a2.svg' },
    ],
    STEPS: [
        'Which alternative prescription drugs would work better for the patient? What clinical events? What caused the clinical event to be triggered?',
        'We built a wireframe based on patients’ currently available lab, medical and pharmacy information, presenting alternatives ranging from good, better, to best.',
        'The prototype generates a report that shows medication alternatives, based on patient medical history, related conditions and medications.',
        'A dummy claim layout was created with a list of columns provided by RMED to determine if any alternatives interact with patient’s history.',
        'We began with an initial design which eventually evolved into a detailed report. We are currently iterating the design as we consider how to add more valuable patient data into the report that would help the provider make a more informed decision for patient care.',
    ],
    FOOTER: {
        IMAGE: 'ppa/ppa-footer.svg',
        TEXT: 'As we continue to test, iterate, and further develop the prototype based on insightful feedback from our partners, we discover more ways to improve our product to assist clinicians and ultimately provide quality, affordable care for patients.',
    },
}

const NEURO = {
    PROJECT: 'Supporting Neurodiversity',
    ACRONYM: DIVE.SND,
    INTRO: {
        TEXT: [
            'We met with the team who had done extensive research with parents and caregivers of those with Autism to understand what they had learned so far, what they were hoping to achieve in RPT’s partnership with them, and their timelines ahead of the build for partners and caregivers.',
            'Our concept owners were focused on understanding desirability of their target audience for their proposed solution.',
        ],
    },
    SECRET: 'RPT completed this concept in one month with one designer and one front end developer. We made three iterations, changing based on business feedback, and enlisted testing services from our partnered vendor, dscout.',
    TESTS: [
        { theory: '/images/neuro/q1.svg', reason: '/images/neuro/a1.svg' },
        { theory: '/images/neuro/q2.svg', reason: '/images/neuro/a2.svg' },
    ],
    STEPS: [
        'How could we structure the site to get feedback from parents? What designs do we want to begin with? Where will we get our target audience to test with?',
        'We began with a wireframe from the original research with parents. The wireframe was critical to ensuring the website design matched our concept owner’s needs and initial hypothesis. ',
        'After agreeing on the wireframes, RPT built a sandbox website with tracking analytics built in to every section to understand what users clicked first, where they stayed the longest and what they came back to. The link was taken down as soon as testing was over and no reference to our clients was made on the site. ',
        'We leveraged our partnership with dscout, a vendor partner, to find parents and caregivers of children with Autism. We gave dscout the link to the sandbox website to collect quantitative metrics and qualitative survey metrics. We ran the test for two weeks and learned an immense amount.',
        'After the test it became clear we needed to refine the scope of the site and narrow the audience, but our concept owners were still questioning the layout and imagery so we updated the prototype designs and tested again.',
    ],
    ITERATIONS: '/images/neuro/neuro-iterations.svg',
    FOOTER: {
        IMAGE: 'neuro/neuro-footer.svg',
        TEXT: 'The Developmental Milestones webpage directing parents went live. Without first building the experience we heard was valued and testing it, we would have released something to market that would have missed the mark for parents, and at the very worst turned them off to our help at a critical time of engagement and support.',
    },
}

const SECURE = {
    PROJECT: 'Secure Browser Messaging',
    ACRONYM: DIVE.IMC,
    INTRO: {
        IMAGE: LOGO.ESI,
        TEXT: [
            'Express Scripts Pharmacy already had a relationship with a texting vendor, and RPT was charged with expanding that relationship in partnership with our internal technology teams to include secure browser messaging. We started with a use case of prior authorization gaps in information to determine the desirability and viability of this use case and technology.',
        ],
    },
    SECRET: 'RPT delivered this prototype in eight months, with two front end developers and two backend developers, and collaborating with the Conversational AI team. We partnered with our internal iNetwork group to complete testing and gather insights.',
    TESTS: [
        { theory: '/images/secure/q1.svg', reason: '/images/secure/a1.svg' },
        { theory: '/images/secure/q2.svg', reason: '/images/secure/a2.svg' },
        { theory: '/images/secure/q3.svg', reason: '/images/secure/a3.svg' },
        { theory: '/images/secure/q4.svg', reason: '/images/secure/a4.svg' },
    ],
    STEPS: [
        'How could we structure the internal testing to get feedback on industry best practices for high trust SMS communications? We also tested branding once the member was in the secure browser messaging environment. ',
        'We began with a wireframe incorporating research on SMS and industry best practices for building trust in digital communications. ',
        'Our prototype build was twofold:\n1) Build a secure browser messaging environment for test and learn scenarios\n2) Create an internal employee test to feed insights to production teams going live with the first use cases for secure browser messaging.',
        'We leveraged our internal employees through a variety of channels, to solicit enough testers to determine if the technology worked with over 50 people, and how we could improve our trust with members with this technology. ',
        'The iteration for the secure browser messaging environment will need to happen on a use case by use case basis, determined by content, desired functionality, and user population.',
    ],
    FOOTER: {
        IMAGE: 'secure/secure-footer.svg',
        TEXT: 'The product owner is looking to pilot Secure Browser use cases in 2023 based on the proof points and learnings RPT uncovered in the prototyping process.',
    },
}

export { DIVE, PERSONAL, PROCESS, NEURO, SECURE }

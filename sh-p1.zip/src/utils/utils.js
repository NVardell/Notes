export const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
}

// Randomly shuffle Carousel Cards
export const shuffleArray = arr => arr.sort(() => 0.5 - Math.random())

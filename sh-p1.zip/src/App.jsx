import './App.css'
import { LoginCallback, Security } from '@okta/okta-react'
import { OktaAuth, toRelativeUrl } from '@okta/okta-auth-js'
import { useMemo } from 'react'
import { Route, Routes, useNavigate } from 'react-router-dom'

import DefaultLayout from './layouts/DefaultLayout'
import Home from './pages/Home'
import Neuro from './pages/Neuro'
import About from './pages/About'
import Contact from './pages/Contact'
import NotFoundPage from './pages/PageNotFound'
import SecureBrowsing from './pages/SecureBrowsing'
import PPA from './pages/PPA'
import { oktaConfig } from './config'
import { AnalyticsManager } from './analytics'

function App() {
    const navigate = useNavigate()
    const oktaAuth = useMemo(
        () =>
            new OktaAuth({
                issuer: oktaConfig.issuer,
                clientId: oktaConfig.clientId,
                redirectUri: `${oktaConfig.reDirectUri}/login/callback`,
                scopes: ['openid', 'email', 'detail'],
                pkce: true,
            }),
        []
    )

    const restoreOriginalUri = async (_oktaAuth, originalUri) => {
        const basepath = navigate({})
        const originalUriWithoutBasepath = originalUri.replace(basepath, '/')
        navigate(toRelativeUrl(originalUriWithoutBasepath, window.location.origin))
    }

    window.onpopstate = () => {
        navigate('/')
    }

    return (
        <Security oktaAuth={oktaAuth} restoreOriginalUri={restoreOriginalUri}>
            <Routes>
                <Route path='/' element={<DefaultLayout />}>
                    <Route index element={<Home />} />
                    <Route path='neuro' element={<Neuro />} />
                    <Route path='secure-browsing' element={<SecureBrowsing />} />
                    <Route path='ppa' element={<PPA />} />
                    <Route path='about' element={<About />} />
                    <Route path='contact' element={<Contact />} />
                    <Route path='*' element={<NotFoundPage />} />
                    <Route path='/login/callback' element={<LoginCallback />} />
                </Route>
            </Routes>
            <AnalyticsManager />
        </Security>
    )
}

export default App

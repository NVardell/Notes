import Stack from '@mui/material/Stack'
import React, { useEffect, memo } from 'react'
import { scrollToTop } from '../../utils/utils'

const Contact = () => {
    useEffect(() => {
        scrollToTop()
    }, [])

    return (
        <Stack alignItems='center' sx={{ minHeight: '100vh' }}>
            <h1>Contact</h1>
        </Stack>
    )
}

export default memo(Contact)

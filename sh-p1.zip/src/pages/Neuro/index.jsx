import React, { memo } from 'react'
import {
    DiveFooter,
    DiveHeader,
    DiveIntro,
    DiveJourney,
    DiveProcess,
    DiveSecret,
    DiveTest,
} from '../../components/dive'
import { NEURO } from '../../utils/dive.constants'

const Neuro = () => (
    <>
        {/*  Deep Dive Splash Landing Banner  */}
        <DiveHeader
            title='Supporting Neurodiversity'
            acronym={NEURO.ACRONYM}
            overlay='neuro/vector-net.svg'
            centerImage='neuro/brain.svg'
            goalModalImage='neuro/goal-modal.svg'
            painModalImage='neuro/pain-point-modal.svg'
            solutionModalImage='neuro/solution-modal.svg'
        />

        {/*  How We Got Started  */}
        <DiveIntro deepDiveDescription={NEURO.INTRO.TEXT} />

        {/*  What We Set Out to Learn  */}
        <DiveTest listOfTheories={NEURO.TESTS} />

        {/*  Secret Sauce  */}
        <DiveSecret saucyDescription={NEURO.SECRET} />

        {/*  RPT Process  */}
        <DiveProcess stepDescriptions={NEURO.STEPS} hasIterations />

        {/*  Iterations  */}
        <DiveJourney sectionTitle='Iteration Journey' sectionImage={NEURO.ITERATIONS} />

        {/*  Where Are We Now?  */}
        <DiveFooter deepDiveConclusion={NEURO.FOOTER.TEXT} footerImage={NEURO.FOOTER.IMAGE} />
    </>
)

export default memo(Neuro)

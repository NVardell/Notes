import React, { memo } from 'react'
import { DiveFooter, DiveHeader, DiveIntro, DiveProcess, DiveSecret, DiveTest } from '../../components/dive'
import { PERSONAL } from '../../utils/dive.constants'

const PPA = () => (
    <>
        {/*  Deep Dive Splash Landing Banner  */}
        <DiveHeader
            shrinkTitle
            title='Personalized Preferred Alternatives'
            acronym={PERSONAL.ACRONYM}
            overlay='ppa/plus-signs.svg'
            centerImage='ppa/pill-bottle.svg'
            goalModalImage='ppa/ppa-goal-modal.svg'
            painModalImage='ppa/ppa-pain-modal.svg'
            solutionModalImage='ppa/ppa-solution-modal.svg'
        />

        {/*  How We Got Started  */}
        <DiveIntro deepDiveDescription={PERSONAL.INTRO.TEXT} />

        {/*  What We Set Out to Learn  */}
        <DiveTest listOfTheories={PERSONAL.TESTS} />

        {/*  Secret Sauce  */}
        <DiveSecret saucyDescription={PERSONAL.SECRET} />

        {/*  RPT Process  */}
        <DiveProcess stepDescriptions={PERSONAL.STEPS} />

        {/*  Where Are We Now?  */}
        <DiveFooter deepDiveConclusion={PERSONAL.FOOTER.TEXT} footerImage={PERSONAL.FOOTER.IMAGE} />
    </>
)

export default memo(PPA)

import { Box, Container, Grid } from '@mui/material'
import { memo } from 'react'
import ImageCard from '../../components/cards/ImageCard'
import { HOME } from './Home.style.js'
import { OUR_BELIEF_CARDS } from '../../utils/constants'
import { BG } from '../../utils/image.constants'

const OurBeliefs = props => {
    const { isMobile } = props
    return (
        <>
            {/*<img src={BG.HEX_BLUE_TRANS} className='belief-bg' alt='hex bg' />*/}
            <Container
                component='div'
                sx={{ ...HOME.CONTAINER,
                    // marginTop: '-35rem',
                    backgroundImage: `url(${BG.HEX_BLUE_TRANS})`,
                    backgroundRepeat: 'no-repeat' }}
            >
                <Box component='header' sx={HOME.TITLE}>
                    OUR BELIEFS
                </Box>
                <Grid container sx={{ display: 'flex', flexDirection: isMobile ? 'column' : 'row' }}>
                    {OUR_BELIEF_CARDS.map(({ title, imageStyles, description }) => (
                        <Grid key={title} item lg={4} md={12} sx={HOME.STACK}>
                            <ImageCard title={title} imageStyles={imageStyles} description={description} titleBelow />
                        </Grid>
                    ))}
                </Grid>
            </Container>
        </>
    )
}

export default memo(OurBeliefs)

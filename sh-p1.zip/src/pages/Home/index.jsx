import { Box, Container, Grid, Typography, useMediaQuery, useTheme } from '@mui/material'
import { useOktaAuth } from '@okta/okta-react'
import React, { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import ContactUs from './ContactUs'
import { HOME } from './Home.style.js'
import { HOME_BANNER_DETAILS, HOME_CARDS } from '../../utils/constants'
import { scrollToTop } from '../../utils/utils'

import OurBeliefs from './Beliefs'
import OurServices from './Services'
import OurPortfolio from './Portfolio'
import OurTeam from './Team'

const host = window.location.origin

export default function Home() {
    const { authState, oktaAuth } = useOktaAuth()
    const location = useLocation()
    const theme = useTheme()
    const isMobile = useMediaQuery(theme.breakpoints.down('md'))
    const target = location.state?.target || ''

    useEffect(() => {
        scrollToTop()
    }, [])

    useEffect(() => {
        const authenticate = async () => {
            if (!authState) return

            if (!authState.isAuthenticated) {
                await oktaAuth.signInWithRedirect({ originalUri: '/' })
            }
        }

        authenticate()
    }, [authState, oktaAuth])

    useEffect(() => {
        if (target && authState?.isAuthenticated) {
            const scrollToDiv = document.getElementById(target).offsetTop
            window.scrollTo({ top: scrollToDiv - 70, behavior: 'smooth' })
        }
    }, [target, authState?.isAuthenticated])

    if (!authState?.isAuthenticated) {
        return (
            <Box sx={{ ...HOME.CONTAINER, minHeight: '100vh' }}>
                <Typography component='h4' variant='h4' sx={{ mb: '4rem', marginTop: '4rem', textAlign: 'center' }}>
                    Please wait while we sign you in
                </Typography>
            </Box>
        )
    }

    return (
        <Box sx={{ ...HOME.CONTAINER, ...HOME.HEADER }}>
            <Container
                component='article'
                style={{ ...HOME.BANNER, backgroundImage: `url("${host}/images/home/glowing-light-bulb.gif")` }}
            >
                <Box component='header' sx={HOME.TITLE}>
                    {HOME_BANNER_DETAILS.title}
                </Box>
                <Box component='section' sx={HOME.SUBTITLE} style={{ maxWidth: '50%', margin: '2rem 0' }}>
                    {HOME_BANNER_DETAILS.content}
                </Box>
            </Container>
            <Container maxWidth='xl' component='div' sx={{ display: 'flex', flexDirection: 'row', margin: '3rem' }}>
                <Grid container>
                    {HOME_CARDS.map(({ title, imgSrc }) => (
                        <Grid
                            component='article'
                            key={title}
                            item
                            lg={4}
                            sx={{
                                width: '100%',
                                padding: '2rem',
                                transform: 'translateX(4em)',
                            }}
                        >
                            <img alt={title} src={imgSrc} />
                        </Grid>
                    ))}
                </Grid>
            </Container>
            <OurBeliefs isMobile={isMobile} />
            <OurServices isMobile={isMobile} />
            <OurPortfolio isMobile={isMobile} />
            <OurTeam isMobile={isMobile} />
            <ContactUs isMobile={isMobile} />
        </Box>
    )
}

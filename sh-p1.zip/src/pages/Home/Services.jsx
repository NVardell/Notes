import { Box, Container, Grid, Typography } from '@mui/material'
import React, { memo, useState } from 'react'
import Card from '../../components/cards/Card'
import ImageModal from '../../components/modal/ImageModal'
import { HOME } from './Home.style.js'
import { OUR_SERVICES_CARDS } from '../../utils/constants'
import { BG } from '../../utils/image.constants'

const OurServices = props => {
    const [openModal, setOpenModal] = useState(false)
    const [serviceImage, setServiceImage] = useState('')
    const [serviceTitle, setServiceTitle] = useState()

    return (
        // <Box sx={{ ...HOME.CONTAINER, ...HOME.SERVICE_HEADER }}>
        <>
            <img src={BG.HEX_BLUE_GREEN} width='100%' height='90%' alt='hex bg' />
            <Container
                className='service-container'
                component='div'
                sx={{
                    ...HOME.CONTAINER,
                    marginTop: '-75rem',
                    // backgroundImage: `url(${BG.HEX_BLUE_GREEN})`,
                    // backgroundPosition: 'top center',
                    // backgroundRepeat: 'no-repeat',
                    // backgroundSize: 'cover',
                }}
            >
                <Box component='header' sx={HOME.TITLE}>
                    OUR SERVICES
                </Box>
                <Box component='section' sx={HOME.SUBTITLE} style={{ textAlign: 'center', marginBottom: '3rem' }}>
                    We provide the following services for your project needs. Our previous and current projects may be
                    viewed below.
                </Box>
                <Card component='section' sx={{ backgroundColor: 'unset' }}>
                    <Grid container sx={{ textAlign: 'center'}} spacing={0}>
                        {OUR_SERVICES_CARDS.map(({ title, imageSrc, modalImageSrc }) => (
                            <Grid key={title} item lg={4} sm={6} xs={12}>
                                <Box
                                    sx={{ cursor: 'pointer', display: 'contents' }}
                                    onClick={() => {
                                        setOpenModal(true)
                                        setServiceImage(modalImageSrc)
                                        setServiceTitle(title)
                                    }}
                                >
                                    <img
                                        title={title.toUpperCase()}
                                        role='button'
                                        className='zoomImage'
                                        src={imageSrc}
                                        alt={title}
                                        width='250px' //65%
                                    />
                                    <Typography sx={HOME.SUBTITLE} style={{ margin: '1rem 0' }}>
                                        {title}
                                    </Typography>
                                </Box>
                            </Grid>
                        ))}
                    </Grid>
                </Card>
            </Container>
            {openModal && (
                <ImageModal
                    isCircleImage
                    open={openModal}
                    title={serviceTitle}
                    closeIconColor='ffffff'
                    handleClose={() => setOpenModal(false)}
                >
                    <img src={serviceImage} alt='our-service-big-images' style={{ height: '70vh' }} />
                </ImageModal>
            )}
        {/*</Box>*/}
            </>
    )
}

export default memo(OurServices)

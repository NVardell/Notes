import { Box, Container, Grid, Stack, Typography, useTheme } from '@mui/material'
import { memo } from 'react'
import { HOME } from './Home.style.js'
import Card from '../../components/cards/Card'
import { CONTACTS } from '../../utils/constants'

const host = window.location.origin
const ContactUs = props => {
    const theme = useTheme()

    return (
        <Container
            id='contact-us'
            component='div'
            style={{
                ...HOME.CONTAINER,
                marginTop: '1rem',
                textAlign: 'center',
                position: 'relative',
            }}
        >
            <img
                src={`${host}/images/home/contact/plane-animation.gif`}
                alt='Mail-Fly'
                style={{ zIndex: 2, position: 'absolute', top: '-5rem' }}
            />
            <Box component='header' sx={HOME.TITLE}>
                CONTACT US
            </Box>
            <img src={`${host}/images/home/contact/contact-us.svg`} alt='Contact Us' style={{ zIndex: 1 }} />
            <Card
                sx={{
                    minHeight: '300px',
                    marginTop: theme.spacing(-3),
                }}
                component='section'
            >
                <Stack sx={{ textAlign: 'center' }} spacing={theme.spacing(3)}>
                    <Typography
                        sx={HOME.SUBTITLE}
                        style={{
                            marginTop: theme.spacing(5),
                            marginBottom: theme.spacing(3),
                        }}
                    >
                        Interested in working with us?
                    </Typography>
                    <Typography sx={{ ...HOME.CONTENT, zIndex: '3' }}>
                        If you would like to partner with Rapid Prototyping Team, please contact Sara Allen at{' '}
                        <a href='mailto: sara.allen@evernorth.com' style={{ color: 'white' }}>
                            sara.allen@evernorth.com
                        </a>
                    </Typography>
                    <Typography sx={{ ...HOME.CONTENT, zIndex: '3' }}>
                        If you are interested in joining our team, please contact Jackie Luong at{' '}
                        <a href='mailto: jacqueline.luong@evernorth.com' style={{ color: 'white' }}>
                            jacqueline.luong@evernorth.com
                        </a>
                    </Typography>
                </Stack>
            </Card>
            <Grid container spacing={2} sx={{ marginTop: '8rem' }}>
                {CONTACTS.map(contact => (
                    <Grid item xs={4} title={contact.altText} key={contact.altText}>
                        <Box
                            component='div'
                            sx={{
                                backgroundImage: `url(${host}${contact.imgSrc})`,
                                backgroundPosition: 'center',
                                backgroundRepeat: 'no-repeat',
                                backgroundSize: 'contain',
                                height: '6rem',
                            }}
                        />
                    </Grid>
                ))}
            </Grid>
        </Container>
    )
}

export default memo(ContactUs)

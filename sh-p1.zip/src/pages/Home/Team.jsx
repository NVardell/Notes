import { Box, Container } from '@mui/material'
import React, { memo } from 'react'
import { HOME } from './Home.style'
import { RPT_RAPTOR_LOGO } from '../../utils/constants'
import TeamBios from './sections/TeamBios'

const OurTeam = props => (
    <Container component='div' style={HOME.CONTAINER} className='team-container'>
        <Box component='header' sx={HOME.TITLE}>
            MEET THE TEAM
        </Box>
        <img
            src={RPT_RAPTOR_LOGO}
            alt='RPT Raptor Team Logo'
            style={{ display: 'inline-block', paddingBottom: '3rem', height: '190px' }}
        />
        <Container style={{ display: 'inline-block', paddingBottom: '3rem' }}>
            <TeamBios />
        </Container>
    </Container>
)

export default memo(OurTeam)

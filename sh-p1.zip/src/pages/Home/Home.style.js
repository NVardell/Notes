import { APP } from '../../styles/App.style'
import { BG } from '../../utils/image.constants'

const HOME = {
    HEADER: {
        backgroundImage: `url(${BG.HEX_BLUE})`,
        backgroundPosition: 'top left',
        backgroundRepeat: 'no-repeat',
        marginTop: '-3rem',
    },
    SERVICE_HEADER: {
        backgroundImage: `url(${BG.HEX_BLUE_GREEN})`,
        backgroundPosition: 'top left',
        backgroundRepeat: 'no-repeat',
        marginTop: '-3rem',
    },
    BANNER: {
        backgroundPosition: 'right',
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'auto',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        maxWidth: '1350px',
        minHeight: '80vh',
        objectFit: 'contain',
    },
    CONTAINER: {
        ...APP.CONTAINER,
    },
    TITLE: {
        ...APP.TITLE,
        maxWidth: '56%',
    },
    SUBTITLE: {
        ...APP.SUBTITLE,
    },
    STACK: {
        alignItems: 'center',
        display: 'flex',
        flexDirection: 'column',
        padding: '3rem',
    },
    CONTENT: {
        fontFamily: 'Roboto',
        fontSize: '1.375rem',
        fontWeight: 400,
        lineHeight: '2rem',
        letterSpacing: 0,
        textAlign: 'center',
    },
}

export { HOME }

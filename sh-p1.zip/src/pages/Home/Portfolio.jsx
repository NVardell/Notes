import { Box, Container, Grid, Typography, useTheme } from '@mui/material'
import React, { memo } from 'react'
import { useNavigate } from 'react-router-dom'

import { HOME } from './Home.style.js'
import ProjectBriefs from './sections/ProjectBriefs'

const host = window.location.origin

const OurPortfolio = props => {
    const { isMobile } = props
    const theme = useTheme()
    const navigate = useNavigate()

    return (
        <Container
            className='portfolio-container'
            id='our-portfolio'
            component='div'
            style={{ ...HOME.CONTAINER, marginTop: '1rem' }}
        >
            <Box component='header' sx={HOME.TITLE}>
                OUR PORTFOLIO
            </Box>
            <Container style={{ display: 'inline-block', paddingBottom: '3rem' }}>
                <Typography sx={HOME.SUBTITLE} style={{ textAlign: 'center', marginBottom: '4rem' }}>
                    Project Briefs
                </Typography>
                <ProjectBriefs />
            </Container>

            <Typography sx={HOME.SUBTITLE} style={{ textAlign: 'center', margin: '4rem 0' }}>
                Project Deep Dives
            </Typography>
            <Grid
                container
                sx={{ display: 'flex', flexDirection: 'row', textAlign: 'center' }}
                spacing={theme.spacing(2)}
            >
                <Grid item lg={8} md={12}>
                    <img
                        alt='NEURO'
                        className='cursor-pointer zoomImageMini'
                        style={{ width: isMobile ? '65%' : 'fit-content' }}
                        src={`${host}/images/home/dives/neuro.svg`}
                        onClick={() => navigate('neuro')}
                    />
                    <img
                        alt='SECURE BROWSING'
                        className='cursor-pointer zoomImageMini'
                        style={{
                            width: isMobile ? '65%' : 'fit-content',
                            marginTop: '1.5rem',
                        }}
                        src={`${host}/images/home/dives/secure.svg`}
                        onClick={() => navigate('secure-browsing')}
                    />
                </Grid>
                <Grid item lg={4} md={12}>
                    <img
                        alt='PPA'
                        className='cursor-pointer zoomImageMini'
                        {...(isMobile && {
                            style: {
                                height: 'auto',
                                width: '55%',
                                marginLeft: '12rem',
                            },
                        })}
                        src={`${host}/images/home/dives/ppa.svg`}
                        onClick={() => navigate('ppa')}
                    />
                </Grid>
            </Grid>
        </Container>
    )
}

export default memo(OurPortfolio)

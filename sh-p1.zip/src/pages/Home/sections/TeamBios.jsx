import Box from '@mui/material/Box'
import React, { memo, useState } from 'react'
import Carousel from '../../../components/carousel/Carousel'
import ImageModal from '../../../components/modal/ImageModal'
import { carouselSpeed, teamBios } from '../../../utils/constants'
import { shuffleArray } from '../../../utils/utils'

const TeamBios = () => {
    const [openModal, setOpenModal] = useState(false)
    const [profileBio, setProfileBio] = useState('')
    const [fullName, setFullName] = useState('')

    return (
        <>
            <Carousel
                slides={shuffleArray(teamBios).map(({ name, imageSrc, modalImageSrc }) => (
                    <Box
                        sx={{ cursor: 'pointer', display: 'contents' }}
                        onClick={() => {
                            setFullName(name)
                            setProfileBio(modalImageSrc)
                            setOpenModal(true)
                        }}
                    >
                        <img src={imageSrc} alt={name.toUpperCase()} role='button' />
                    </Box>
                ))}
                autoplay
                isOpen={openModal}
                interval={carouselSpeed}
                className='carousel-team'
            />
            {openModal && (
                <ImageModal
                    open={openModal}
                    handleClose={() => {
                        setOpenModal(false)
                    }}
                    closeIconColor='fff'
                >
                    <img src={profileBio} alt={fullName} style={{ height: '60vh' }} />
                </ImageModal>
            )}
        </>
    )
}

export default memo(TeamBios)

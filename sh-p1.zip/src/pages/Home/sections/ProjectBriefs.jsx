import './projectBriefs.css'
import { Box, Grid } from '@mui/material'
import React, { useState } from 'react'
import Carousel from '../../../components/carousel/Carousel'
import CustomModal from '../../../components/modal/CustomModal'
import ImageModal from '../../../components/modal/ImageModal'
import { carouselSpeed, projectBriefBubbles, projectBriefs } from '../../../utils/constants'
import { shuffleArray } from '../../../utils/utils'

const host = window.location.origin

const ProjectBriefs = props => {
    const [showProjectSummaryModal, setShowProjectSummaryModal] = useState(false)
    const [childModalDetails, setChildModalDetails] = useState({ openModal: false, imageSrc: '' })
    const [projectSummary, setProjectSummary] = useState({ title: '', modalImageSrc: '', shortTitle: '' })
    const { isMobile } = props

    React.useEffect(() => {}, [])
    return (
        <>
            <Grid container sx={{ textAlign: 'center' }} spacing={isMobile ? 8 : 4} justifyContent='center'>
                {projectBriefs.map(({ title, imageSrc, modalImageSrc, shortTitle }) => (
                    <Grid key={shortTitle} item lg={4} sm={6} xs={12}>
                        <Box
                            onClick={() => {
                                setShowProjectSummaryModal(true)
                                setProjectSummary({ title, modalImageSrc, shortTitle })
                            }}
                            sx={{ cursor: 'pointer', display: 'contents' }}
                        >
                            <img src={imageSrc} alt={shortTitle.toUpperCase()} role='button' className='zoom brief' width='95%' />
                        </Box>
                    </Grid>
                ))}
            </Grid>

            {showProjectSummaryModal && (
                <CustomModal
                    showCloseIcon
                    showHeader
                    title={projectSummary.title}
                    open={showProjectSummaryModal}
                    handleClose={() => {
                        setShowProjectSummaryModal(false)
                        setProjectSummary({ title: '', shortTitle: '', modalImageSrc: '' })
                    }}
                >
                    <Box position='relative' className='project-summary-container project-brief-box'>
                        <Box
                            component='div'
                            alt='project-summary'
                            className='project-brief-main'
                            sx={{
                                backgroundImage: `url(${host}/images/home/briefs/${projectSummary.shortTitle}/summary.svg)`,
                                backgroundPosition: 'center',
                                backgroundRepeat: 'no-repeat',
                                backgroundSize: 'contain',
                                height: '650px', // height of background modal
                                position: 'relative',
                                marginTop: 0,
                                borderRadius: '100px',
                            }}
                        />
                        <Box className='project-brief-images'>
                            {projectBriefBubbles.map(({ altText, className, imgClasses, imgSrc, modalImage }) => (
                                <Box className={className} aria-label={altText} key={altText}>
                                    <img
                                        title={`${projectSummary.shortTitle.toUpperCase()}:${altText.toUpperCase()}`}
                                        role='button'
                                        alt={altText}
                                        className={imgClasses}
                                        src={imgSrc}
                                        onClick={() => {
                                            setChildModalDetails({
                                                imageSrc: `${host}/images/home/briefs/${projectSummary.shortTitle}/${modalImage}`,
                                                openModal: true,
                                            })
                                        }}
                                    />
                                </Box>
                            ))}
                        </Box>
                    </Box>
                </CustomModal>
            )}
            {childModalDetails.openModal && (
                <ImageModal
                    open={childModalDetails.openModal}
                    handleClose={() => {
                        setChildModalDetails({ openModal: false })
                    }}
                    closeIconColor='9dffdf'
                    isBrief
                >
                    <img src={childModalDetails.imageSrc} alt='project-brief-childModal-images' height='100%' />
                </ImageModal>
            )}
        </>
    )
}

export default ProjectBriefs

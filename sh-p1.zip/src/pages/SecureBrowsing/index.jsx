import { useTheme } from '@mui/material'
import React, { memo } from 'react'
import { DiveFooter, DiveHeader, DiveIntro, DiveProcess, DiveSecret, DiveTest } from '../../components/dive'
import { SECURE } from '../../utils/dive.constants'

const secureCloudPositions = [1, 4, 5, 8]

const SecureBrowsing = () => {
    const theme = useTheme()

    return (
        <>
            {/*  Deep Dive Splash Landing Banner  */}
            <DiveHeader
                shrinkCenterImage
                title='Secure Browser Messaging'
                acronym={SECURE.ACRONYM}
                overlay='secure/secure-overlay.svg'
                centerImage='secure/secure-header.svg'
                goalModalImage='secure/secure-goal-modal.svg'
                painModalImage='secure/secure-pain-point-modal.svg'
                solutionModalImage='secure/secure-solution-modal.svg'
            />

            {/*  How We Got Started  */}
            <DiveIntro deepDiveDescription={SECURE.INTRO.TEXT} footerImage={SECURE.INTRO.IMAGE} />

            {/*  What We Set Out to Learn  */}
            <DiveTest listOfTheories={SECURE.TESTS} />

            {/*  Secret Sauce  */}
            <DiveSecret saucyDescription={SECURE.SECRET} />

            {/*  RPT Process  */}
            <DiveProcess stepDescriptions={SECURE.STEPS} />

            {/*  Where Are We Now?  */}
            <DiveFooter deepDiveConclusion={SECURE.FOOTER.TEXT} footerImage={SECURE.FOOTER.IMAGE} />
        </>
    )
}

export default memo(SecureBrowsing)

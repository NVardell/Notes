import Box from '@mui/material/Box'
import React, { memo } from 'react'

const About = () => (
    <Box sx={{ minHeight: '100vh' }}>
        <h1>About</h1>
    </Box>
)

export default memo(About)

import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'

import * as RouteConstants from '../../routes/routeConstants'
import { EVENT_TYPES } from '../constants'
import { addEvent, extractPageActionDetails, isPageAction } from '../util'
import { useOktaAuth } from '@okta/okta-react'

const availableRoutes = Object.values(RouteConstants)

export const AnalyticsManager = ({ profileId }) => {
    const location = useLocation()
    const { authState } = useOktaAuth()
    const [prevPathname, setPrevPathname] = useState('')
    const [prevHref, setPrevHref] = useState('')

    useEffect(() => {
        const pathname = window.location.pathname
        const href = window.location.href

        // Do not fire event if path is NOT in available routes
        if (!availableRoutes.includes(pathname)) return
        if (!authState && !pathname.includes('login')) return

        addEvent(EVENT_TYPES.PAGE_LOAD, {
            pathname,
            href,
            referringPath: prevPathname,
            referringHref: prevHref,
        })

        setPrevPathname(pathname)
        setPrevHref(href)
    }, [location.pathname])

    useEffect(() => {
        document.body.addEventListener('click', handleElementClicked)

        return () => {
            document.body.removeEventListener('click', handleElementClicked)
        }
    }, [])

    const handleElementClicked = event => {
        if (isPageAction(event.target)) {
            addEvent(EVENT_TYPES.PAGE_ACTION, extractPageActionDetails(event))
        }
    }

    return <div className='showcase-analytics-manager' />
}

export default AnalyticsManager

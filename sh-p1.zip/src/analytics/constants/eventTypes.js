export const EVENT_TYPES = {
    PAGE_LOAD: 'pageLoad',
    PAGE_ACTION: 'pageAction',
    LOGIN_SUCCESS: 'loginSuccess',
}

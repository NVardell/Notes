export const BASE_ID = 'RPT:'

export const PAGE_SECTIONS = {
    HOME: 'Home',
    DIVE: 'DeepDive',
    LOGIN: 'Login',
}

export const PAGE_TYPES = {
    DASHBOARD: 'Dashboard',
    DATA: 'Data',
    FORM: 'Form',
}

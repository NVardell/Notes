import * as RouteConstants from '../../../routes/routeConstants'
import { BASE_ID, PAGE_SECTIONS, PAGE_TYPES } from './pageConstants'

export const LOGIN_PAGES = {
    [RouteConstants.LOGIN_CALLBACK]: {
        section: PAGE_SECTIONS.LOGIN,
        type: PAGE_TYPES.DASHBOARD,
        name: `${BASE_ID}Login`,
    },
}

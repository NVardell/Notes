import * as RouteConstants from '../../../routes/routeConstants'
import { BASE_ID, PAGE_SECTIONS, PAGE_TYPES } from './pageConstants'

export const DIVE_PAGES = {
    [RouteConstants.DIVE_NEURODIVERSITY_PATH]: {
        section: PAGE_SECTIONS.DIVE,
        type: PAGE_TYPES.DASHBOARD,
        name: `${BASE_ID}SupportingNeurodiversity`,
    },
    [RouteConstants.DIVE_PREFERRED_ALTERNATIVES_PATH]: {
        section: PAGE_SECTIONS.DIVE,
        type: PAGE_TYPES.DASHBOARD,
        name: `${BASE_ID}PersonalizedPreferredAlternatives`,
    },
    [RouteConstants.DIVE_SECURE_MESSAGING_PATH]: {
        section: PAGE_SECTIONS.DIVE,
        type: PAGE_TYPES.DASHBOARD,
        name: `${BASE_ID}SecureBrowserMessaging`,
    },
}

import { BASE_ID, PAGE_SECTIONS, PAGE_TYPES } from './pageConstants'

import { HOME_PAGES } from './homePages'
import { DIVE_PAGES } from './divePages'
import { LOGIN_PAGES } from './loginPages'

const PAGE_INFO = {
    ...HOME_PAGES,
    ...DIVE_PAGES,
    ...LOGIN_PAGES,
}

export { PAGE_SECTIONS, PAGE_TYPES, BASE_ID, PAGE_INFO }

import * as RouteConstants from '../../../routes/routeConstants'
import { BASE_ID, PAGE_SECTIONS, PAGE_TYPES } from './pageConstants'

export const HOME_PAGES = {
    [RouteConstants.HOME_PATH]: {
        section: PAGE_SECTIONS.HOME,
        type: PAGE_TYPES.DASHBOARD,
        name: `${BASE_ID}HomePage`,
    },
}

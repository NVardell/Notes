import { EVENT_TYPES, PAGE_INFO } from '../constants'

/**
 * Generic Add Event
 *
 * @description Build/Post Analytics Event
 * @param eventType EVENT_TYPES
 * @param event DOM/Window Event
 */
export const addEvent = (eventType, event) => {
    const newEvent = buildEvent(eventType, event)
    console.log(JSON.stringify(newEvent, null, 4))
    if (newEvent) window.adobeDataLayer.push(newEvent)
}

/**
 * Build Analytics Event
 *
 * @description Build data object for analytics
 * @param eventType
 * @param eventDetails
 * @returns {{actionData: {actionRegion: string, actionName: string}, event: string}|{event}|{pageData: {site: string, pageType, previousPageName, destinationURL: string, pageAuthenticationType: (string), pageName, platform: string, pageSection: *, referringURL: string}, event: string}}
 */
const buildEvent = (eventType, eventDetails) => {
    switch (eventType) {
        case EVENT_TYPES.PAGE_LOAD:
            return buildPageLoadEvent(eventDetails)
        case EVENT_TYPES.PAGE_ACTION:
            return buildPageAction(eventDetails)
        default:
            return buildBasicEvent(eventDetails)
    }
}

const buildBasicEvent = eventDetails => ({
    event: eventDetails,
})

let login = false
const buildPageLoadEvent = eventDetails => {
    const { pathname = '', href = '', referringPath = '', referringHref = '' } = eventDetails
    const pageAuthenticationType = pathname.includes('login/') ? 'Unauthenticated' : 'Authenticated'
    const currentPageInfo = PAGE_INFO[pathname] || {}
    const previousPageInfo = PAGE_INFO[referringPath] || {}

    if (login && pathname.includes('login')) return
    if (pathname.includes('login')) login = true

    return {
        event: EVENT_TYPES.PAGE_LOAD,
        pageData: {
            pageName: currentPageInfo.name,         // Name of current page
            pageSection: currentPageInfo.section,   // Typically parent page
            pageType: currentPageInfo.type,         // Content type (form/cart/dashboard/etc.)
            site: 'RPT',                            // Shorthand Project Name
            platform: 'React',                      // Presentation (iOS/Android/etc.)
            referringURL: referringHref,            // Prior page url (if any)
            previousPageName: previousPageInfo.name,// Prior page name (if any)
            destinationURL: href,                   // Current page url
            pageAuthenticationType,                 // Login status
        },
    }
}

const buildPageAction = eventDetails => {
    const { actionName = '', actionRegion = '' } = eventDetails

    return {
        event: EVENT_TYPES.PAGE_ACTION,
        actionData: {
            actionName,
            actionRegion,
        },
    }
}

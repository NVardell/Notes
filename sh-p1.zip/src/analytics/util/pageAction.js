const PAGE_ACTION_ROLES = ['button', 'tab', 'link', 'menuitem', 'switch', 'complementary']

export const isPageAction = eventSource => PAGE_ACTION_ROLES.includes(eventSource.getAttribute('role'))

export const extractPageActionDetails = event => {
    const pathname = window.location.pathname
    const actionText = event.target.innerText || event.target.textContent || event.target.title || event.target.alt
    const actionHeader = extractActionHeader(event)

    const actionName = actionHeader !== '' ? `${actionHeader}:${actionText}` : actionText

    let actionRegion = 'MAIN'
    if (document.body.getElementsByClassName('header-container')[0].contains(event.target)) actionRegion = 'HEADER'
    else if (document.body.getElementsByClassName('footer-container')[0].contains(event.target)) actionRegion = 'FOOTER'

    return {
        actionName,
        actionRegion,
    }
}

const SERVICE_CONTAINER = document.body.getElementsByClassName('service-container')
const PORTFOLIO_CONTAINER = document.body.getElementsByClassName('portfolio-container')
const SUMMARY_CONTAINER = document.body.getElementsByClassName('project-summary-container')
const TEAM_CONTAINER = document.body.getElementsByClassName('team-container')

const extractActionHeader = event => {
    let actionHeader = ''
    const elementRole = event.target.getAttribute('role')

    // Handle button event
    if (elementRole === 'button') {
        if (TEAM_CONTAINER[0].contains(event.target)) actionHeader = 'TEAM'
        else if (SERVICE_CONTAINER[0].contains(event.target)) actionHeader = 'SERVICE'
        else if (PORTFOLIO_CONTAINER[0].contains(event.target) || SUMMARY_CONTAINER[0].contains(event.target)) actionHeader = 'PORTFOLIO'
    }

    // Handle complementary info event (Deep Dive Pills)
    if (elementRole === 'complementary') actionHeader = 'DIVE'

    return actionHeader
}

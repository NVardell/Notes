const LAUNCH_DEV_URL = 'https://assets.adobedtm.com/75c13ef9d9d6/f0a32dfed573/launch-f8d0968b2e4e-development.min.js'
const LAUNCH_QA_URL = 'https://assets.adobedtm.com/75c13ef9d9d6/f0a32dfed573/launch-23466747d1c5-staging.min.js'
const LAUNCH_PROD_URL = 'https://assets.adobedtm.com/75c13ef9d9d6/f0a32dfed573/launch-8be0e798202b.min.js'

const getLaunchUrl = () => {
    const hostname = window.location.hostname
    if (hostname.includes('-dev') || hostname.includes('localhost')) return LAUNCH_DEV_URL
    if (hostname.includes('-qa')) return LAUNCH_QA_URL
    return LAUNCH_PROD_URL
}

const isLaunchScriptLoaded = () => {
    const launchUrl = getLaunchUrl()
    const allScripts = Array.from(document.getElementsByTagName('script'))

    return allScripts.some(script => script.src === launchUrl)
}

const analyticsLoader = () => {
    window.adobeDataLayer = window.adobeDataLayer || []

    if (!isLaunchScriptLoaded()) {
        const launchScript = document.createElement('script')
        launchScript.setAttribute('src', getLaunchUrl())
        launchScript.setAttribute('async', '')

        document.head.appendChild(launchScript)
    }
}

export default analyticsLoader

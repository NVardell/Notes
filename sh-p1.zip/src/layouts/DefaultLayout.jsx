import Box from '@mui/material/Box'
import styled from '@emotion/styled'
import { Outlet, useLocation } from 'react-router-dom'

import Header from '../components/Header.jsx'
import Footer from '../components/Footer.jsx'
import { useMemo } from 'react'

const LayoutWrapper = styled.div`
    background: #000;
    color: #fff;
    min-height: 100vh;
    box-sizing: border-box;
`

const DefaultLayout = () => {
    const location = useLocation()
    const isLoginCallbackRoute = useMemo(() => location.pathname === '/login/callback', [location.pathname])

    return (
        <LayoutWrapper>
            <Header />
            <Box
                sx={
                    isLoginCallbackRoute
                        ? { height: '90vh', paddingTop: '10rem', textAlign: 'center' }
                        : { paddingTop: '5rem' }
                }
            >
                <Outlet />
            </Box>
            <Footer />
        </LayoutWrapper>
    )
}

export default DefaultLayout

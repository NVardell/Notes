function renderSwitch(host) {
    switch (host) {
        // Dev
        case 'showcase-dev.apps-3.hs-3-nonprod.openshift.evernorthcloud.com':
            return JSON.parse(process.env.REACT_APP_DEV_OKTA)
        // QA
        case 'showcase-qa.apps.hs-3-nonprod.openshift.evernorthcloud.com':
            return JSON.parse(process.env.REACT_APP_QA_OKTA)
        // localhost
        case 'localhost':
            return JSON.parse(process.env.REACT_APP_LOCAL_OKTA)
        default:
            return {}
    }
}
export const oktaConfig = renderSwitch(window.location.hostname)

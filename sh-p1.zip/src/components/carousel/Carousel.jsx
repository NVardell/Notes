import React, { useEffect, useRef, useState } from 'react'
import { ChevronLeft, ChevronRight } from '@mui/icons-material'
import './carousel.css'

const Carousel = ({ isOpen, autoplay, interval, slides, height, arrows }) => {
    const [slideTotal, setSlideTotal] = useState(0)
    const [slideCurrent, setSlideCurrent] = useState(-1)
    const [slidesSet, setSlidesSet] = useState([])
    const [carouselHeight, setCarouselHeight] = useState('')
    const intervalRef = useRef(null)
    const nextRef = useRef()
    const [pauseCarousel, setPauseCarousel] = useState(false)

    useEffect(() => {
        if (isOpen) setPauseCarousel(true)
        if (height) setCarouselHeight(height)

        if (!isOpen && !pauseCarousel) {
            const locSlides = []
            slides.forEach(slide => {
                const slideObj = {
                    class: 'slider-single pro-activated',
                    element: slide,
                }
                locSlides.push(slideObj)
            })
            if (slides.length === 2) {
                slides.forEach(slide => {
                    const slideObj = {
                        class: 'slider-single pro-activated',
                        element: slide,
                    }
                    locSlides.push(slideObj)
                })
            }
            setSlidesSet(locSlides)
            setSlideTotal(locSlides.length - 1)
            setPauseCarousel(false)
            setTimeout(() => {
                nextRef.current?.click()
                if (autoplay) {
                    intervalRef.current = setTimeout(() => {
                        nextRef.current?.click()
                    }, interval)
                }
            }, 500)
        }
    }, [slides, isOpen, autoplay, height, interval, pauseCarousel])

    useEffect(() => {
        if (slideCurrent === -1) {
            setTimeout(() => {}, 500)
        }
    }, [slidesSet, slideCurrent])

    const activeClass = 'slider-single active'
    const preActiveClass = 'slider-single pre-active'
    const proActiveClass = 'slider-single pro-active'
    const updateSlides = (slide, current, active, preActive, proActive) => {
        slide.forEach(slid => {
            if (slid.class.includes('pre-activated')) slid.class = 'slider-single pro-activated'
            else if (slid.class.includes('pro-activated')) slid.class = 'slider-single pre-activated'
            else if (slid.class.includes('pre-active')) slid.class = 'slider-single pre-activated'
            else if (slid.class.includes('pro-active')) slid.class = 'slider-single pro-activated'
        })

        preActive.class = preActiveClass
        active.class = activeClass
        proActive.class = proActiveClass
        setSlidesSet(slide)
        setSlideCurrent(current)

        if (autoplay) {
            clearTimeout(intervalRef.current)
            intervalRef.current = setTimeout(() => {
                nextRef.current && nextRef.current?.click()
            }, interval)
        }
    }

    const slide = [...slidesSet]

    const slideRight = () => {
        if (slideTotal) {
            const current = slideCurrent < slideTotal ? slideCurrent + 1 : 0
            const preActiveSlide = current ? slide[current - 1] : slide[slideTotal]
            const proActiveSlide = current < slideTotal ? slide[current + 1] : slide[0]
            updateSlides(slide, current, slide[current], preActiveSlide, proActiveSlide)
        }
    }
    const slideLeft = () => {
        if (slideTotal) {
            const current = slideCurrent ? slideCurrent - 1 : slideTotal
            const preActiveSlide = current ? slide[current - 1] : slide[slideTotal]
            const proActiveSlide = current < slideTotal ? slide[current + 1] : slide[0]
            updateSlides(slide, current, slide[current], preActiveSlide, proActiveSlide)
        }
    }

    const sliderClass = direction => (!arrows ? 'slider-disabled' : `slider-${direction}`)

    return (
        <div className='carousel' style={{ height: carouselHeight ? `${carouselHeight}px` : '275px' }}>
            {slidesSet && slidesSet.length > 0 && (
                <div className='carousel-container'>
                    <div className='carousel-content'>
                        {slidesSet.map((slider, index) => (
                            <div className={slider.class} key={index}>
                                <div className={sliderClass('left')} onClick={slideLeft}>
                                    <div>
                                        <ChevronLeft />
                                    </div>
                                </div>
                                <div className={sliderClass('right')} onClick={slideRight} ref={nextRef}>
                                    <div>
                                        <ChevronRight />
                                    </div>
                                </div>
                                <div className='slider-single-content'>{slider.element}</div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    )
}
Carousel.defaultProps = {
    arrows: true,
    autoplay: false,
    interval: 3000,
    isOpen: false,
    height: 0,
    slides: [],
}
export default Carousel

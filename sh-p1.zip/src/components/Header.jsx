import { Box, Link } from '@mui/material'
import { useOktaAuth } from '@okta/okta-react'
import { Link as RouteLink, useNavigate } from 'react-router-dom'

import { MAIN_NAV, MAIN_NAV_UL, MAIN_NAV_UL_LINKS, NAV_LINKS, RPT_TITLE } from '../styles/Header.style.js'
import { NAV_LINK_TEXT, RPT_TITLE_TEXT } from '../utils/constants'
import { scrollToTop } from '../utils/utils'

const host = window.location.origin

const Header = () => {
    const navigate = useNavigate()
    const { authState } = useOktaAuth()

    return (
        <Box
            component='nav'
            className='header-container'
            sx={{
                ...MAIN_NAV,
                ...(!authState?.isAuthenticated && {
                    justifyContent: 'center',
                }),
            }}
        >
            <Box component='span' sx={MAIN_NAV_UL}>
                <RouteLink to='/' style={{ ...RPT_TITLE, ...NAV_LINKS, ...MAIN_NAV_UL_LINKS }} onClick={scrollToTop}>
                    {RPT_TITLE_TEXT}
                </RouteLink>
            </Box>
            {authState?.isAuthenticated && (
                <Box component='ul' sx={MAIN_NAV_UL}>
                    <li>
                        <Link
                            role='link'
                            className='cursor-pointer'
                            style={{ ...NAV_LINKS, ...MAIN_NAV_UL_LINKS }}
                            onClick={() => navigate('/', { state: { target: 'our-portfolio' } })}
                        >
                            {NAV_LINK_TEXT.PORTFOLIO}
                        </Link>
                    </li>
                    <li>
                        <Link
                            role='link'
                            className='cursor-pointer'
                            style={{ ...NAV_LINKS, ...MAIN_NAV_UL_LINKS }}
                            onClick={() => navigate('/', { state: { target: 'contact-us' } })}
                        >
                            {NAV_LINK_TEXT.CONTACT}
                        </Link>
                    </li>
                    <li>
                        <img alt='user_icon' src={`${host}/images/nav/icon.svg`} role='link' />
                    </li>
                </Box>
            )}
        </Box>
    )
}

export default Header

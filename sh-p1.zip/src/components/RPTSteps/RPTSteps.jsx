import './steps.css'
import { Box, Grid, Typography, useTheme } from '@mui/material'
import { useEffect } from 'react'
import { APP } from '../../styles/App.style'

export default function RPTSteps(props) {
    const theme = useTheme()
    const { description, imageSrc, reverseDirection, title, uniqueKey } = props
    const isSecureBrowsingRoute = window.location.pathname === '/secure-browsing'
    const stepDescriptionClassNames = reverseDirection
        ? ` step-description-left step-${uniqueKey}`
        : ` step-description-right step-${uniqueKey}`

    const iconClassNames = reverseDirection
        ? `process-icon image-right icon-${uniqueKey}`
        : `process-icon image-left icon-${uniqueKey}`

    useEffect(() => {
        const target = document.getElementById(title)
        if (target) {
            document.addEventListener('scroll', () => {
                if (window.scrollY + 200 >= target.getBoundingClientRect().top + 1000) {
                    setTimeout(() => {
                        target.classList.remove('hide-text')
                        target.classList.add('show-text')
                    }, 500)
                } else {
                    target.classList.remove('show-text')
                    target.classList.add('hide-text')
                }
            })
        }
        return document.removeEventListener('scroll', () => {})
    }, [title])

    return (
        <Grid container className='process-step-container' flexDirection={reverseDirection && 'row-reverse'}>
            <Grid item sm={4} className='zig-zag'>
                <img src={imageSrc} className={iconClassNames} alt={title} />
            </Grid>
            <Box position='absolute' className={stepDescriptionClassNames}>
                <Typography sx={{ ...APP.SECTION.TITLE, textAlign: 'inherit', marginBottom: '.75rem' }}>
                    {title}
                </Typography>
                <Typography
                    id={title}
                    component={isSecureBrowsingRoute ? 'span' : 'p'}
                    variant={isSecureBrowsingRoute ? 'span' : 'p'}
                    className='hide-text'
                    sx={{ ...APP.SECTION.TEXT, textAlign: 'inherit', color: 'white' }}
                >
                    {description}
                </Typography>
            </Box>
        </Grid>
    )
}

import { Link } from 'react-router-dom'
import {
    FOOTER_NAV,
    FOOTER_NAV_LINKS,
    FOOTER_NAV_UL,
    FOOTER_NAV_UL_LINKS,
    FOOTER_RPT_TITLE,
} from '../styles/Footer.style.js'
import { Box } from '@mui/material'
import { NAV_LINK_TEXT, RPT_TITLE_TEXT } from '../utils/constants.js'

const Footer = () => (
    <Box component='nav' sx={FOOTER_NAV} className='footer-container'>
        <Box component='span' sx={FOOTER_RPT_TITLE}>
            <Link to='/' style={FOOTER_NAV_LINKS}>
                {RPT_TITLE_TEXT}
            </Link>
        </Box>
        <Box component='ul' sx={FOOTER_NAV_UL}>
            <li>
                <Link role='link' style={{ ...FOOTER_NAV_LINKS, ...FOOTER_NAV_UL_LINKS }} to='#'>
                    {NAV_LINK_TEXT.TERMS_OF_USE}
                </Link>
            </li>
            <li>
                <Link role='link' style={{ ...FOOTER_NAV_LINKS, ...FOOTER_NAV_UL_LINKS }} to='#'>
                    {NAV_LINK_TEXT.PRIVACY_POLICY}
                </Link>
            </li>
            <li>
                <Link role='link' style={{ ...FOOTER_NAV_LINKS, ...FOOTER_NAV_UL_LINKS }} to='#'>
                    {NAV_LINK_TEXT.ABOUT}
                </Link>
            </li>
        </Box>
    </Box>
)

export default Footer

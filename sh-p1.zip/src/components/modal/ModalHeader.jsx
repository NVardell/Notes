import Box from '@mui/material/Box'
import Stack from '@mui/material/Stack'
import Typography from '@mui/material/Typography'
import React from 'react'

function ModalHeader(props) {
    const { title = '' } = props

    return (
        <Stack
            alignItems='center'
            direction='row'
            justifyContent='center'
            sx={{
                position: 'relative',
            }}
        >
            <Box>
                <Typography
                    component='div'
                    whiteSpace='nowrap'
                    sx={{
                        color: '#fff',
                        textTransform: 'uppercase',
                        fontSize: '32px',
                    }}
                >
                    {title}
                </Typography>
            </Box>
            {}
        </Stack>
    )
}

export default ModalHeader

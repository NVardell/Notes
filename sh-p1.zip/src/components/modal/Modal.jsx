import Modal from '@mui/material/Modal'

export default function ModalContainer({ children, open, handleClose }) {
    return (
        <Modal
            open={open}
            onClose={handleClose}
            aria-labelledby='modal-modal-title'
            aria-describedby='modal-modal-description'
            sx={{
                backgroundColor: 'rgba(0, 0, 0, 0.75)',
            }}
        >
            {children}
        </Modal>
    )
}

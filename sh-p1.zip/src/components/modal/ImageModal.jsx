import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined'
import Grid from '@mui/material/Grid'
import Modal from '@mui/material/Modal'
import { useMediaQuery, useTheme } from '@mui/material'
import React, { useEffect } from 'react'

export default function ImageModal(props) {
    const {
        children,
        open,
        handleClose,
        isBrief,
        closeIconColor = '3EFFC0',
        imageHeight = '50%',
        isCircleImage = false,
        imageCenter = false,
    } = props
    const theme = useTheme()
    const isMobile = useMediaQuery(theme.breakpoints.down('md'))

    useEffect(() => {
        document.body.classList.add('rpt-modal-open')
        return () => {
            document.body.classList.remove('rpt-modal-open')
        }
    }, [])

    return (
        <Modal
            open={open}
            onClose={() => {}}
            aria-labelledby='modal-modal-title'
            aria-describedby='modal-modal-description'
            sx={{
                position: 'fixed !important',
                display: 'block',
                '&>.MuiBackdrop-root': {
                    backgroundColor: 'rgba(0, 0, 0, 0.75)',
                },
            }}
            disableAutoFocus
            disableScrollLock
        >
            <Grid
                id='modal-content'
                sx={{
                    position: 'absolute',
                    float: 'left',
                    left: '50%',
                    top: imageCenter ? '50%' : '40%',
                    height: imageHeight,
                    transform: 'translate(-50%, -50%)',
                    '&:focus-visible': { outline: '0px' },
                    marginTop: isBrief ? '5%' : 0,
                }}
            >
                {children}
                <CloseOutlinedIcon
                    onClick={handleClose}
                    sx={{
                        color: `#${closeIconColor}`,
                        cursor: 'pointer',
                        position: 'absolute',
                        fontSize: theme.spacing(isMobile ? 2 : 6.5),
                        ...(isCircleImage && {
                            marginLeft: '-3rem',
                            marginTop: '3rem',
                        }),
                        ...(isBrief && {
                            marginTop: '-0.65rem',
                        }),
                    }}
                />
            </Grid>
        </Modal>
    )
}

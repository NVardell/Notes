import Dialog from '@mui/material/Dialog'
import DialogContent from '@mui/material/DialogContent'
import DialogTitle from '@mui/material/DialogTitle'
import { styled } from '@mui/material/styles'
import useMediaQuery from '@mui/material/useMediaQuery'
import React, { useEffect } from 'react'
import { useTheme } from '@mui/material'
import ModalHeader from './ModalHeader'
import Box from '@mui/material/Box'
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined'
import IconButton from '@mui/material/IconButton'

const CustomDialog = styled(Dialog)(({ isMobile }) => ({
    '& .MuiDialog-container': {
        '& .MuiPaper-root': {
            borderRadius: isMobile ? 0 : '100px',
            maxWidth: '100%',
            width: '1300px',
            overflow: 'inherit',
        },
    },
    '& .MuiDialogContent-root': {
        padding: 0,
        backgroundColor: '#000',
        borderRadius: isMobile ? 0 : '0 0 45px 45px',
        borderBottom: '10px solid #1D8160',
        borderLeft: '10px solid #1D8160',
        borderRight: '10px solid #1D8160',
    },
    '& .MuiDialogContent-root::-webkit-scrollbar': {
        maxHeight: 'calc(100% - 50px)',
        width: '8px',
    },
    '& .MuiDialogContent-root::-webkit-scrollbar-thumb': {
        borderRadius: '100px',
    },
    '.MuiDialogContent-root::-webkit-scrollbar-track-piece:end': {
        marginBottom: '40px',
    },
    '& .MuiDialogActions-root': {
        padding: 0,
    },
    '& .MuiDialogTitle-root': {
        borderRadius: isMobile ? '0px' : '45px 45px 0 0 ',
        padding: '20px 32px',
        backgroundColor: '#0c3326',
        outline: 0,
        borderTop: '10px solid  #1D8160',
        borderLeft: '10px solid  #1D8160',
        borderRight: '10px solid  #1D8160',
    },
}))

function CustomModal(props) {
    const { children, handleClose, open, showCloseIcon = false, showHeader = true, title = '' } = props

    const theme = useTheme()
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'))

    useEffect(() => {
        document.body.classList.add('rpt-modal-open')
        return () => {
            document.body.classList.remove('rpt-modal-open')
        }
    }, [])

    return (
        <CustomDialog
            disableEnforceFocus
            className='rpt-custom-dialog'
            fullScreen={!!isMobile}
            ismobile={+isMobile}
            open={open}
            sx={{ zIndex: isMobile ? 1306 : 1300 }}
            transitionDuration={{
                enter: theme.transitions.duration.enteringScreen,
                exit: 0,
            }}
            onClose={() => {}}
        >
            {showHeader && (
                <DialogTitle id='scroll-dialog-title'>
                    <ModalHeader handleClose={handleClose} showCloseIcon={showCloseIcon} title={title} />
                </DialogTitle>
            )}
            <DialogContent>{children}</DialogContent>
            {showCloseIcon && (
                <Box sx={{ position: 'absolute', right: '-4rem', top: '-1rem' }}>
                    <IconButton onClick={handleClose} sx={{ color: '#FFF' }}>
                        <CloseOutlinedIcon sx={{ fontSize: '3.5rem' }} />
                    </IconButton>
                </Box>
            )}
        </CustomDialog>
    )
}

export default CustomModal

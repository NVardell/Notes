import React from 'react'
import { Box, Container, Grid, Typography } from '@mui/material'
import { INTRO } from '../Dive.style'

const DiveIntro = ({ sectionTitle = 'How We Got Started', deepDiveDescription, footerImage }) => (
    <Container component='section' className='dive-intro'>
        <Grid container spacing={2} sx={INTRO}>
            <Grid item sm={12}>
                <Typography sx={INTRO.TITLE}>{sectionTitle}</Typography>
            </Grid>
            {deepDiveDescription.map((words, i) => (
                <Grid item key={i}>
                    <Typography sx={INTRO.TEXT}>{words}</Typography>
                </Grid>
            ))}
            {footerImage && (
                <Grid item sm={12}>
                    <Box component='img' src={footerImage} className='img-fluid' alt='footer image' />
                </Grid>
            )}
        </Grid>
    </Container>
)

export default DiveIntro

import React from 'react'
import { Grid, Typography } from '@mui/material'
import { FOOTER } from '../Dive.style'
import './diveFooter.style.css'

const DiveFooter = ({ sectionTitle = 'Where Are They Now?', deepDiveConclusion, footerImage }) => (
    <Grid container spacing={2} sx={FOOTER} className='dive-footer-container'>
        <Grid item sm={1} />
        <Grid item sm={5} sx={{ px: '2rem' }}>
            <Typography sx={FOOTER.TITLE}>{sectionTitle}</Typography>
            <Typography sx={FOOTER.TEXT}>{deepDiveConclusion}</Typography>
        </Grid>
        <Grid item sm={6} sx={{ ...FOOTER.IMAGE, backgroundImage: `url(/images/${footerImage}), ${FOOTER.ELLIPSE}` }} />
    </Grid>
)

export default DiveFooter

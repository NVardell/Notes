export { default } from './DiveFooter'

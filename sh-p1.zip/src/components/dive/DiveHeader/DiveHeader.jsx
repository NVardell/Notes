import React, { useEffect, useState } from 'react'
import { scrollToTop } from '../../../utils/utils'

import './DiveHeader.css'
import { Box, Container } from '@mui/material'
import { HEADER } from '../Dive.style'
import PropTypes from 'prop-types'
import ImageModal from '../../modal/ImageModal'
import { PILL } from '../../../utils/image.constants'

const DiveHeader = ({
    title,
    acronym,
    overlay,
    centerImage,
    goalModalImage,
    painModalImage,
    solutionModalImage,
    background = '/images/common/ellipse-header.svg',
    shrinkTitle,
    shrinkCenterImage,
}) => {
    useEffect(() => {
        scrollToTop()
    }, [])

    const [openModal, setOpenModal] = useState(false)
    const [imageDetails, setImageDetails] = useState({
        imageSrc: '',
    })

    const handleClick = modalImage => {
        setOpenModal(true)
        setImageDetails({ imageSrc: `/images/${modalImage}` })
    }

    return (
        <Box
            component='section'
            className='dive-header-container'
            sx={{
                ...HEADER.CONTAINER,
                backgroundImage: `url(/images/${overlay}), url(${background})`,
                ...(shrinkCenterImage ? HEADER.BACKGROUND.SHRINK : HEADER.BACKGROUND),
            }}
        >
            <Container>
                {/*     TITLE    */}
                <Box
                    className='dive-header-title'
                    sx={{
                        ...HEADER.TITLE,
                        ...(shrinkTitle && HEADER.TITLE.SHRINK),
                    }}
                >
                    {title}
                </Box>

                <Box display='flex' justifyContent='space-between' position='relative' sx={{ marginBottom: '10rem' }}>
                    {/*     PAIN PILL    */}
                    <Box className='dive-pain-point'>
                        <img
                            src={PILL.PAIN}
                            title={`${acronym.toUpperCase()}:PAIN PILL`}
                            role='complementary'
                            alt='pain point pill'
                            className='img-fluid cursor-pointer zoomImage'
                            onClick={() => handleClick(painModalImage)}
                        />
                    </Box>

                    {/*    SOLUTION    */}
                    <Box className='dive-solution'>
                        {/*    SOLUTION  - CENTER IMAGE    */}
                        <img
                            src={`/images/${centerImage}`}
                            className='img-fluid'
                            alt='dive splash icon'
                            style={{ ...(shrinkCenterImage && HEADER.BACKGROUND.SHRINK.DIVE_IMAGE) }}
                        />

                        {/*    SOLUTION  - PILL    */}
                        <Box className='dive-solution-point'>
                            <img
                                src={PILL.SOLUTION}
                                title={`${acronym.toUpperCase()}:SOLUTION PILL`}
                                role='complementary'
                                alt='dive solution pill'
                                className='img-fluid cursor-pointer zoomImage'
                                onClick={() => handleClick(solutionModalImage)}
                            />
                        </Box>
                    </Box>

                    {/*     GOAL PILL   */}
                    <Box className='dive-goal-point'>
                        <img
                            src={PILL.GOAL}
                            title={`${acronym.toUpperCase()}:GOAL PILL`}
                            role='complementary'
                            alt='dive goal pill'
                            className='img-fluid cursor-pointer zoomImage'
                            onClick={() => handleClick(goalModalImage)}
                        />
                    </Box>
                </Box>
            </Container>
            {openModal && (
                <ImageModal imageCenter open={openModal} handleClose={() => setOpenModal(false)}>
                    <img src={imageDetails.imageSrc} alt='dive-pill-info-modal' />
                </ImageModal>
            )}
        </Box>
    )
}

DiveHeader.defaultProps = {
    title: '',
    overlay: '',
    centerImage: '',
    goalModalImage: '',
    painModalImage: '',
    solutionModalImage: '',
    background: '/images/common/ellipse-header.svg',
    shrinkTitle: false,
    shrinkCenterImage: false,
}
DiveHeader.propTypes = {
    title: PropTypes.string /** Dive Page Header Title */,
    overlay: PropTypes.string /** Image Path ~ Fullscreen splash overlay */,
    centerImage: PropTypes.string /** Image Path ~ Dive Centerpiece image */,
    goalModalImage: PropTypes.string /** Image Path ~ Dive 'Goal' info card */,
    painModalImage: PropTypes.string /** Image Path ~ Dive 'Pain' info card */,
    solutionModalImage: PropTypes.string /** Image Path ~ Dive 'Solution' info card */,
    background: PropTypes.string /** Image Path ~ Default green circle header background */,
    shrinkTitle: PropTypes.bool /** Reduces title margins (long dive title? true.) */,
    shrinkCenterImage: PropTypes.bool /** Reduces size of focal image (taller > wider ? true.) */,
}

export default DiveHeader

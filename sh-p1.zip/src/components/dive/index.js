import DiveHeader from './DiveHeader'
import DiveIntro from './DiveIntro'
import DiveTest from './DiveTest'
import DiveSecret from './DiveSecret'
import DiveProcess from './DiveProcess'
import DiveJourney from './DiveJourney'
import DiveFooter from './DiveFooter'

export { DiveHeader, DiveIntro, DiveTest, DiveSecret, DiveProcess, DiveJourney, DiveFooter }

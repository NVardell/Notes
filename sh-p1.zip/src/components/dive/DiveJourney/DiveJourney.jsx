import { Box, Typography } from '@mui/material'
import { JOURNEY } from '../Dive.style'
import { BG } from '../../../utils/image.constants'
import React from 'react'

const DiveJourney = ({
    sectionTitle = 'Dive Progress, Insights, & Iterations',
    sectionImage,
    upperBoarder = BG.HIGH_TIDE,
    lowerBoarder = BG.LOW_TIDE,
}) => (
    <Box sx={JOURNEY.CONTAINER}>
        <img src={upperBoarder} alt='upper boarder' width='100%' />
        <Box sx={JOURNEY.CONTENT}>
            <Typography sx={JOURNEY.TITLE}>{sectionTitle}</Typography>
            <img src={sectionImage} alt='Dive Journey Section Iterations' className='img-fluid' width='76%' />
        </Box>
        <img src={lowerBoarder} alt='lower boarder' width='100%' />
    </Box>
)

export default DiveJourney

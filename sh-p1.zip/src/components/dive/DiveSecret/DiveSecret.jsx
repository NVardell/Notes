import { Box, Grid, Typography } from '@mui/material'
import { SECRET } from '../Dive.style'

const DiveSecret = ({ sectionTitle = 'Our Secret Sauce', saucyDescription }) => (
    <Grid container spacing={2} sx={SECRET}>
        <Grid item sm={5} sx={SECRET.SAUCE}>
            <img src='/images/common/secret-sauce.svg' alt='sauce-bottle' className='bottle bottle-waddle' />
        </Grid>
        <Grid item sm={4}>
            <Typography sx={SECRET.TITLE}>{sectionTitle}</Typography>
            <Box sx={SECRET.STARS}>
                <img src='/images/common/stars.svg' alt='five star' />
            </Box>
            <Typography sx={SECRET.TEXT}>{saucyDescription}</Typography>
        </Grid>
        <Grid item sm={3} />
    </Grid>
)

export default DiveSecret

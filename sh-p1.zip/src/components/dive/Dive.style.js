import { APP } from '../../styles/App.style'

const HEADER = {
    TITLE: {
        ...APP.TITLE,
        paddingTop: '12rem',
        SHRINK: {
            marginBottom: '1rem',
        },
    },
    BACKGROUND: {
        backgroundPosition: 'top center',
        backgroundRepeat: 'no-repeat',
        backgroundSize: '100vw 95vh, contain',
        SHRINK: {
            backgroundPosition: '48% 45%, top center',
            backgroundRepeat: 'no-repeat',
            backgroundSize: '70vw 85vh, contain',
            DIVE_IMAGE: {
                marginTop: '-4rem',
            },
        },
    },
    CONTAINER: {
        ...APP.CONTAINER,
        marginTop: '-5rem !important',
        textAlign: 'center',
        height: '98vh',
    },
}

const INTRO = {
    ...APP.SECTION,
    TITLE: {
        ...APP.SECTION.TITLE,
        marginBottom: '2rem',
    },
    TEXT: {
        ...APP.SECTION.TEXT,
        width: '78vw',
        textAlign: 'left',
    },
}

const TEST = {
    CONTAINER: {
        marginTop: '-4rem',
        marginBottom: '-3rem',
    },
    TITLE: {
        ...APP.SECTION.TITLE,
        marginBottom: '5rem', // 80px = 5 rem
    },
}

const SECRET = {
    ...APP.SECTION,
    height: '90vh',
    marginTop: '-15rem',
    SAUCE: {
        backgroundImage: 'url(/images/common/ellipse-right-half.svg)',
        backgroundPosition: 'left center',
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'auto 100%',
        height: '85vh',
    },
    TITLE: {
        ...APP.SECTION.TITLE,
        marginBottom: '1.5rem',
        textAlign: 'center',
    },
    TEXT: {
        ...APP.SECTION.TEXT,
        textAlign: 'center',
    },
    STARS: {
        textAlign: 'center',
        marginBottom: '2.5rem',
    },
}

const JOURNEY = {
    CONTAINER: {
        textAlign: 'center',
    },
    CONTENT: {
        marginTop: '-7rem',
        marginBottom: '5rem',
    },
    TITLE: {
        ...APP.SECTION.TITLE,
        marginBottom: '4rem',
    },
}

const FOOTER = {
    ...APP.SECTION,
    flexDirection: 'row',
    height: '125vh',
    marginTop: '-15rem',
    marginBottom: '-1rem',
    ELLIPSE: `url(/images/common/ellipse-left-half.svg)`,
    TITLE: {
        ...APP.SECTION.TITLE,
        marginBottom: '2rem',
    },
    TEXT: {
        ...APP.SECTION.TEXT,
    },
    IMAGE: {
        // BACKGROUND ~ Footer Image, Green Ellipse
        backgroundPosition: 'center, right center',
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'auto, auto 90%',
        height: '125vh',
    },
}
export { HEADER, INTRO, TEST, SECRET, JOURNEY, FOOTER }

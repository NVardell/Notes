import { Container, Grid } from '@mui/material'
import RPTSteps from '../../RPTSteps/RPTSteps'
import { BG } from '../../../utils/image.constants'
import { PROCESS } from '../../../utils/dive.constants'

const DiveProcess = ({ stepDescriptions, hasIterations }) => (
    <>
        <Container component='section' className='dive-process-container' sx={{ my: '-6rem' }}>
            <Grid container justifyContent='center'>
                <Grid item xs={8}>
                    {PROCESS.STEPS.map(({ icon, title }, i) => (
                        <RPTSteps
                            key={title}
                            description={stepDescriptions[i]}
                            imageSrc={icon}
                            title={title}
                            reverseDirection={!!(i % 2)}
                            uniqueKey={i++}
                        />
                    ))}
                </Grid>
            </Grid>
        </Container>
        {!hasIterations && <img alt='process-footer' src={BG.LOW_TIDE} style={{ marginTop: '9rem', width: '100%' }} />}
    </>
)

export default DiveProcess

import { Container, Grid, Typography } from '@mui/material'
import { TEST } from '../Dive.style'
import { BG, CLOUD, COMMON } from '../../../utils/image.constants'
import ImageTransitionCard from '../../cards/ImageTransitionCard'
import React from 'react'
import './diveTest.style.css'

const DiveTest = ({
    sectionTitle = 'What We Set Out to Learn',
    listOfTheories,
    upperBoarder = BG.NO_TIDE,
    lowerBoarder = BG.HIGH_TIDE,
}) => (
    <>
        <img src={upperBoarder} alt='upper boarder' width='100%' />
        <Container section sx={TEST.CONTAINER}>
            <Typography sx={TEST.TITLE}>{sectionTitle}</Typography>
            <Grid container spacing={3}>
                {listOfTheories.map(({ theory, reason }, i) => (
                    <>
                        <Grid key={`theory-${i}`} item xs={6} position='relative'>
                            <img src={theory} alt={`theory-${i}`} width='100%' />
                        </Grid>
                        <Grid key={`reason-${i}`} item xs={6} position='relative'>
                            <img src={COMMON.ARROW_WHITE} className='arrow' alt='Arrow' />
                            <img src={reason} alt={`reason-${i}`} width='100%' />
                            <ImageTransitionCard
                                imgAlt='Cloud'
                                imgSrc={CLOUD[i]}
                                width='100%'
                                transitionClass='show-cloud'
                                initialClassName={
                                    i % 2 === 0
                                        ? `cloud-${i} hide-left-cloud`
                                        : `cloud-${listOfTheories.length > 2 && i === 1 ? '1-2' : i} hide-right-cloud`
                                }
                            />
                        </Grid>
                    </>
                ))}
            </Grid>
        </Container>
        <img src={lowerBoarder} alt='lower boarder' width='100%' />
    </>
)

export default DiveTest

import { useEffect, useRef } from 'react'

const ImageTransitionCard = props => {
    const imageRef = useRef(null)
    const { imgAlt, imgSrc, initialClassName, transitionClass } = props

    useEffect(() => {
        if (imageRef?.current) {
            const target = imageRef.current
            document.addEventListener('scroll', () => {
                if (window.scrollY + 200 >= target.getBoundingClientRect().top + 500) {
                    setTimeout(() => {
                        target.classList.add(transitionClass)
                    }, 50)
                } else {
                    target.classList.remove(transitionClass)
                }
            })
        }
        return () => {
            document.removeEventListener('scroll', () => {})
        }
    }, [transitionClass])

    return <img alt={imgAlt} className={`img-fluid ${initialClassName}`} ref={imageRef} src={imgSrc} />
}

export default ImageTransitionCard

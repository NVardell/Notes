import { Box, Typography } from '@mui/material'
import React from 'react'
import { CARD } from './Card.style'

const Card = props => {
    const { component, children, sx = {}, title } = props

    return (
        <Box component={component} sx={{ ...CARD.CONTAINER, ...sx }}>
            {title && <Typography sx={CARD.TITLE}>{title}</Typography>}
            {children}
        </Box>
    )
}

export default Card

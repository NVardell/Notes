import { Box, Paper, Typography } from '@mui/material'
import { useState } from 'react'

import { HOME } from '../../pages/Home/Home.style.js'
import { CARD, BG_IMAGE_STYLES } from './Card.style'

const ImageCard = props => {
    const { title, imageStyles, description, titleBelow } = props
    const [showDescription, setShowDescription] = useState(false)

    const toggleHover = () => {
        setShowDescription(prev => !prev)
    }
    return (
        <>
            {!titleBelow && <Typography sx={HOME.SUBTITLE} title={title}>{title}</Typography>}
            <Paper
                className='zoomImage'
                sx={{ ...BG_IMAGE_STYLES, ...imageStyles }}
                onMouseEnter={toggleHover}
                onMouseLeave={toggleHover}
            />
            {titleBelow && <Typography sx={HOME.SUBTITLE} title={title}>{title}</Typography>}
            <Box component='span' sx={{ minHeight: '130px', width: '100%', textAlign: 'center' }}>
                <Typography sx={CARD.CONTENT}>{showDescription && description}</Typography>
            </Box>
        </>
    )
}

export default ImageCard

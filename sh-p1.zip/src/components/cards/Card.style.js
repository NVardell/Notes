import { HOME } from '../../pages/Home/Home.style'
const CARD = {
    CONTAINER: {
        boxSizing: 'border-box',
        borderRadius: '2rem',
        backgroundColor: '#124D36',
        color: '#fff',
        padding: '1rem',
        fontSize: '1.25rem',
        fontWeight: 400,
        width: '100%',
        lineHeight: '150%',
    },
    TITLE: {
        ...HOME.SUBTITLE,
        marginBottom: '1rem',
    },
    CONTENT: {
        fontFamily: 'Roboto',
        fontSize: '1.375rem',
        fontWeight: 400,
        lineHeight: '2rem',
        letterSpacing: 0,
    },
}

const BG_IMAGE_STYLES = {
    backgroundColor: 'rgb(0 0 0)',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    backgroundSize: '15rem',
    height: '15rem',
    margin: '2rem',
    width: '100%',
}

export { CARD, BG_IMAGE_STYLES }

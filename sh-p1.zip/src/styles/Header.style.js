const MAIN_NAV = {
    backgroundColor: '#000',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    position: 'fixed',
    width: '100%',
    zIndex: 5,
    height: '7vh',
    minHeight: '40px',
}

const NAV_LINKS = {
    color: '#fff',
    display: 'flex',
    justifySelf: 'center',
    margin: '0.5rem 0',
    padding: '1rem',
    textDecoration: 'none',
    textTransform: 'uppercase',
}

const MAIN_NAV_UL = {
    alignItems: 'center',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-around',
    listStyleType: 'none',
    marginRight: '2rem',
    textTransform: 'capitalize',
}

const MAIN_NAV_UL_LINKS = {
    letterSpacing: '4px',
    margin: '0.5rem 0.5rem 0.5rem 0',
}

const RPT_TITLE = {
    fontStyle: 'italic',
    margin: '1rem',
    fontWeight: '600',
    fontSize: '2rem',
}

export { MAIN_NAV, MAIN_NAV_UL, MAIN_NAV_UL_LINKS, NAV_LINKS, RPT_TITLE }

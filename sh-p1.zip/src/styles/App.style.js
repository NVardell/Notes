const host = window.location.origin

const APP = {
    HOST: host,
    CONTAINER: {
        alignItems: 'center',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        margin: '3rem 0',
    },
    TITLE: {
        fontSize: '3.75rem',
        fontWeight: 900,
        letterSpacing: '3px',
        lineHeight: '5.5rem',
        marginBottom: '2.5rem',
        textTransform: 'uppercase',
        whiteSpace: 'pre-line',
    },
    SUBTITLE: {
        fontSize: '2rem',
        fontWeight: 500,
        letterSpacing: 0,
        lineHeight: '2.75rem',
    },
    SECTION: {
        my: '5rem',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        TITLE: {
            fontFamily: 'Roboto',
            fontWeight: 700,
            fontSize: '4.25vh', // 32px - 2rem
            textAlign: 'center',
            fontStyle: 'normal',
            lineHeight: '5.5vh', // 48px ~ 3rem ~ 137.5% (ish)
        },
        TEXT: {
            fontFamily: 'Roboto',
            fontWeight: 400,
            fontSize: '2.7vh', // 22px ~ 1.375rem
            textAlign: 'center',
            fontStyle: 'normal',
            lineHeight: '3.75vh', // 36px ~ 2.25rem ~ 135%
        },
    },
}

const TITLE_TEXT_STYLE = {
    fontSize: '32px',
    fontWeight: 700,
    lineHeight: '137.5%',
}

const ELLIPSIS_BG_IMAGE = {
    backgroundImage: `url(${host}/images/common/ellipse-full.svg)`,
}

export { APP, ELLIPSIS_BG_IMAGE, TITLE_TEXT_STYLE }

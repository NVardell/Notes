const FOOTER_NAV = {
    backgroundColor: '#3effc0',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
}

const FOOTER_NAV_LINKS = {
    color: '#000',
    display: 'flex',
    justifySelf: 'center',
    margin: '0.5rem 0',
    padding: '1rem',
    textDecoration: 'none',
    textTransform: 'uppercase',
}

const FOOTER_NAV_UL = {
    alignItems: 'center',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-around',
    listStyleType: 'none',
    textTransform: 'capitalize',
}

const FOOTER_NAV_UL_LINKS = {
    letterSpacing: '4px',
    margin: '0.5rem 0.5rem 0.5rem 0',
}

const FOOTER_RPT_TITLE = {
    fontSize: 'xx-large',
    fontStyle: 'italic',
    fontWeight: 'bold',
    margin: '0 0.5rem',
}

export { FOOTER_NAV, FOOTER_NAV_LINKS, FOOTER_NAV_UL, FOOTER_NAV_UL_LINKS, FOOTER_RPT_TITLE }

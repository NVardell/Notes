const imports = require('eslint-plugin-import')
const jsx = require('eslint-plugin-jsx-a11y')
const prettier = require('eslint-plugin-prettier')
const react = require('eslint-plugin-react')
const reactHook = require('eslint-plugin-react-hooks')

module.exports = [
    {
        files: ['**/*.{js,jsx}'],
        plugins: {
            imports,
            jsx,
            prettier,
            react,
            reactHook,
        },
        languageOptions: {
            parserOptions: {
                ecmaFeatures: {
                    jsx: true,
                },
            },
        },
        settings: {
            react: {
                version: 'detect',
            },
        },
        rules: {
            //  Error
            'array-bracket-spacing': ['error', 'never', { objectsInArrays: false, arraysInArrays: true }],
            'computed-property-spacing': 2,
            'prettier/prettier': 2,
            'react/jsx-uses-react': 'error',
            'react/jsx-uses-vars': 'error',

            //  Warn
            'arrow-body-style': 1,
            'func-names': 1,
            'no-console': 1,
            'no-restricted-exports': 1,
            'no-shadow': 1,
            'object-shorthand': 1,
            'prefer-template': 1,
            'react/destructuring-assignment': ['warn', 'always', { ignoreClassFields: true }],
            'react/jsx-boolean-value': 1,
            'react/jsx-curly-brace-presence': 1,
            'react/jsx-no-useless-fragment': 1,
            'react/prefer-stateless-function': 1,
            'react/require-default-props': 1,
            'react/self-closing-comp': 1,

            //  Ignore
            'import/extensions': 0,
            'import/order': 0,
            'no-param-reassign': 0,
            'object-curly-spacing': 0,
            'react/jsx-props-no-spreading': 0,
            'react/jsx-filename-extension': 0,
            'react/no-array-index-key': 0,
            'react/prop-types': 0,
            'react/react-in-jsx-scope': 0,
            'spaced-comment': 0,
        },
    },
]

"""HWB color class."""

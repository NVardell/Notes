// Any copyright is dedicated to the Public Domain.
// http://creativecommons.org/publicdomain/zero/1.0/

import './tasks/task-test';
import './tasks/task-clean';
import './tasks/task-build';

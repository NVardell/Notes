# RoyallyStated
Using MongoDB Atlas to host and manage data in the cloud.  
Atlas cluster is deployed on an AWS Free Tier Cluster.

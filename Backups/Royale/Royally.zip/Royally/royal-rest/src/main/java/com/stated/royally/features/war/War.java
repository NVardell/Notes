package com.stated.royally.features.war;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * War Details
 *
 * @author Nate Vardell
 * @since 2/1/2020
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class War {

}

package com.stated.royally.helper;

import com.stated.royally.common.clan.Clan;
import com.stated.royally.common.constants.RouteParam;
import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Clan Impl for Official Clash Service
 *
 * @author Nate Vardell
 * @since 2/10/2020
 */
@Log4j2
@Service
public class ClanSvcImpl implements ClashSvc<Clan, String> {

    @Value("${official.resource.clans}")
    private String endpoint;

    @Override
    public Clan getById(String tag) {
        return getClanDetails(tag);
    }

    /**
     * Make REST call to official Clash Royale endpoint to retrieve Clan details.
     *
     * @param clanTag Clan Identifier
     * @return Clan Details for a single clan
     */
    private Clan getClanDetails(String clanTag) {

        log.info("Getting details for clanTag = #{}", clanTag);

        // Add URL Encoded '#' Value to endpoint url
//        return Unirest.get(endpoint + "%23" + clanTag)
//                .asObject(Clan.class)
//                .getBody();
//        return Unirest.get(endpoint+"{Clan Tag}")
//                .routeParam("Clan Tag", "#"+clanTag)
        return Unirest.get(endpoint + RouteParam.CLAN_TAG)
                .routeParam(RouteParam.CLAN_TAG.getParamName(), "%"+clanTag)
                .asObject(Clan.class)
                .getBody();
    }

}

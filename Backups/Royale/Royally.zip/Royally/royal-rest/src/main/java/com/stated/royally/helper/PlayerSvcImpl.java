package com.stated.royally.helper;

import com.stated.royally.common.player.Player;

/**
 * Player Impl for Official Clash Service
 *
 * @author Nate Vardell
 * @since 2/19/2020
 */
public class PlayerSvcImpl implements ClashSvc<Player, String> {

    @Override
    public Player getById(String s) {
        return null;
    }
}

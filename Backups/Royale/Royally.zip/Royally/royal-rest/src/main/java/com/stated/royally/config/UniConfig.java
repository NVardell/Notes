package com.stated.royally.config;

import kong.unirest.Unirest;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * TODO - Add Class Definition
 *
 * @author Nate Vardell
 * @since 7/1/2019
 */
@Log4j2
@Component
public class UniConfig {

    @Autowired Environment env;

    @PostConstruct
    public void init() {
        log.info("Configuring Uni.");

        String token = "Bearer " + env.getRequiredProperty("clash.royale.dev.api.token");
        log.info("Bearer Token is = {}", token);

        Unirest.config()
                .setObjectMapper(new CustomObjectMapper())
                .setDefaultHeader("Authorization", token)
                // For metrics
                .instrumentWith(requestSummary -> {
                    long startNanos = System.nanoTime();
                    return (responseSummary,exception) -> log.info("path: {} status: {} time: {}",
                            requestSummary.getRawPath(),
                            responseSummary.getStatus(),
                            System.nanoTime() - startNanos);
                });
    }
}

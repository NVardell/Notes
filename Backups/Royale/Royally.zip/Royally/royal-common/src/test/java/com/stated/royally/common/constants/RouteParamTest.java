package com.stated.royally.common.constants;


import org.junit.Before;

/**
 * TODO - Add Class Definition
 *
 * @author Nate Vardell
 * @since 2/28/2020
 */
class RouteParamTest {



    @Before
    public void setUp() {

    }
}
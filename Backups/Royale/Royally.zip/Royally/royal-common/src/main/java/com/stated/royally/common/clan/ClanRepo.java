package com.stated.royally.common.clan;

import com.stated.royally.common.ClashRepo;

/**
 * Clan Repo
 *
 * @author Nate Vardell
 * @since 2/23/2020
 */
public interface ClanRepo extends ClashRepo<Clan, String> {
}

package com.stated.royally.common;

/**
 * TODO - Add Class Definition
 *
 * @author Nate Vardell
 * @since 2/19/2020
 */
public interface ClashObject<E> {
}

package com.stated.royally.common;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.io.Serializable;
import java.util.Optional;

/**
 * Clash Base Repo
 *
 * @author Nate Vardell
 * @since 2/23/2020
 */
@NoRepositoryBean
public interface ClashRepo<T, ID extends Serializable> extends MongoRepository<T, ID> {
    Optional<T> findById(ID id);
}
